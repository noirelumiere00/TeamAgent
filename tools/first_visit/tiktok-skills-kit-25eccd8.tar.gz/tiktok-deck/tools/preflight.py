#!/usr/bin/env python3
"""preflight.py — 提出前の全検（ずれ・漏れ・崩れ）を PPTX から直接判定する

機械検査にはレンダリング不要。標準ライブラリ（zipfile + xml）だけで Windows / macOS / Linux で
同じ結果が出る。全頁レンダリング・目視QAの前段であり、機械合格だけで完成を認定しない。

検出するもの:
  [崩れ] 本文領域より下へ出た要素（フッター・ページ番号との衝突）
  [崩れ] スライドの右端・左端の外へ出た要素（4列目の見出しが右端33in に置かれた事故）
  [崩れ] テキスト枠どうしの重なり
  [漏れ] 切り詰め記号（…）で終わるセル・本文＝文章が途中で消えている
  [漏れ] 空のテキスト枠／プレースホルダ（[DATA NOT PROVIDED] 等）
  [漏れ] 未解決の変数（undefined / NaN / null / [object Object]）
  [ずれ] 同一画像が N ページ以上連続（実例の使い回し）
  [ずれ] 画像の縦横比が元ファイルと違う（潰れ・引き伸ばし。PNG / JPEG）
  [情報] ページ別のフォントサイズ最小値（下限に張り付いているページ）
  [構成] 初訪（*_初訪.pptx）: 付録>2枚・本編>8枚は致命的、本編1枚の文字>160字は重大
  [漏れ] 画像の代替テキストに作ったPCの絶対パス（/Users/… 等）が入っている
  [話す] 調査と提案の資料：14pt 未満の文（6字以下の札は除く）・本文550字超（台本は650字超）は重大、450字超は情報。付録と「実画面の解剖」の章は除く。生成ログの「強調の無い表」は情報
  [単独] 前の会（前回・お見せした）を指す言い方は全版、別の版（初訪・具体提案）の名前は初訪版・具体提案版で重大。ノートも見る
  [生成] 生成ログの QA 警告。ログ名は PPTX 名から決める
         TikTok_Competitive_Research{接尾辞}.pptx → generation_log{接尾辞}.md
  [研究] 標準subjectの品質契約・生成監査、選定/分析本数、結論/企画/台本の存在と本文、空表
         research routeはmetadataから判定。改名・コピー・ログ無しでも同じ検査を行う

使い方:
  python3 tools/preflight.py output/deck.pptx
  python3 tools/preflight.py output/deck.pptx --baseline output/previous.pptx   # 前版と全ページ差分
  python3 tools/preflight.py output/deck.pptx --json report.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import struct
import sys
import zipfile
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

# 日本語 Windows ではパイプ・リダイレクト越しの標準出力が cp932 になり、「—」（ページ0の指摘で必ず使う）で
# UnicodeEncodeError になって終了コード1で落ちていた。崩れ（終了コード1）と区別できないので、表示できない字だけ置き換える
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(errors="replace")
    except (AttributeError, ValueError):
        pass

NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}
EMU = 914400.0

# レイアウトの約束（theme.js と揃える）
CONTENT_BOTTOM_IN = 10.20
SLIDE_H_IN = 11.25
SLIDE_W_IN = 20.0
# フッターは「実在する要素」から見つける。全ページにあると決め打ちすると
# 表紙（フッターを持たない）を誤検出する。
# ページ番号は「NN / NN」。初訪（storySlide.js）は総数が未確定だと「NN / --」を出すので、それも拾う
FOOTER_HINT = re.compile(r"DEEP-DIVE|^\d+\s*/\s*(\d+|--)$")
# 初訪（ストーリー型）のフッター左は「{client}様｜{取得日}取得」で、DEEP-DIVE を含まない。
# 拾わないと、フッター左そのものが「フッター(ページ番号)へ入る要素」として全ページ重大になる
STORY_FOOTER = re.compile(r"様\s*[｜|]|[｜|][^｜|]*取得\s*$")
FOOTER_ZONE_IN = 9.5
# レンダラ（src/generate.js）が付ける出力名の接頭辞。verify_assets.py と同じ値にそろえる
RENDERER_PREFIX = "TikTok_Competitive_Research"
# ── 初訪（first_visit.json から組むストーリー型。仕様 v0.2 の F）
FV_SUFFIX = "_初訪"
RESEARCH_LOG_HEAD = "調査と提案の統合資料"   # build_research.js が生成ログの1行目に書く
QUALITY_PREFIX = "tiktok-deck-quality:v1:"
DC_NS = "http://purl.org/dc/elements/1.1/"
TALK_MIN_PT = 14        # 話す資料の字の下限（6字以下の札・番号は除く）
TALK_SHORT = 6
TALK_MAX_CHARS = 550    # 1枚の本文の上限（付録は除く）。JCB の最大は 479 字
TALK_WARN_CHARS = 450
TALK_SCRIPT_CHARS = 650  # 台本のページ（秒ごとの画とテロップが中身そのもの）
# ── 単独で渡せるか（2026-10-02 本人FB「前回のふりかえり…これって初回資料をもとに出した前回って言っている？」）
# 初訪・具体提案・統合のどの版も「1回目の提案」として単独で渡す。まだ開いていない会や、渡していない別の版を指す言い方は書かない。
# 前の会を指す言い方は全版で、別の版の名前は初訪版・具体提案版だけで探す（統合版では「② 具体提案」が章の名前なので正しい）。
# 投稿の引用（「…」の中）は作り手の言葉なので見ない（「前回の動画で…」と話す投稿がある）
PAST_MEETING = re.compile(r"前回|先日|お見せし|ご覧いただい|初回の?(資料|会|打ち合わせ|ご提案)|前の資料")
OTHER_VERSION = re.compile(r"初訪|具体提案|統合版")
PART_SUFFIXES = ("_初訪", "_具体提案", "_具体提案_本編")
QUOTE = re.compile(r"「[^「」]*」|『[^『』]*』")
# 作った PC の絶対パス（画像の代替テキストに pptxgenjs が書いていた。2026-10-02 safeAltText.js で止めた）
LOCAL_PATH = re.compile(r'descr="((?:/Users/|/home/|/private/|[A-Za-z]:\\)[^"]*)"')
# ノートの出典に書くファイル名（review/初訪_レビュー.html 等）は言い方ではない
PATHLIKE = re.compile(r"[\w./-]+\.(?:html|json|md|pptx|pdf|png|jpe?g|csv|tsv)\b")


def standalone_findings(stem: str, slide_texts: dict[int, list[str]], note_texts: dict[int, str],
                        part: str | None = None) -> list[tuple[str, int, str, str]]:
    """前の会・別の版を指す言い方を探す。返り値は (重さ, ページ, 種類, 文)。紙面もノート（話すこと）も見る"""
    is_part = part in ("first", "concrete") if part is not None else stem.endswith(PART_SUFFIXES)
    out = []
    for where, texts in (("紙面", slide_texts), ("ノート", {p: [t] for p, t in note_texts.items()})):
        for page, ts in sorted(texts.items()):
            for t in ts:
                bare = PATHLIKE.sub("", QUOTE.sub("", t))
                for rx, label in ((PAST_MEETING, "前の会を指す"), (OTHER_VERSION if is_part else None, "別の版を指す")):
                    if rx is None:
                        continue
                    m = rx.search(bare)
                    if m:
                        frag = bare[max(0, m.start() - 12): m.end() + 14].replace("\n", " ")
                        out.append(("重大", page, "単独で渡せない言い方",
                                    f"{where}に{label}言い方「…{frag}…」。どの版も1回目の提案として単独で読めるように書く"))
    return out
FV_MAX_MAIN = 8          # 本編（表紙・付録を除く）の上限
FV_MAX_APPENDIX = 2      # 付録の上限（契約はちょうど2枚）
def _fv_body_limit() -> int:
    """上限は tools/vocab/_limits.json（build_first_visit.py・firstVisit.js と同じ値）"""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "vocab", "_limits.json"),
                  encoding="utf-8") as f:
            return int(json.load(f).get("body_chars", 160))
    except (OSError, ValueError):
        return 160


FV_BODY_LIMIT = _fv_body_limit()   # 本編1枚の文字数の上限
# 6字以下の短い文字（順位「12位」・再生「▶ 3.3万」・「PR」・社名チップ等）は文章ではないので数えない。
# レンダラ（components/storySlide.js）の数え方と同じにする。数え方が違うと片方だけが落ちる
FV_SHORT_TOKEN = 6
# 付録は「kicker 位置（上端 0.62in）の文字が『付録』で始まる」ページ。
# 見出しは 0.98in から始まるので、0.95in 未満に絞って見出しを kicker と取り違えない
FV_KICKER_MAX_Y = 0.95
APPENDIX_KICKER = re.compile(r"^付録")
PLACEHOLDERS = ("[DATA NOT PROVIDED]", "[IMAGE NOT PROVIDED]")
BAD_TOKENS = ("undefined", "UNDEFINED", "NaN", "[object Object]", "null,", "Infinity")


def slide_files(z: zipfile.ZipFile) -> list[str]:
    names = [n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)]
    return sorted(names, key=lambda n: int(re.search(r"(\d+)", n.split("/")[-1]).group(1)))


def shapes_of(root: ET.Element) -> list[dict]:
    """テキスト枠と画像の位置・寸法・文字を拾う"""
    out = []
    for sp in root.iter():
        tag = sp.tag.split("}")[-1]
        if tag not in ("sp", "pic"):
            continue
        xfrm = sp.find(".//a:xfrm", NS)
        if xfrm is None:
            continue
        off, ext = xfrm.find("a:off", NS), xfrm.find("a:ext", NS)
        if off is None or ext is None:
            continue
        texts = [t.text or "" for t in sp.iter(f"{{{NS['a']}}}t")]
        sizes = [int(rPr.get("sz")) / 100 for rPr in sp.iter(f"{{{NS['a']}}}rPr")
                 if rPr.get("sz")]
        blip = sp.find(".//a:blip", NS)
        # PowerPoint でトリミングされた画像は、元の縦横比と枠が違って当然。
        # トリミング後の比で比べないと、人が整えた版を「歪み」と誤検知する
        src = sp.find(".//a:srcRect", NS)
        crop = (tuple(int(src.get(k, 0)) / 100000 for k in ("l", "t", "r", "b"))
                if src is not None else None)
        out.append({
            "kind": "pic" if tag == "pic" else "sp",
            "x": int(off.get("x")) / EMU, "y": int(off.get("y")) / EMU,
            "w": int(ext.get("cx")) / EMU, "h": int(ext.get("cy")) / EMU,
            "text": "".join(texts),
            "sizes": sizes,
            "embed": blip.get(f"{{{NS['r']}}}embed") if blip is not None else None,
            "crop": crop,
        })
    return out


def frame_texts(root: ET.Element) -> list[str]:
    """表（graphicFrame）のセルの文字。shapes_of は sp / pic しか見ないので、
    表に入れた文字は初訪の文字数に入らず、表にするだけで上限をすり抜けてしまう"""
    out = []
    for gf in root.iter(f"{{{NS['p']}}}graphicFrame"):
        for tc in gf.iter(f"{{{NS['a']}}}tc"):
            t = "".join(x.text or "" for x in tc.iter(f"{{{NS['a']}}}t")).strip()
            if t:
                out.append(t)
    return out


def quality_metadata(z: zipfile.ZipFile) -> tuple[dict | None, str | None]:
    """Read the portable renderer contract; this marker is identification, not a signature."""
    if "docProps/core.xml" not in z.namelist():
        return None, None
    try:
        root = ET.fromstring(z.read("docProps/core.xml"))
        subject = root.findtext(f"{{{DC_NS}}}subject", "")
    except ET.ParseError:
        return None, "docProps/core.xml を読めない"
    if not subject.startswith("tiktok-deck-quality:"):
        return None, None
    if not subject.startswith(QUALITY_PREFIX):
        return None, "品質metadataの識別子・バージョンが未対応"
    try:
        data = json.loads(subject[len(QUALITY_PREFIX):])
    except (ValueError, TypeError):
        return None, "品質metadataのJSONを読めない"
    if not isinstance(data, dict):
        return None, "品質metadataはJSON objectである必要がある"
    return data, None


def research_content_hint(z: zipfile.ZipFile) -> bool:
    """Recognize unsigned historical research decks without guessing from filenames.

    A DEEP-DIVE footer alone also occurs in the retired route, so require an
    identifiable research heading. Such decks are diagnosed, never certified.
    """
    texts = "\n".join("".join(t.text or "" for t in ET.fromstring(z.read(name)).iter(f"{{{NS['a']}}}t"))
                      for name in slide_files(z))
    headings = ("この資料で分かったこと", "冒頭0〜3秒の入り方と保存率", "保存される型×", "競合差の詳細")
    return "DEEP-DIVE" in texts and any(t in texts for t in headings)


def research_contract_findings(contract: dict | None, metadata_error: str | None,
                               page_shapes: dict[int, list[dict]], roots: dict[int, ET.Element],
                               shape_texts: dict[int, list[str]], note_texts: dict[int, str]) -> list[tuple[str, int, str, str]]:
    """Validate input evidence, renderer audit, required sections and physical content.

    Cover/part slides intentionally contain little text. Content slides are
    checked by their declared role, plus historical headings if metadata is absent.
    Passing this function says nothing about visual review or factual correctness.
    """
    out = []
    def issue(page, kind, message, severity="重大"):
        out.append((severity, page, kind, message))

    if metadata_error:
        issue(0, "品質metadata不正", metadata_error, "致命的")
    if contract is None:
        issue(0, "品質metadataなし", "研究資料の品質契約・生成監査がPPTXに無い。build_research_json.py → build_research.js で再生成し、選定・分析・原稿の検証を行う", "致命的")
        manifest = []
        for page, texts in shape_texts.items():
            top = " ".join(s["text"] for s in page_shapes[page] if s["y"] < 1.4)
            if "この資料で分かったこと" in top:
                manifest.append({"page": page, "type": "insights", "id": "summary"})
            elif any(t in top for t in ("上位20本の中身", "冒頭0〜3秒の入り方と保存率", "誰が投稿しているか")):
                manifest.append({"page": page, "type": "table", "id": "historical_table"})
        part = None
    else:
        part = contract.get("part")
        is_research = contract.get("route") != "creative-report"
        if contract.get("schema_version") != 1 or contract.get("route") not in ("research", "creative-report"):
            issue(0, "品質契約不正", "schema_version=1、既知のrouteが必要", "致命的")
        if is_research:
            if part not in ("first", "concrete", "all"):
                issue(0, "品質契約不正", "研究routeにはpart=first|concrete|allが必要", "致命的")
            ids, n = contract.get("selected_ids"), contract.get("n_analysed")
            if (not isinstance(ids, list) or not ids or any(not isinstance(v, str) or not v.strip() for v in ids)
                    or len(set(v for v in ids if isinstance(v, str))) != len(ids)):
                issue(0, "選定記録欠落", "selected_ids は重複のない空でない投稿ID一覧が必要", "致命的")
            if type(n) is not int or n <= 0:
                issue(0, "分析0本", "分析済み本数 n_analysed は1以上が必要。空の分析で完成合格にできない", "致命的")
            elif isinstance(ids, list) and n != len(ids):
                issue(0, "分析記録不整合", f"選定{len(ids)}本と分析済み{n}本が一致しない", "致命的")
            if type(contract.get("review_collect")) is not bool:
                issue(0, "品質契約不正", "review_collect のbooleanが必要", "致命的")
        manifest = contract.get("slide_manifest")
        if (not isinstance(manifest, list) or not manifest or any(not isinstance(m, dict) for m in manifest)):
            issue(0, "ページ監査欠落", "slide_manifest のページ種別・IDが無い", "致命的")
            manifest = []
        elif [m.get("page") for m in manifest] != list(range(1, len(roots) + 1)):
            issue(0, "ページ監査不整合", "宣言したページ順・枚数とPPTXの実体が一致しない", "致命的")
        audit = contract.get("generation_audit")
        if (not isinstance(audit, dict) or audit.get("schema_version") != 1
                or type(audit.get("slides")) is not int
                or not isinstance(audit.get("missing_images"), list)
                or not isinstance(audit.get("qa"), list)
                or any(not isinstance(t, str) for t in audit.get("missing_images", []) + audit.get("qa", []))):
            issue(0, "生成監査欠落", "生成時の枚数・画像欠落一覧・QA警告を埋め込んだgeneration_auditが必要", "致命的")
        else:
            if audit["slides"] != len(roots):
                issue(0, "生成監査不整合", "生成時の枚数とPPTXの枚数が一致しない", "致命的")
            if audit["missing_images"]:
                issue(0, "画像が出ていない", f"生成監査に画像欠落{len(audit['missing_images'])}件がある", "致命的")
        roles = [(m.get("id"), m.get("type")) for m in manifest]
        proposal_count = contract.get("required_proposal_count", 3)
        script_count = contract.get("required_script_count", 3 if part in ("concrete", "all") else 0)
        if is_research and (type(proposal_count) is not int or proposal_count <= 0
                            or type(script_count) is not int or script_count < 0
                            or (part in ("concrete", "all") and script_count == 0)):
            issue(0, "品質契約不正", "研究資料の企画・台本の必要本数が不正", "致命的")
            proposal_count, script_count = 3, 3 if part in ("concrete", "all") else 0
        if is_research and not any(i == "summary" and t == "insights" for i, t in roles):
            issue(0, "結論欠落", "この資料で分かったこと（summary）の本文ページが無い", "致命的")
        if is_research and not any(t == "proposals" for _, t in roles):
            issue(0, "企画欠落", "根拠を示した企画（proposals）の本文ページが無い", "致命的")
        if is_research:
            proposal_items = [m.get("item_count") for m in manifest if m.get("type") == "proposals"]
            if any(type(n) is not int or n < 1 for n in proposal_items) or sum(n for n in proposal_items if type(n) is int) < proposal_count:
                issue(0, "企画本文欠落", f"企画ページ全体で指定{proposal_count}本の企画本文が必要", "致命的")
        if is_research and sum(t == "script" for _, t in roles) < script_count:
            issue(0, "台本欠落", f"秒単位の台本{script_count}本が必要", "致命的")
        if is_research and contract.get("review_collect") is True and not any(
                t == "reviewshots" or i in ("rv_zero", "rv_voice", "rv_shots", "rv_comp", "rv_vs_pr", "review_reading1", "review_reading2", "effects", "unsat", "purchase", "scene")
                for i, t in roles):
            issue(0, "口コミ本文欠落", "review_collect=trueだが口コミの根拠を示す内容ページが無い", "致命的")
        if is_research and any(i == "rv_zero" for i, _ in roles):
            observation = contract.get("review_observation")
            sources = observation.get("sources") if isinstance(observation, dict) else None
            if (contract.get("review_collect") is not True or not isinstance(observation, dict)
                    or observation.get("status") != "observed_zero" or type(observation.get("count")) is not int or observation["count"] != 0
                    or not isinstance(sources, list) or not sources
                    or any(not isinstance(source, dict) or source.get("status") != "0件"
                           or source.get("site_total") != 0 or source.get("fetched") != 0 or source.get("error")
                           or not isinstance(source.get("url") or source.get("source"), str)
                           or not (source.get("url") or source.get("source")).strip() for source in sources)):
                issue(0, "口コミ0件の観測不正", "口コミ0件のページには入力検証済みの対象URL・サイト表示0件・取得0件の記録が必要", "致命的")

    for page, texts in shape_texts.items() if contract is None or contract.get("route") == "research" else []:
        if any(re.search(r"(?:分析(?:した|済み)?\s*0本|(?<!\d)0本での主な入り方|未分析)", text)
               for text in texts + [note_texts.get(page, "")]):
            issue(page, "分析未完了", "分析0本・未分析を示す本文/ノートがある", "致命的")

    for entry in manifest:
        page, kind = entry.get("page"), entry.get("type")
        if type(page) is not int or page not in roots:
            continue
        if not isinstance(kind, str) or not kind or not isinstance(entry.get("id"), str):
            issue(page, "ページ監査不正", "各ページにtypeとidが必要", "致命的")
            continue
        if kind in ("cover", "part"):
            continue
        shapes = page_shapes[page]
        if any(s["text"].strip() == "画像なし" for s in shapes):
            issue(page, "画像欠落", "実画像の欄が「画像なし」のままになっている", "致命的")
        content = [s["text"].strip() for s in shapes if s["kind"] == "sp" and 2.6 <= s["y"] < CONTENT_BOTTOM_IN
                   and s["text"].strip() and not FOOTER_HINT.search(s["text"].strip())]
        native = frame_texts(roots[page])
        if kind in ("insights", "proposals"):
            substantive = [t for t in content + native if not re.fullmatch(r"[\d\s./—-]+", t)]
            required_items = (1 if contract and contract.get("route") == "creative-report" else
                              3 if entry.get("id") == "summary" else 1)
            count = entry.get("item_count")
            if not substantive or (contract is not None and (type(count) is not int or count < required_items)):
                issue(page, "結論本文欠落" if entry.get("id") == "summary" else "企画本文欠落" if kind == "proposals" else "本文欠落",
                      f"表題・番号だけで必要な本文が無い。{required_items}項目が必要", "致命的")
        elif kind in ("table", "script"):
            # Drawn tables put data below their header, native tables retain tr.
            # Derive the header line instead of hardcoding a skin's body origin.
            native_data = ["".join(x.text or "" for x in row.iter(f"{{{NS['a']}}}t")).strip()
                           for t in roots[page].iter(f"{{{NS['a']}}}tbl") for row in t.findall("a:tr", NS)[1:]]
            table_body = [s for s in shapes if s["kind"] == "sp" and 2.6 <= s["y"] < CONTENT_BOTTOM_IN
                          and s["text"].strip() and not FOOTER_HINT.search(s["text"].strip())]
            header_y = min((s["y"] for s in table_body), default=CONTENT_BOTTOM_IN)
            drawn_rows = [s for s in table_body if s["y"] > header_y + 0.05
                          and not re.fullmatch(r"[\s—–-]+", s["text"])]
            count = entry.get("row_count")
            if (contract is not None and (type(count) is not int or count < 1)) or (
                    not drawn_rows and not any(t and not re.fullmatch(r"[\s—–-]+", t) for t in native_data)):
                issue(page, "空表", "列見出しだけでデータ行が無い", "致命的")
        elif not content and not native and not any(s["kind"] == "pic" and s["y"] >= 2.6 for s in shapes):
            issue(page, "本文欠落", "内容ページの本文・実画像が無く表題だけになっている", "致命的")
        required = entry.get("required_texts", [])
        if contract is not None and (not isinstance(required, list) or any(not isinstance(t, str) for t in required)):
            issue(page, "ページ監査不正", "required_texts は文字列一覧が必要", "致命的")
            continue
        actual = "\n".join(shape_texts[page] + [note_texts.get(page, "")])
        normalize = lambda text: re.sub(r"\s+", "", text)
        absent = [t for t in required if normalize(t) not in normalize(actual)]
        if absent:
            issue(page, "必須内容欠落", f"原稿の必須内容{len(absent)}件が紙面/ノートに無い「{absent[0][:40]}」", "致命的")
    return out


def image_dims(data: bytes) -> tuple[int, int] | None:
    """PNG / JPEG の実寸（幅, 高さ）。読めなければ None。

    src/helpers/imageBox.js の imageSize と同じ読み方（PNG は IHDR、JPEG は SOF マーカー）。
    レンダラはこの実寸で枠を決めるので、別の読み方で比べると
    「レンダラは正しいのに歪み」と誤検知する。以前は JPEG を丸ごと省いていたが、
    投稿カバーはほぼ全部 JPEG なので、初訪（画像が主役）の潰れを1件も見ていなかった
    """
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) >= 24:
            w, h = struct.unpack(">II", data[16:24])
            return (w, h) if w and h else None
        if data[:2] == b"\xff\xd8":
            i, n = 2, len(data)
            while i + 9 < n:
                if data[i] != 0xFF:
                    i += 1
                    continue
                m = data[i + 1]
                if m == 0xFF:                          # 詰め物の FF
                    i += 1
                    continue
                if m == 0x01 or 0xD0 <= m <= 0xD7:     # 長さを持たないマーカー
                    i += 2
                    continue
                if m == 0xDA:                          # SOS 以降は圧縮データ。SOF はこれより前
                    break
                # SOF0-SOF15（DHT=C4 / JPG=C8 / DAC=CC は除く）に実寸が入る
                if 0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return (w, h) if w and h else None
                i += 2 + struct.unpack(">H", data[i + 2:i + 4])[0]
    except (struct.error, IndexError):
        return None
    return None


def generation_log_for(pptx: Path) -> tuple[Path, bool]:
    """PPTX に対応する生成ログと、それが名前から確定できたか。

    generate.js はログを generation_log{接尾辞}.md に書く（初訪なら generation_log_初訪.md）。
    以前は generation_log.md を決め打ちで読んでいたため、具体提案以外の全モードで
    「生成ログなし（情報）」になり、収まらない・画像欠落の警告がどのゲートにも届いていなかった。
    人が改名した納品版は接尾辞を推定し、推定できなければ従来どおり generation_log.md を見る
    """
    d = pptx.resolve().parent
    stem = pptx.stem
    if stem.startswith(RENDERER_PREFIX):
        return d / f"generation_log{stem[len(RENDERER_PREFIX):]}.md", True
    # 調査と提案の資料（build_research.js）は generation_log_<PPTX名>.md に書く。先に完全一致を見る
    # （見ないと「…_初訪.pptx」が接尾辞の推定で旧初訪の generation_log_初訪.md に当たり、別の資料の警告を読んでいた）
    exact = d / f"generation_log_{stem}.md"
    if not exact.exists() and (d / "作業" / f"generation_log_{stem}.md").exists():
        exact = d / "作業" / f"generation_log_{stem}.md"   # build_research.js は output/作業/ に書く（2026-10-06）
    if exact.exists():
        return exact, True
    cands = sorted(d.glob("generation_log?*.md"), key=lambda p: -len(p.stem))
    for c in cands:
        sfx = c.stem[len("generation_log"):]
        if sfx and stem.endswith(sfx):
            return c, False
    return d / "generation_log.md", False


def notes_text(z: zipfile.ZipFile, slide_name: str) -> str:
    """そのページのノート（話すこと）の文字。ノートの番号はページ番号と一致するとは限らないので、ページの rels からたどる"""
    rels = slide_name.replace("slides/", "slides/_rels/") + ".rels"
    if rels not in z.namelist():
        return ""
    m = re.search(r'Target="\.\./notesSlides/(notesSlide\d+\.xml)"', z.read(rels).decode("utf-8"))
    if not m:
        return ""
    root = ET.fromstring(z.read(f"ppt/notesSlides/{m.group(1)}"))
    return "\n".join("".join(t.text or "" for t in para.iter(f"{{{NS['a']}}}t")) for para in root.iter(f"{{{NS['a']}}}p"))


def image_map(z: zipfile.ZipFile, slide_name: str) -> dict[str, str]:
    rid = slide_name.split("/")[-1]
    rels = f"ppt/slides/_rels/{rid}.rels"
    if rels not in z.namelist():
        return {}
    root = ET.fromstring(z.read(rels))
    out = {}
    for rel in root:
        if "image" in (rel.get("Type") or ""):
            out[rel.get("Id")] = rel.get("Target", "").split("/")[-1]
    return out


def overlap(a: dict, b: dict) -> float:
    ix = max(0.0, min(a["x"] + a["w"], b["x"] + b["w"]) - max(a["x"], b["x"]))
    iy = max(0.0, min(a["y"] + a["h"], b["y"] + b["h"]) - max(a["y"], b["y"]))
    inter = ix * iy
    smaller = min(a["w"] * a["h"], b["w"] * b["h"])
    return inter / smaller if smaller > 0 else 0.0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx")
    ap.add_argument("--baseline", help="前版のPPTX。全ページのテキストを比較する")
    ap.add_argument("--json", dest="json_out")
    ap.add_argument("--repeat-limit", type=int, default=3,
                    help="同一画像が何ページ連続したら指摘するか（既定3）")
    ap.add_argument("--fv-body-limit", type=int, default=FV_BODY_LIMIT,
                    help=f"初訪の本編1枚あたりの文字数上限（既定{FV_BODY_LIMIT}）")
    args = ap.parse_args()

    path = Path(args.pptx)
    if not path.exists():
        print(f"[ERROR] ありません: {path}", file=sys.stderr)
        return 2
    # 初訪は「画像＋ワンフレーズ」の別物の資料（2026-09 上長FB）。分析資料の基準では
    # 枚数も文字量も通ってしまうので、名前の接尾辞で見分けて別の基準を足す
    # 2026-10-02：調査と提案の資料の初訪版（build_research_json.py --part first → *_初訪.pptx）も同じ接尾辞になった。
    # こちらは「話す資料」の基準（見出し1行・表6行。build_research.js が組むときに見る）で作るので、旧初訪の
    # 枚数・文字量の基準は当てない。生成ログの1行目で見分ける
    _log, _ = generation_log_for(path)
    log_research = _log.exists() and RESEARCH_LOG_HEAD in open(_log, encoding="utf-8").readline()
    with zipfile.ZipFile(path) as package:
        contract, metadata_error = quality_metadata(package)
        inferred_research = research_content_hint(package)
    research_route = (contract.get("route") == "research" if contract is not None
                      else metadata_error is not None or log_research or inferred_research)
    is_fv = path.stem.endswith(FV_SUFFIX) and not research_route and contract is None and metadata_error is None
    # 旧い Q1〜Q8型（generate.js の具体提案・構成提案など）で作った資料。2026-10-05 から提案資料には使わない
    legacy_deck = (contract is None and _log.exists() and not research_route and not is_fv
                   and "資料モード" in open(_log, encoding="utf-8").read(2000))
    fv_pages: dict[int, dict] = {}

    findings: list[dict] = []
    def add(sev: str, page: int, kind: str, msg: str) -> None:
        findings.append({"severity": sev, "page": page, "kind": kind, "message": msg})

    texts_by_page: dict[int, str] = {}
    # 図形ごとに区切った版。文脈チェックはこちらを使う。
    # 全図形を連結すると、別々のテキストボックスの断片がつながって
    # 存在しない一文ができ、誤検知になる（実際に「最下位」で誤検知した）
    shape_texts: dict[int, list[str]] = {}
    note_texts: dict[int, str] = {}
    page_shapes: dict[int, list[dict]] = {}
    page_roots: dict[int, ET.Element] = {}
    anatomy = [False]            # 「実画面の解剖」の章の中か（ページの順に見る）
    anatomy_pages: list[int] = []
    img_runs: dict[str, list[int]] = defaultdict(list)

    with zipfile.ZipFile(path) as z:
        slides = slide_files(z)
        for name in slides:
            page = int(re.search(r"(\d+)", name.split("/")[-1]).group(1))
            root = ET.fromstring(z.read(name))
            shapes = shapes_of(root)
            page_shapes[page] = shapes
            page_roots[page] = root
            imap = image_map(z, name)
            texts_by_page[page] = "".join(s["text"] for s in shapes)
            shape_texts[page] = [s["text"] for s in shapes if s["text"].strip()] + frame_texts(root)
            note_texts[page] = notes_text(z, name)
            lp = LOCAL_PATH.findall(z.read(name).decode("utf-8"))
            if lp:
                add("重大", page, "手元のパス", f"画像の代替テキストに作ったPCのパスが {len(lp)} 件入っている「{lp[0][:60]}」。"
                    "tiktok-deck の build_research.js / generate.js で作り直す（safeAltText.js がファイル名だけにする）")

            body = [s for s in shapes if s["kind"] == "sp" and s["text"].strip()]

            # ── 崩れ: フッター／ページ番号との衝突（フッターが実在する場合だけ）
            footers = [s for s in body if s["y"] > FOOTER_ZONE_IN
                       and (FOOTER_HINT.search(s["text"].strip())
                            or STORY_FOOTER.search(s["text"].strip()))]
            if footers:
                # フッター左は案件ごとの文言（取得日が無い版・「〇〇｜リール10本」など）で形が揺れる。
                # ページ番号と同じ行・同じ高さの短い帯にある文字はフッターとして扱う（初訪に限らない。
                # 統合資料・分析資料でフッター左がそのまま「フッター衝突」の重大として全ページに出ていた）
                fy = min(s["y"] for s in footers)
                footers += [s for s in body if s not in footers and s["y"] > FOOTER_ZONE_IN
                            and abs(s["y"] - fy) < 0.03 and s["h"] <= 0.5]
            ftop = min((s["y"] for s in footers), default=None)
            for s in body:
                if s in footers:
                    continue
                bottom = s["y"] + s["h"]
                if bottom > SLIDE_H_IN + 0.02:
                    add("致命的", page, "スライド外",
                        f"要素がスライド外へ出る 下端 {bottom:.2f}in > {SLIDE_H_IN}in "
                        f"「{s['text'][:26]}」")
                elif ftop is not None and bottom > ftop + 0.06:
                    add("重大", page, "フッター衝突",
                        f"要素の下端 {bottom:.2f}in がフッター(上端 {ftop:.2f}in)へ入る "
                        f"「{s['text'][:26]}」")

            # ── 崩れ: 左右へのはみ出し。下端しか見ていなかったため、表の列が右端の外
            # （33.85in）に置かれ、その列のデータが描かれていなくても通っていた
            for s in shapes:
                if s["kind"] == "sp" and not s["text"].strip():
                    continue                      # 文字の無い図形（罫線・背景）は対象外
                right = s["x"] + s["w"]
                if right > SLIDE_W_IN + 0.02 or s["x"] < -0.02:
                    add("致命的", page, "スライド外",
                        f"要素がスライドの左右の外へ出る 左端 {s['x']:.2f}in／右端 {right:.2f}in"
                        f"（幅 {SLIDE_W_IN}in）「{s['text'][:26] or '画像'}」")

            # ── 崩れ: テキスト枠の重なり
            for i in range(len(body)):
                for j in range(i + 1, len(body)):
                    ov = overlap(body[i], body[j])
                    if ov > 0.55:
                        add("重大", page, "重なり",
                            f"文字枠が{ov * 100:.0f}%重なる 「{body[i]['text'][:18]}」"
                            f"×「{body[j]['text'][:18]}」")

            # ── 漏れ: 切り詰め・プレースホルダ・未解決変数
            for s in body:
                t = s["text"].strip()
                # 切り詰めはビルド側（truncateToBox の警告）が正。ここでは判定しない。
                # clip() による意図的な抜粋と区別できず、誤検出になるため
                for ph in PLACEHOLDERS:
                    if ph in t:
                        add("重大", page, "欠損", f"{ph} がスライドに出ている")
                for bad in BAD_TOKENS:
                    if bad in t:
                        add("致命的", page, "未解決変数",
                            f"'{bad}' がスライドに出ている 「{t[:40]}」")

            # ── ずれ: 画像の連続使い回し
            for s in shapes:
                if s["kind"] == "pic" and s["embed"]:
                    f = imap.get(s["embed"])
                    if f:
                        img_runs[f].append(page)

            # ── 誤読: 「平均」と書いた列に中央値が入っていないか（同一ページ内の齟齬）
            page_text = "".join(x["text"] for x in body)
            if "平均保存率" in page_text and "中央値" in page_text:
                add("重大", page, "平均と中央値",
                    "同じページに「平均保存率」の列と「中央値」の記述が同居している"
                    "（列見出しと実データの取り違えの疑い）")

            # ── 話す資料（調査と提案の資料）：14pt 未満の文章と、字の多いページ（2026-10-02 字の量の見直し。JCB は最小14pt・最大479字）
            if research_route or (contract is not None and contract.get("route") == "creative-report"):
                # 「実画面の解剖」の章（動画1本2枚の参考ページ）は付録と同じ扱い。中扉で入り、付録で出る
                if any("実画面の解剖" in x["text"] for x in body):
                    anatomy[0] = True
                if any("付録" in x["text"][:12] for x in body if x["y"] < 1.4):
                    anatomy[0] = False
                appendix_pg = anatomy[0] or any("付録" in x["text"][:12] for x in body if x["y"] < 1.4)
                if anatomy[0]:
                    anatomy_pages.append(page)
                script_pg = any("台本" in x["text"][:16] for x in body if x["y"] < 1.4)
                cap = TALK_SCRIPT_CHARS if script_pg else TALK_MAX_CHARS
                prose = [x for x in body if x not in footers and len(x["text"].strip()) > TALK_SHORT and x["sizes"] and min(x["sizes"]) < TALK_MIN_PT]
                if prose and not appendix_pg:
                    add("重大", page, "小さな字", f"{TALK_MIN_PT}pt 未満の文が {len(prose)} か所（最小 {min(min(x['sizes']) for x in prose)}pt）"
                        f"「{prose[0]['text'][:20]}」。字を小さくせず、行を減らすか話すことへ回す")
                # 6字以下の札と数字（「いいね」「26,900」「3位」）は文ではないので数えない（2026-10-05 上位5本のカードに数字を並べた）
                chars = sum(len(x["text"].strip()) for x in body if x not in footers and len(x["text"].strip()) > TALK_SHORT)
                if not appendix_pg and chars > cap:
                    add("重大", page, "字が多い", f"本文 {chars} 字（上限 {cap} 字）。結果だけを紙面に、細かい話はノートへ")
                elif not appendix_pg and chars > TALK_WARN_CHARS:
                    add("情報", page, "字がやや多い", f"本文 {chars} 字（目安 {TALK_WARN_CHARS} 字）")

            # ── 情報: フォントの下限張り付き
            sizes = [x for s in shapes for x in s["sizes"]]
            if sizes and min(sizes) <= 9.5:
                add("情報", page, "文字が最小",
                    f"最小フォント {min(sizes)}pt（下限に張り付いている）")

            # ── 初訪: 付録の判定と本編の文字量（集計はループの後）
            if is_fv:
                parts = [s["text"].strip() for s in body if s not in footers]
                parts += frame_texts(root)
                fv_pages[page] = {
                    "appendix": any(s["y"] < FV_KICKER_MAX_Y
                                    and APPENDIX_KICKER.match(s["text"].strip())
                                    for s in body),
                    "chars": sum(len(t) for t in parts if len(t) > FV_SHORT_TOKEN),
                    "parts": parts,
                    # 分析資料の器（DEEP-DIVE フッター）で組まれた初訪＝廃止した旧経路の出力
                    "legacy": any("DEEP-DIVE" in s["text"] for s in footers),
                }

        # ── ずれ: 縦横比の破壊（元画像と比較）
        for name in slides:
            page = int(re.search(r"(\d+)", name.split("/")[-1]).group(1))
            root = ET.fromstring(z.read(name))
            imap = image_map(z, name)
            for s in shapes_of(root):
                if s["kind"] != "pic" or not s["embed"]:
                    continue
                f = imap.get(s["embed"])
                m = f and f"ppt/media/{f}"
                if not m or m not in z.namelist():
                    add("重大", page, "画像欠落", f"参照先が見つからない: {f}")
                    continue
                # SOF は EXIF の後ろにあり、先頭64バイトでは届かないので全体を読む
                dims = image_dims(z.read(m))
                if not dims:
                    continue
                w, h = dims
                if s["crop"]:
                    cl, ct, cr, cb = s["crop"]
                    w, h = w * (1 - cl - cr), h * (1 - ct - cb)
                if w <= 0 or h <= 0:
                    continue
                src = w / h
                box = s["w"] / s["h"] if s["h"] else 0
                if box and abs(src - box) / src > 0.06:
                    add("重大", page, "縦横比",
                        f"画像が歪んでいる 元={src:.3f} 配置={box:.3f}（{f}）")

    if research_route or contract is not None or metadata_error is not None:
        for sev, page, kind, msg in research_contract_findings(
                contract, metadata_error, page_shapes, page_roots, shape_texts, note_texts):
            add(sev, page, kind, msg)

    # ── 初訪: 枚数と文字量（仕様 v0.2 の F）
    # 上長FBは「スライド数が多すぎる」「文字が多い」。本編が9枚目に伸びたり、
    # 手法の注記が本編へ戻ってきたりしても、分析資料の基準では何も落ちない。
    # 表紙＝1枚目、付録＝kicker が「付録」で始まるページ、残りを本編として数える
    fv_summary = None
    if is_fv:
        appx = [p for p in sorted(fv_pages) if p != 1 and fv_pages[p]["appendix"]]
        main_pages = [p for p in sorted(fv_pages) if p != 1 and p not in appx]
        fv_summary = {"main_pages": main_pages, "appendix_pages": appx,
                      "chars": {p: fv_pages[p]["chars"] for p in main_pages},
                      "body_limit": args.fv_body_limit}
        legacy = [p for p in sorted(fv_pages) if fv_pages[p]["legacy"]]
        if legacy:
            add("致命的", legacy[0], "旧形式の初訪",
                f"分析資料の器（DEEP-DIVE フッター）で組まれた初訪が {len(legacy)} ページある。"
                "旧経路（MODES.初訪）は廃止した。build_first_visit.py → first_visit.json から組み直すこと")
        if len(appx) > FV_MAX_APPENDIX:
            add("致命的", appx[0], "付録の枚数",
                f"付録が {len(appx)} 枚（上限 {FV_MAX_APPENDIX} 枚）: "
                + "、".join(f"p{p}" for p in appx))
        elif len(appx) < FV_MAX_APPENDIX:
            # 手法・定義は付録にしか書かない約束。付録が欠けると、その開示がどこにも無い
            add("情報", 0, "付録が足りない",
                f"付録が {len(appx)} 枚（契約は2枚：調査の前提／数字の一覧）。"
                "手法・定義の開示が抜けていないか確認すること")
        if len(main_pages) > FV_MAX_MAIN:
            add("致命的", 0, "本編の枚数",
                f"本編が {len(main_pages)} 枚（上限 {FV_MAX_MAIN} 枚。表紙・付録を除く）: "
                + "、".join(f"p{p}" for p in main_pages))
        for p in main_pages:
            n = fv_pages[p]["chars"]
            if n > args.fv_body_limit:
                top = sorted(fv_pages[p]["parts"], key=len, reverse=True)[:3]
                add("重大", p, "本編の文字量",
                    f"文字が {n} 字（上限 {args.fv_body_limit} 字。フッター・ページ番号と6字以下のラベルを除く）。"
                    "多い順: " + " / ".join(f"「{t[:16]}」{len(t)}字" for t in top))

    # ── 資料内の矛盾: 同じ数値が「最も高い/最も低い」と別ページで逆に語られていないか
    # 読点・句点をまたがせない。またぐと「最上位のA3.52%は…、最下位のB0.92%」の
    # ような並列文で、Aの数値がBの序列に結び付いて誤検知する
    SUP = r"(最も高|最も低|最多|最少|最下位|最上位|1位|トップ)"
    # 単位必須。裸の数字を拾うと、数字を含む社名や「2面」まで指標扱いになり誤検知する
    NUM = r"([0-9][0-9,\.]*)\s*(%|本|再生)"
    sup_after = re.compile(NUM + r"[^。、]{0,20}?" + SUP)   # 「3.52%は…最も高い」
    sup_before = re.compile(SUP + r"[^。、]{0,20}?" + NUM)  # 「最上位の◯◯社3.52%」
    HIGH = ("最も高", "最多", "最上位", "1位", "トップ")
    LOW = ("最も低", "最少", "最下位")
    claims: dict[str, list[tuple[int, str, str]]] = defaultdict(list)
    for page, texts in shape_texts.items():
        for t in texts:                      # 図形単位。またぐと偽の一文ができる
            for rx, gnum in ((sup_after, 1), (sup_before, 2)):
                for m in rx.finditer(t):
                    num = m.group(gnum).replace(",", "")
                    unit = m.group(gnum + 1)
                    # 1桁の整数（本数の「2本」等）は指標として一意に定まらない
                    if "." not in num and len(num) < 2:
                        continue
                    # 「10本で1位」「10本中最下位」の本数は比べる母数で、指標の値ではない
                    # （別々の指標の順位を同じ「10本」の最高・最低と取り違えていた）
                    after = t[m.start(gnum) + len(m.group(gnum)) + len(unit):][:2]
                    if unit == "本" and (after.startswith("で") or after.startswith("中") or after.startswith("の中")):
                        continue
                    frag = m.group(0)
                    kind = "高" if any(k in frag for k in HIGH) else "低"
                    claims[f"{num}{unit}"].append((page, kind, frag[:40]))
    for num, hits in claims.items():
        kinds = {k for _, k, _ in hits}
        pages = sorted({p for p, _, _ in hits})
        if len(kinds) > 1 and len(pages) > 1:
            ev = " / ".join(f"p{p}「{f}」" for p, _, f in hits[:3])
            add("重大", pages[0], "資料内の矛盾",
                f"同じ数値 {num} が別ページで最高とも最低とも語られている: {ev}")

    if anatomy_pages:
        add("情報", anatomy_pages[0], "解剖の章", f"動画1本ずつの解剖 {len(anatomy_pages)} 枚は参考の部分として、字の大きさ・量の基準から外した"
            f"（p{anatomy_pages[0]}〜p{anatomy_pages[-1]}）")

    if legacy_deck:
        add("重大", 0, "旧い型の資料", "generate.js（Q1〜Q8型）で作った資料。話す資料の決め事（見出し34字・14pt・550字・ノート）が入らない。"
            "tools/build_parts.sh（build_research_json.py → build_research.js）で作り直す")

    # ── 単独で渡せるか：前の会・別の版を指す言い方（紙面とノート）
    for sev, page, kind, msg in standalone_findings(path.stem, shape_texts, note_texts,
                                                  contract.get("part") if contract else None):
        add(sev, page, kind, msg)

    # 同一画像の連続
    for f, pages in img_runs.items():
        pages = sorted(set(pages))
        run, start = 1, pages[0]
        for a, b in zip(pages, pages[1:]):
            if b == a + 1:
                run += 1
            else:
                if run >= args.repeat_limit:
                    add("重大", start, "画像の使い回し",
                        f"同じ画像が {run} ページ連続（p{start}〜p{start + run - 1}）: {f}")
                run, start = 1, b
        if run >= args.repeat_limit:
            add("重大", start, "画像の使い回し",
                f"同じ画像が {run} ページ連続（p{start}〜p{start + run - 1}）: {f}")

    # 前版との差分
    if args.baseline:
        bp = Path(args.baseline)
        if bp.exists():
            with zipfile.ZipFile(bp) as zb:
                base = {}
                for name in slide_files(zb):
                    page = int(re.search(r"(\d+)", name.split("/")[-1]).group(1))
                    root = ET.fromstring(zb.read(name))
                    base[page] = "".join(s["text"] for s in shapes_of(root))
            if len(base) != len(texts_by_page):
                add("重大", 0, "枚数変化",
                    f"前版 {len(base)} 枚 → 今回 {len(texts_by_page)} 枚")
            diff = [p for p in base if base.get(p) != texts_by_page.get(p)]
            if diff:
                add("情報", 0, "本文差分",
                    f"前版と本文が異なるページ: {diff[:20]}{'…' if len(diff) > 20 else ''}"
                    f"（計{len(diff)}枚）")
        else:
            add("情報", 0, "前版なし", f"baseline が見つからない: {bp}")

    # 生成時のQA警告を拾う。レンダラは「本文領域に収まらない」を
    # generation_log.md に書くが、どのゲートも読んでいなかった。
    # 収まらない資料が前検も画像照合も緑で通り抜けていた
    log_path, log_named = generation_log_for(path)
    log = str(log_path)
    log_name = log_path.name
    audit = contract.get("generation_audit") if contract else None
    embedded_audit = (isinstance(audit, dict) and isinstance(audit.get("qa"), list)
                      and all(isinstance(t, str) for t in audit["qa"]))
    # The embedded audit is authoritative for portable research PPTX files.
    # A renamed file must never read another deck's guessed adjacent log.
    if embedded_audit or os.path.exists(log):
        lines = (["## QA"] + [f"- {t}" for t in audit["qa"]] if embedded_audit
                 else open(log, encoding="utf-8").read().split("\n"))
        # 見出しより上の行にも重要な数字がある。「解決できなかった画像」は
        # 画像が紙面に出ていないという意味で、どのゲートも読んでいなかった
        for ln in lines:
            m = re.search(r"宣言があるのに実体が無い画像:\s*(\d+)", ln)
            if m and int(m.group(1)) > 0:
                add("重大", 0, "画像が出ていない",
                    f"{m.group(1)} 枚が、宣言はあるのに実体が無くスライドに出ていない。"
                    f"ファイルが動かされた可能性があります。{log_name} に一覧があります")
            m2 = re.search(r"画像欄そのものが無い箇所:\s*(\d+)", ln)
            if m2 and int(m2.group(1)) > 0:
                add("情報", 0, "画像欄なし",
                    f"{m2.group(1)} 箇所は画像欄が宣言されていない。"
                    "その欄を使わない案件では正常です（ページは画像なしで組まれます）")
        qa = []
        seen_head = False
        for ln in lines:
            if ln.strip().startswith("## QA fixes") or ((research_route or embedded_audit) and ln.strip() == "## QA"):
                seen_head = True
                continue
            if seen_head:
                if ln.startswith("#"):
                    break
                t = ln.strip().lstrip("- ").strip()
                if t and t != "なし":      # generate.js は警告0件のとき「- なし」と書く
                    qa.append(t)
        # 「収まらない（確定）」は重大。「収まらない可能性」は行数の推定に
        # よる警告で、実際には溢れていないことがある（レンダラ側にその注記がある）。
        # 推定を重大にすると誤検知で提出が止まるので、目視の宿題として情報に置く
        maybe = 0
        for t in dict.fromkeys(qa):
            # 初訪のレンダラ警告（generate.js が ## QA fixes に書く）。ページ番号を拾って
            # 該当ページに付ける。下の「可能性」「収まらない」より先に判定する
            # （文言にそれらの語が入っても、初訪の区分を優先するため）
            if t.startswith("強調の無い表"):
                # 見出しの答えが表の中で見えない（JCB の表は答えのマスを強調色にした）。止めないが毎回見せる
                fm = re.search(r"p(\d+)", t)
                add("情報", int(fm.group(1)) if fm else 0, "強調の無い表", t)
                continue
            if t.startswith("補足をノートへ回した"):
                continue          # 決め事どおりの動き（長い補足はノートへ）。報告に並べない
            fm = re.search(r"FV文字量超過\s*p(\d+)", t)
            if fm:
                # 調査と提案の資料では、初訪の部品にも「話す資料」の基準（本文550字）を当てる。旧初訪の160字は旧初訪だけ
                add("情報" if research_route else "重大", int(fm.group(1)), "FV文字量超過", t)
                continue
            fm = re.search(r"FVカード不足\s*p(\d+)", t)
            if fm:
                # カードが減るのは縮退として正常なこともある。止めないが、必ず目に入れる
                add("情報", int(fm.group(1)), "FVカード不足", t)
                continue
            if t.startswith("補足行に入らず非掲載"):
                # その文は紙面に載っていない（SKILL.md「前検」）。情報に置くと既定の表示で隠れ、
                # 終了コード0のまま所見の一部が消えた資料が出ていた。短く書き直すまで止める
                add("重大", 0, "補足行の非掲載", t)
            elif t.startswith("章の欠落"):
                add("重大" if research_route else "情報", 0, "章の欠落", t)
            elif t.startswith("表セルを"):
                # 読める字で要点を出すための意図的な切り詰め。止めないが、隠さず毎回見せる
                add("情報", 0, "表セルの切り詰め", t)
            elif "可能性" in t:
                add("情報", 0, "生成時のQA警告(要目視)", t)
                maybe += 1
            elif "収まらない" in t or "スライド外" in t:
                add("重大", 0, "生成時のQA警告", t)
            else:
                add("情報", 0, "生成時のQA警告", t)
        if maybe:
            add("情報", 0, "目視の宿題",
                f"下限の文字サイズでも収まらない可能性のある本文が {maybe} 件ある。"
                "行数の推定なので実際は収まっていることもある。"
                "render_pptx_any.py で画像にして該当ページを見てから提出すること")
    elif log_named:
        # レンダラの出力名なのにログが無い＝別の場所で生成して PPTX だけ持ってきたか、
        # 生成が途中で止まった。どちらも QA 警告（収まらない・画像欠落）を誰も見ていない
        add("重大", 0, "生成ログなし",
            f"{log_name} が {path.name} の隣に無い。生成時のQA警告（収まらない・画像欠落）を"
            "確認できていない。generate.js で出力し直すか、同じ output/ にログを置くこと")
    else:
        add("情報", 0, "生成ログなし",
            f"{log_name} が無いため、生成時のQA警告は確認できていない"
            "（PPTX が改名されていて、どのログか決められない）")

    order = {"致命的": 0, "重大": 1, "情報": 2}
    findings.sort(key=lambda f: (order.get(f["severity"], 9), f["page"]))
    counts = defaultdict(int)
    for f in findings:
        counts[f["severity"]] += 1
    for severity in ("致命的", "重大", "情報"):
        counts[severity] += 0

    print(f"preflight: {path.name}")
    print(f"  ページ数 : {len(texts_by_page)}")
    if fv_summary:
        print(f"  初訪     : 本編 {len(fv_summary['main_pages'])} 枚（上限 {FV_MAX_MAIN}）"
              f" / 付録 {len(fv_summary['appendix_pages'])} 枚（上限 {FV_MAX_APPENDIX}）")
    # どのログを読んだかを出す。決め打ちの名前で空振りしていたことに誰も気づかなかった
    print(f"  生成監査 : {'PPTX metadata（ログ単体の同梱不要）' if embedded_audit else log_name + ('' if os.path.exists(log) else '（無い）')}")
    print("  目視QA   : 未検証（機械検査の合格だけでは提出完了にならない）")
    print(f"  致命的 {counts['致命的']} / 重大 {counts['重大']} / 情報 {counts['情報']}\n")
    # 情報のうち、人が手を動かさないと閉じないものは既定でも必ず出す。
    # --json の中に隠すと、目視の宿題が誰にも渡らないまま提出される
    ALWAYS_SHOW = ("目視の宿題", "生成ログなし", "FVカード不足", "付録が足りない",
                   "章の欠落", "表セルの切り詰め")
    for f in findings:
        if f["severity"] == "情報" and f["kind"] not in ALWAYS_SHOW:
            continue
        page = f"p{f['page']:>2}" if f["page"] else " — "
        print(f"  [{f['severity']}] {page} {f['kind']}: {f['message']}")
    hidden = [f for f in findings
              if f["severity"] == "情報" and f["kind"] not in ALWAYS_SHOW]
    if hidden:
        print(f"\n  （ほかに情報 {len(hidden)} 件。--json で確認できます）")

    if args.json_out:
        Path(args.json_out).write_text(
            json.dumps({"pptx": str(path), "pages": len(texts_by_page),
                        "pptx_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "generation_log": log if os.path.exists(log) else None,
                        "generation_audit_source": "pptx_metadata" if embedded_audit else "generation_log" if os.path.exists(log) else None,
                        "route": contract.get("route") if contract else "research" if research_route else "legacy_first" if is_fv else "unknown",
                        "route_basis": "pptx_metadata" if contract else "generation_log" if log_research else "content_hint" if inferred_research else "filename" if is_fv else None,
                        "quality_contract": contract,
                        "machine_qa": "failed" if counts["致命的"] or counts["重大"] else "passed",
                        "visual_qa": "unverified", "delivery_ready": False,
                        "first_visit": fv_summary,
                        "counts": dict(counts), "findings": findings},
                       ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n  レポート: {args.json_out}")

    return 1 if counts["致命的"] or counts["重大"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
