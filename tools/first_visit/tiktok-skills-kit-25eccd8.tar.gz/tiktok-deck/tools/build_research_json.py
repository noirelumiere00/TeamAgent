#!/usr/bin/env python3
"""build_research_json.py — 初訪＋具体提案（口コミ・SNS・動画解剖・台本）を1本にする research.json を組む

数字はすべてここで取得データから計算する。文（考察・台本）は <案件>/authored/synthesis.json、
動画ごとの判定は <run>/anatomy/*.json（紙面用の短い版は <run>/anatomy_page/*.json）、
口コミの判定は <reviews>/labels/*.jsonl から読む。レンダラ（src/slides/research.js）は並べるだけ。

使い方:
  python3 tools/build_research_json.py --case <案件> --run <動画のrun-dir> --reviews <口コミのフォルダ> [--check]
出力: <案件>/research.json、<案件>/research_numbers.json（検算用）、<案件>/assets/frames/…（紙面のコマの写し）
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import glob
import json
import os
import re
import shutil
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from fvlib import pr_basis  # noqa: E402
from research_input_gate import InputGateError, read_json, resolve_review_collect, validate_research_inputs  # noqa: E402

ENTRY_JA = {"empathy": "共感入り", "ingredient": "成分入り", "product": "商品紹介入り", "demo": "実演入り", "other": "その他"}
ENTRY_ORDER = ["empathy", "ingredient", "product", "demo", "other"]
TIERS = [("ナノ（〜1万）", 0, 10_000), ("マイクロ（1〜10万）", 10_000, 100_000), ("ミドル（10〜50万）", 100_000, 500_000), ("メガ（50万〜）", 500_000, 10**12)]
ANGLE_JA = {"ranking": "ランキング", "review": "レビュー", "talk": "解説", "compare": "比較", "beforeafter": "ビフォアフ",
            "haul": "購入品", "newlist": "新作", "grwm": "GRWM", "other": "その他", "unknown": "判定不可"}
POSTER_JA = {"official": "公式", "creator_pr": "PRクリエイター", "creator": "クリエイター", "consumer": "一般", "media": "メディア"}
# 口コミの分類名は案件の商材で変わるため、分類表（JSON）から読む。既定はヘアケア用
# （references/research/review_spec_haircare.json）。case.json の research.review_spec で差し替えられる
DEFAULT_REVIEW_SPEC = os.path.join(HERE, "..", "references", "research", "review_spec_haircare.json")
EFFECT_JA, UNSAT_JA, PURCHASE_JA, SCENE_JA = {}, {}, {}, {}
# 口コミの判定ファイル名の頭（labels/<review_key>*.jsonl）→ case.json の brands[].name。main() で case.json から作る
BRANDS: list[tuple[str, str]] = []
SITE_JA = {"cosme": "@cosme", "rakuten": "楽天", "yahoo": "Yahoo!", "kakaku": "価格.com", "mybest": "マイベスト"}
SITE_FULL = {"cosme": "@cosme", "rakuten": "楽天市場", "yahoo": "Yahoo!ショッピング", "kakaku": "価格.com", "mybest": "マイベスト"}   # 紙面で営業が読み上げる正式な呼び名
ANG_ORDER = None   # 見せ方の並び（research.angle_labels_from_vocab のとき案件の語彙から。無ければ既定）


def apply_research_config(rcfg, cfg, case_dir):
    """research 節のうち、ブランド・分類表以外の案件ごとの語を差し替える（2026-09-30 HARIO 案件で追加）。
    entry_labels: 冒頭の入口の分類名（{id: 表示名}。並びもこの順）
    angle_labels_from_vocab: true なら見せ方の表示名と並びを案件の語彙（case.json の vocab）から取る"""
    global ENTRY_JA, ENTRY_ORDER, ANGLE_JA, ANG_ORDER
    if rcfg.get("entry_labels"):
        ENTRY_JA = dict(rcfg["entry_labels"])
        ENTRY_ORDER = list(ENTRY_JA)
    vp = cfg.get("vocab")
    if rcfg.get("angle_labels_from_vocab") and vp and os.path.exists(os.path.join(case_dir, str(vp))):
        vv = jl(os.path.join(case_dir, str(vp)))
        ANGLE_JA = {**ANGLE_JA, **{e["id"]: e["label"] for e in vv.get("angles", [])}}
        ANG_ORDER = [(e["id"], e["label"]) for e in vv.get("angles", []) if e["id"] not in ("unknown",)]


def jl(p):
    return json.load(open(p, encoding="utf-8"))


def views_label(v):
    if v is None:
        return "—"
    if v >= 10_000:
        x = v / 10_000
        return f"{x:.0f}万" if x >= 100 else f"{x:.1f}万".replace(".0万", "万")
    return f"{v:,}"


def pct(x, d=2):
    return "—" if x is None else f"{x * 100:.{d}f}%"


def med(xs):
    xs = [x for x in xs if x is not None]
    return st.median(xs) if xs else None


def med_label(xs):
    value = med(xs)
    return f"{value:,.0f}" if value is not None else "—"


def rates(v):
    s = v.get("stats") or {}
    p = s.get("playCount") or 0
    if not p:
        return None, None
    sv = (s.get("collectCount") or 0) / p
    eng = sum((s.get(k) or 0) for k in ("diggCount", "collectCount", "commentCount", "shareCount")) / p
    return sv, eng


def short_url(u):
    return re.sub(r"^https?://(www\.)?", "", u or "")


def is_pr(v):
    return bool(pr_basis(v))


def txt(v):
    return (v.get("desc") or "") + " " + " ".join("#" + h for h in (v.get("hashtags") or []))


# 初訪版・具体提案版のページの並び（id は pages に付けた _id、または種類から決める。ここに無いページは出さない）
# どの版も単独で「1回目の提案」として渡せる形にする（2026-10-02 本人FB）。具体提案版にも、要約の数字を裏づける
# 「現状」（検索画面・露出・指名検索）を先頭に置く。他の版や前回の会を指す言い方（前回／お見せした／振り返り）は書かない
PART_ORDER = {
    # 2026-10-06 本人の初訪の5点：①自社と競合の発信 ②生活者の検索 ③口コミ（ある業種だけ）④興味を持たれる要素 ⑤結論
    "first": ["summary", "fpart1", "voices", "comp_pr", "official", "own", "standing",
              "fpart2", "kw_1", "kw_2", "kw_3", "share", "fv_competitors",
              "part3", "rv_zero", "rv_voice", "rv_shots", "rv_comp", "rv_vs_pr", "review_reading1", "review_reading2",
              "fpart4", "ad", "top_views", "top_eng", "top_saves", "hook3", "patterns",
              "fpart5", "proposals", "fv_next", "fv_appendix"],
    "concrete": ["summary", "part1", "fv_now", "share", "own", "part3", "rv_zero", "years", "effects", "unsat", "purchase", "scene", "review_reading1", "review_reading2",
                 "part2", "ad", "entry", "sns_reading", "creator", "tier", "diff", "hook4", "patterns", "competitors", "blanks",
                 "part4", "proposals", "script", "kit", "plan", "fv_next", "part_videos", "video", "reviews", "urls", "fv_appendix"],
}
# 版ごとの中扉の見出し（統合版の「① 現状と発見」などの接頭辞を付け替える）
PART_LABELS = {
    "first": {"part3": "PART 3　口コミ"},   # ほかの章扉（fpart1〜5）は build_first_only が作る
    "concrete": {"part1": "PART 1　現状", "part3": "PART 2　顧客の声", "part2": "PART 3　保存される型", "part4": "PART 4　台本と進め方"},
}


def page_id(p):
    if p.get("_id"):
        return p["_id"]
    t = p.get("type")
    if t == "fv":
        return f"fv_{p.get('page')}"
    if t == "part":
        lab = p.get("label", "")
        for n in ("1", "2", "3"):
            if f"PART {n}" in lab:
                return f"part{n}"
        return "part4" if "具体提案" in lab else "part_videos"
    if t == "hook":
        return f"hook{p.get('part')}"
    return t


def select_part(rs, part, g):
    """統合版の pages から、初訪版または具体提案版の並びだけを取り出す（同じ id のページは元の順のまま全部）"""
    by = {}
    for p in rs["pages"]:
        by.setdefault(page_id(p), []).append(p)
    pages = []
    for pid in PART_ORDER[part]:
        for p in by.get(pid, []):
            q = dict(p)
            q["_id"] = pid   # 中扉の番号を付け替えても、元の id で文言を差し替えられるように
            if q.get("type") == "part" and pid in PART_LABELS[part]:
                q["label"] = PART_LABELS[part][pid]
            pages.append(q)
    # 出なかった章（口コミが無い業種の「顧客の声」など）があっても、章の番号は 1,2,3… と続ける
    k = 0
    for q in pages:
        if q.get("type") == "part" and re.match(r"PART \d+", q.get("label") or ""):
            k += 1
            q["label"] = re.sub(r"^PART \d+", f"PART {k}", q["label"])
    proj = dict(rs["project"])
    suffix = {"first": "初訪", "concrete": "具体提案"}[part]
    # 初訪版は動画の個別解剖を持たないので「本編」を付けない。具体提案版は --no-videos のときだけ「_本編」
    proj["file"] = re.sub(r"(_本編)?\.pptx$", lambda m: f"_{suffix}{m.group(1) if part == 'concrete' and m.group(1) else ''}.pptx", proj["file"])
    proj["cover_title"] = g(f"cover_title_{part}", proj.get("cover_title"))
    proj["cover_kicker"] = {"first": "TIKTOK SEARCH — FIRST VISIT", "concrete": "TIKTOK SEARCH — PROPOSAL"}[part]
    if part == "first" and any(page_id(p) == "rv_vs_pr" for p in pages):
        # 初訪の③：口コミの良さ・不満と、PR投稿の訴求を比べる章（2026-10-06）
        for p in pages:
            if page_id(p) == "part3":
                p["title"] = g("part3_title_first", "口コミで褒められる点を、PRは語っているか")
                p["items"] = g("part3_items_first", ["口コミで良いと言われていること・不満", "競合のPRの訴求と、口コミの良さ", "アピールすべきこと・訴求を変えるべきこと"])
    if part == "first":
        proj["min_text"] = 16   # 初訪は字の下限16pt（2026-10-06 本人「細かい文字が多く見づらい」）
    # 版ごとに差し替える文言（synthesis.json の <キー>_first / <キー>_concrete。無ければ統合版と同じ）
    for p in pages:
        pid = page_id(p)
        if p.get("type") == "part" and g(f"{pid}_items_{part}"):
            p["items"] = g(f"{pid}_items_{part}")
        if pid in ("summary", "proposals") and g(f"{pid}_{part}"):
            # The effective proposals were already split into groups of three.
            # Reapplying the full items override here would restore all items
            # on every page and silently truncate them in the renderer.
            p.update({k: v for k, v in g(f"{pid}_{part}").items() if pid != "proposals" or k != "items"})
    if g(f"next_override_{part}"):
        for p in pages:
            if p.get("type") == "fv" and p.get("page") == "next":
                p["override"] = g(f"next_override_{part}")
    return {"project": proj, "pages": pages}


def skin_file_mark(skin, case_dir):
    """スキンの版のファイル名の印。キット同梱（@名前）は skin.json の file_mark、無ければ _<名前>"""
    m = re.fullmatch(r"@([\w-]+)", str(skin))
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "skins", m.group(1), "skin.json") if m \
        else os.path.join(case_dir, skin)
    try:
        mark = json.load(open(p, encoding="utf-8")).get("file_mark")
    except Exception:
        mark = None
    return mark if mark is not None else "_" + (m.group(1) if m else os.path.splitext(os.path.basename(str(skin)))[0])


DEFAULT_SKIN = "@deepdive"   # 既定の見た目＝元のFMT（2026-10-06）。--skin none で明朝の話す資料


def resolve_skin(chosen):
    """(使うスキン, ファイル名に印を入れるか)。指定なし＝既定（印なし）、none＝スキン無し、ほか＝そのスキン（既定と違えば印）"""
    if chosen is None or chosen == "":
        return DEFAULT_SKIN, False
    if str(chosen).lower() == "none":
        return None, False
    return chosen, chosen != DEFAULT_SKIN
TALKED = ("relevant", "mention", "off_category")   # 「語られている」（label_posts.py と同じ）


def post_kind(p):
    """投稿者の種類：official（その社の公式）／pr（#PR等の表記・広告配信の印・PRクリエイター）／creator（フォロワー1万以上）／consumer"""
    if p.get("poster") == "official":
        return "official"
    if p.get("is_pr") or p.get("is_ad") or p.get("poster") == "creator_pr":
        return "pr"
    return "creator" if p.get("poster") == "creator" else "consumer"


def brand_voices(brands, labels):
    """社ごとに、社名の検索で判定した本数・語られている投稿・投稿者の種類の本数（①と③で同じ数え方を使う）"""
    info = []
    for b in brands:
        kind = "own" if b.get("own") else "competitor"
        judged, talked = 0, []
        for p in labels.values():
            for ax in p["axes"]:
                if ax["kind"] == kind and ax["name"] == b["name"] and ax.get("relevance"):
                    judged += 1
                    if ax["relevance"] in TALKED:
                        talked.append(p)
        c = collections.Counter(post_kind(p) for p in talked)
        info.append(dict(b=b, judged=judged, talked=talked, c=c, paid=c["official"] + c["pr"]))
    return info


REVIEW_VS_PR = {"min_pos": 5, "min_share": 0.15, "ratio": 1.5, "top": 3, "min_n": 30, "min_paid": 3, "weak_share": 0.10}


def review_judgments(cfg, spec, rl, labels, BRANDS, rc, appeal_ids=None):
    """③ 口コミ×PR投稿の判定（2026-10-06 本人「口コミで良いと言われている点がPR投稿で訴求されていなければそこをアピールすべき、
    PRの訴求が口コミと違えば訴求を変えるべき」）。分類表の appeal_map（口コミの分類 → 投稿の訴求）が無い業種では何もしない。
    返り値：{社名: {n, cats, strong, weak, paid, people, pa, main, verdicts, few, issuer, key, b}}"""
    amap = spec.get("appeal_map") or {}
    if not amap:
        return {}
    thr = {**REVIEW_VS_PR, **(rc.get("review_vs_pr") or {})}
    EFF = spec["effects"]
    UNS = spec.get("unsatisfied") or {}
    inv = collections.defaultdict(list)
    for c, a in amap.items():
        inv[a].append(c)
    key_of = {bn: k for k, bn in BRANDS}
    res = {}
    for x in brand_voices(cfg["brands"], labels):
        b = x["b"]
        key = key_of.get(b["name"])
        ls = rl.get(key, []) if key else []
        n = len(ls)
        pos = collections.Counter(c for l in ls for c in set(l.get("satisfied") or []) if c in EFF)
        # 国際ブランド・発行会社の違いから来る不満（issuer）はPRの判定に使わない（数は別に出す）
        neg = collections.Counter(c for l in ls if not l.get("issuer") for c in set(l.get("unsatisfied") or []) if c in EFF or c in UNS)
        neg_all = collections.Counter(c for l in ls for c in set(l.get("unsatisfied") or []) if c in EFF or c in UNS)
        cats = {c: dict(pos=pos[c], neg=neg[c], neg_all=neg_all[c], p=(pos[c] / n if n else 0), q=(neg[c] / n if n else 0),
                        q_all=(neg_all[c] / n if n else 0)) for c in list(EFF) + list(UNS)}
        cand = [c for c in EFF if cats[c]["pos"] >= thr["min_pos"] and cats[c]["p"] >= thr["min_share"] and cats[c]["pos"] >= thr["ratio"] * cats[c]["neg"]]
        strong = sorted(cand, key=lambda c: -cats[c]["p"])[:thr["top"]]
        weak = [c for c in cats if cats[c]["neg"] >= thr["min_pos"] and cats[c]["q"] >= thr["min_share"] and cats[c]["neg"] > cats[c]["pos"]]
        paid = [p for p in x["talked"] if post_kind(p) in ("official", "pr")]
        people = [p for p in x["talked"] if post_kind(p) not in ("official", "pr")]
        pa = collections.Counter(p.get("appeal") for p in paid)
        main = [a for a, k in pa.most_common() if a and k >= 2 and k / len(paid) >= 0.30] if paid else []
        verdicts = []
        if n:
            for c in strong:
                hits = sum(1 for p in paid if p.get("appeal") == amap.get(c))
                if appeal_ids is not None and amap.get(c) not in appeal_ids and not hits:
                    # 投稿の訴求の選択肢にまだ無い分類（デザイン・決済）は「0本」と言えない。判定し直すまで保留
                    verdicts.append(dict(cat=c, verdict="PRは判定待ち", paid_hits=None))
                    continue
                verdicts.append(dict(cat=c, verdict="合っている" if hits else "アピールすべき", paid_hits=hits))
            if len(paid) >= thr["min_paid"]:
                for a in main:
                    cs = inv.get(a, [])
                    if cs and not any(c in strong for c in cs) and any(cats[c]["p"] < thr["weak_share"] or c in weak for c in cs):
                        verdicts.append(dict(cat=cs[0], verdict="訴求を変えるべき", appeal=a, paid_hits=pa[a]))
        res[b["name"]] = dict(key=key, n=n, cats=cats, strong=strong, weak=weak, paid=paid, people=people, pa=pa, main=main,
                              verdicts=verdicts, few=(0 < n < thr["min_n"]), issuer=sum(1 for l in ls if l.get("issuer") and l.get("unsatisfied")), b=b)
    return res


def review_vs_pr_pages(cfg, spec, J, rl, rv_by, g, app_label, site_txt, window_txt, case_dir=None):
    """③ の3枚（rv_voice・rv_comp・rv_vs_pr）。初訪だけ（_first_only）"""
    if not J:
        return []
    EFF, UNS, amap = spec["effects"], spec.get("unsatisfied") or {}, spec.get("appeal_map") or {}
    lab = lambda c: (EFF.get(c) or UNS.get(c) or c).split("（")[0]  # noqa: E731
    short = lambda b: b.get("short") or b["name"]  # noqa: E731
    own_name = next((b["name"] for b in cfg["brands"] if b.get("own")), cfg["brands"][0]["name"])
    o = J[own_name]
    on = short(o["b"])
    if not o["n"]:
        return []
    out = []
    comps = [r for nm, r in J.items() if nm != own_name]
    comp_paid = [p for r in comps for p in r["paid"]]
    N = len(comp_paid)

    def quotes(cat, field, k=2):
        rows = [l for l in rl.get(o["key"], []) if cat in (l.get(field) or []) and l.get("quote")]
        rows.sort(key=lambda l: -int((rv_by.get((l["review_id"], l.get("product_id"))) or {}).get("helpful_count") or 0))
        return [f"「{l['quote']}」（{(rv_by.get((l['review_id'], l.get('product_id'))) or {}).get('product_name') or ''}　"
                f"{(rv_by.get((l['review_id'], l.get('product_id'))) or {}).get('review_url') or ''}）" for l in rows[:k]]

    # ── 口コミの良い点・不満（自社）
    goods = [c for c, v in sorted(o["cats"].items(), key=lambda kv: -kv[1]["pos"]) if v["pos"] > 0 and c in EFF][:3]
    bads = [c for c, v in sorted(o["cats"].items(), key=lambda kv: -kv[1]["neg_all"]) if v["neg_all"] > 0 and c not in goods][:3]
    rows, emph, talk = [], [], []
    for c in goods + bads:
        v = o["cats"][c]
        rows.append([lab(c), f"{v['pos']}件（{v['p']:.0%}）", f"{v['neg_all']}件（{v['q_all']:.0%}）"])
        if c in o["strong"]:
            emph.append(len(rows) - 1)
    for c in goods[:2]:
        talk += [f"良い（{lab(c)}）：{q}" for q in quotes(c, "satisfied")]
    for c in bads[:2]:
        talk += [f"不満（{lab(c)}）：{q}" for q in quotes(c, "unsatisfied")]
    if o["issuer"]:
        talk.append(f"不満のうち{o['issuer']}件は国際ブランド・発行会社の違いから来るもの（Apple Payが使えない・発行会社の会員サイト等）。PRとの比較の判定には入れていない")
    g1, b1 = (lab(goods[0]) if goods else "—"), (lab(bads[0]) if bads else "—")
    t = g("rv_voice")
    if rows:
        out.append(dict(type="table", _id="rv_voice", _first_only=True, kicker=f"{site_txt}の{on}の口コミ{o['n']}件（{window_txt}）",
                        headline=t.get("headline", f"{on}の口コミの良さは{g1}、不満は{b1}"),
                        sub=t.get("sub", f"良いと書いた・不満を書いた口コミの件数（1件が複数に入る）"),
                        head=["言われていること", "良いと書いた", "不満を書いた"], rows=rows, align=["left", "right", "right"],
                        col_w=[6.4, 3.2, 3.2], emph_rows=emph,
                        big=dict(value=f"{o['cats'][goods[0]]['p']:.0%}", label=f"{g1}を良いと書いた口コミ（{o['n']}件中{o['cats'][goods[0]]['pos']}件）") if goods else None,
                        talk=talk))

    # ── 口コミの実画面（写し）。2026-10-06 本人「写し＋URLで飛べると確証が出せる」
    # 良い点の1位から2件・不満の1位から1件を選び <案件>/review_shots_wanted.json に書く。tools/review_shots.js で撮った
    # <案件>/assets/review_shots/shots.json に揃っていれば、良い点・不満のページの次に写しのページを置く
    if case_dir and goods:
        PIN = {"kakaku": 0, "cosme": 0}   # 押すと口コミ1件が開くサイトを先に選ぶ
        def terms(cat):
            # 分類の名前の語（「マイル（貯まる・使える・有効期限）」→ マイル・貯まる・使える・有効期限）。引用にこの語がある口コミを先に選ぶ
            # （引用が分類と別の話の口コミを写すと、黄色の線の一文が見出しと合わない。JAL：会員サイトの不満の枠に窓口の対応の一文が来ていた）
            full = EFF.get(cat) or UNS.get(cat) or cat
            return [w for w in re.split(r"[（）()・／/、\s]+", full) if len(w) >= 2]
        def pick(cat, field, k):
            rows = [l for l in rl.get(o["key"], []) if cat in (l.get(field) or []) and l.get("quote")]
            info = lambda l: rv_by.get((l["review_id"], l.get("product_id"))) or {}  # noqa: E731
            ws = terms(cat)
            on_topic = lambda l: 0 if any(w in l["quote"] for w in ws) else 1  # noqa: E731
            rows.sort(key=lambda l: (on_topic(l), PIN.get(info(l).get("site") or l.get("site"), 1), -int(info(l).get("helpful_count") or 0)))
            return [l for l in rows if on_topic(l) == 0][:k]
        wanted = g("review_shots") or []   # 原稿で口コミを決めたとき：[{review_id, label, tone}]
        if not wanted:
            wanted = [dict(review_id=l["review_id"], label=f"良い点：{lab(goods[0])}", tone="good") for l in pick(goods[0], "satisfied", 2)]
            if bads:
                wanted += [dict(review_id=l["review_id"], label=f"不満：{lab(bads[0])}", tone="bad") for l in pick(bads[0], "unsatisfied", 1)]
        with open(os.path.join(case_dir, "review_shots_wanted.json"), "w", encoding="utf-8") as f:
            json.dump(wanted, f, ensure_ascii=False, indent=1)
        sp = os.path.join(case_dir, "assets", "review_shots", "shots.json")
        have = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else {}
        shots = []
        for w in wanted:
            x = have.get(w["review_id"])
            if not x or not os.path.exists(os.path.join(case_dir, "assets", "review_shots", x.get("png") or "")):
                continue
            d = str(x.get("posted_at") or "")
            dl = f"{int(d[:4])}年{int(d[5:7])}月{int(d[8:10])}日" if re.match(r"\d{4}-\d{2}-\d{2}", d) else d
            cap = "｜".join(v for v in ([f"満足度 {x['satisfaction']}／{x.get('satisfaction_scale') or 5}"] if x.get("satisfaction") else []) + [x.get("product_name") or "", dl] if v)
            shots.append(dict(png=f"assets/review_shots/{x['png']}", url=x.get("url"), label=w["label"], tone=w["tone"], caption=cap,
                              quote=x.get("quote") or "", site=x.get("site"), pinpoint=x.get("pinpoint", x.get("site") in PIN)))
        if shots:
            sites = "・".join(dict.fromkeys(SITE_FULL.get(x["site"], x["site"]) for x in shots))
            out.append(dict(type="reviewshots", _id="rv_shots", _first_only=True, kicker=f"{sites}の口コミ（実画面）｜{on}",
                            headline=t.get("shots_headline", f"口コミの実画面：{g1}は高評価、{b1}は不満" if bads else f"口コミの実画面：{g1}が高評価"),
                            sub="画像か下のリンクを押すと、元の口コミが開く", shots=shots,
                            note="黄色の線＝引用した一文。投稿者の名前は写していない。撮った日は写しの記録（shots.json）にある"))
        missing_ids = [w["review_id"] for w in wanted if w["review_id"] not in have]
        if missing_ids:
            print(f"注意: 口コミの写しが未撮影 {len(missing_ids)}件（node tools/review_shots.js --reviews <reviews> --out {os.path.join(case_dir, 'assets', 'review_shots')} {' '.join(missing_ids)}）", file=sys.stderr)

    # ── 競合のPRの訴求と、口コミの良さ（社ごと）
    rows, emph = [], []
    for nm, r in J.items():
        b = r["b"]
        main = "・".join(f"{app_label.get(a, a)} {r['pa'][a]}本" for a in r["main"]) or ("—" if r["paid"] else "（PRなし）")
        if not r["n"]:
            good, verdict = "口コミ未取得", "—"
        else:
            good = "・".join(lab(c) for c in r["strong"]) or "抜けた良さなし"
            vs = [v["verdict"] for v in r["verdicts"]]
            verdict = next((x for x in ("訴求を変えるべき", "アピールすべき", "合っている", "PRは判定待ち") if x in vs), "—")
            if r["few"]:
                verdict = f"参考（口コミ{r['n']}件）"
        rows.append([short(b) + ("（貴社）" if b.get("own") else ""), f"{len(r['paid'])}本", main, good, verdict])
        if b.get("own"):
            emph.append(len(rows) - 1)
    s0 = o["strong"][0] if o["strong"] else None
    k0 = sum(1 for p in comp_paid if s0 and p.get("appeal") == amap.get(s0))
    t = g("rv_comp")
    out.append(dict(type="table", _id="rv_comp", _first_only=True, kicker=f"社名で検索した上位の公式・PRの投稿 × {site_txt}の口コミ",
                    headline=t.get("headline", (f"競合の公式・PR{N}本で、{lab(s0)}を推す投稿は{k0}本" if s0 else f"競合の公式・PR{N}本の訴求と、口コミの良さ")),
                    sub=t.get("sub", "PRで多い訴求＝2本以上かつ3割以上。口コミの良さ＝良いと書いた口コミが多く、不満より多い分類"),
                    head=["社名", "公式・PR", "PRで多い訴求", "口コミで多い良さ", "判定"], rows=rows,
                    align=["left", "right", "left", "left", "left"], col_w=[3.0, 1.9, 4.6, 4.6, 3.6], emph_rows=emph,
                    talk=[f"{short(r['b'])}：口コミ{r['n']}件、公式・PR{len(r['paid'])}本（訴求 " +
                          "・".join(f"{app_label.get(a, a or '空')}{k}" for a, k in r["pa"].most_common()) + "）" for r in J.values()]))

    # ── 訴求すべきこと（自社）
    rows, emph = [], []
    o_paid = len(o["paid"])
    for c in o["strong"]:
        v = o["cats"][c]
        a = amap.get(c)
        ph = sum(1 for p in o["paid"] if p.get("appeal") == a)
        pe = sum(1 for p in o["people"] if p.get("appeal") == a)
        ch = sum(1 for p in comp_paid if p.get("appeal") == a)
        verdict = next((x["verdict"] for x in o["verdicts"] if x["cat"] == c), "—")
        if verdict == "PRは判定待ち":
            rows.append([lab(c), f"{v['pos']}件／{v['neg_all']}件", "判定待ち", "判定待ち", verdict])
            continue
        rows.append([lab(c), f"{v['pos']}件／{v['neg_all']}件", f"{ph}本（個人{pe}本）", f"{ch}本", verdict])
        if verdict == "アピールすべき":
            emph.append(len(rows) - 1)
    ind = collections.Counter(a for p in comp_paid for a in [p.get("appeal")] if a in set(amap.values()))
    for a, k in ind.most_common(2):
        c = next((c for c, aa in amap.items() if aa == a), None)
        if not c or c in o["strong"] or k < 2:
            continue
        v = o["cats"][c]
        rows.append([lab(c) + "（競合のPRに多い）", f"{v['pos']}件／{v['neg_all']}件", f"{sum(1 for p in o['paid'] if p.get('appeal') == a)}本", f"{k}本",
                     "合わせなくてよい" if v["p"] < REVIEW_VS_PR["weak_share"] else "—"])
    bads2 = [c for c in sorted(o["cats"], key=lambda c: -o["cats"][c]["neg_all"]) if o["cats"][c]["neg_all"] > o["cats"][c]["pos"] and o["cats"][c]["neg_all"] > 0][:1]
    for c in bads2:
        v = o["cats"][c]
        rows.append([lab(c) + "（不満）", f"{v['pos']}件／{v['neg_all']}件", "—", "—", "動画で答える"])
    if not o["strong"]:
        # 抜けた良さが無いときも空のページにしない（件数の多い2つを参考に）
        for c in [c for c in sorted(EFF, key=lambda c: -o["cats"][c]["pos"]) if o["cats"][c]["pos"] > 0][:2]:
            v = o["cats"][c]
            rows.insert(0, [lab(c) + "（参考）", f"{v['pos']}件／{v['neg']}件", "—", "—", "—"])
    t = g("rv_vs_pr")
    if s0:
        head = f"{lab(s0)}は口コミで評価され、{on}のPRは{o_paid}本" + ("。語るべき" if o_paid == 0 else "")
    else:
        head = f"{on}の口コミで抜けた良さは、まだ無い"
    if len(head) > 34:
        head = f"{lab(s0)}は評価され、PRは{o_paid}本" if s0 else head[:34]
    out.append(dict(type="table", _id="rv_vs_pr", _first_only=True,
                    kicker=f"{on}の口コミ{o['n']}件 × 公式・PRの投稿（{on}{o_paid}本・競合{N}本）",
                    headline=t.get("headline", head),
                    sub=t.get("sub", (f"競合のPR・公式{N}本で{lab(s0)}を推す投稿は{k0}本" if s0 else "件数の多い良さを参考に並べた")),
                    head=["言われていること", f"口コミ 良い／不満", f"{on}のPR（個人）", f"競合のPR（{N}本中）", "判定"], rows=rows,
                    align=["left", "right", "right", "right", "left"], col_w=[4.6, 3.2, 3.2, 3.3, 3.4], emph_rows=emph,
                    note="アピールすべき＝口コミで評価されているのにPR・公式の投稿が無い。訴求を変えるべき＝PRで推しているのに口コミで評価が少ない・不満の方が多い（PRが3本以上の社だけ）。"
                         "口コミは評価されている点の傾向で、語れば伸びるとは断定しない"))
    return out


def search_words(cfg, n_max=1):
    """黒文字（小見出し）に書く検索語。「クレジットカード おすすめ」ほか2語"""
    qs = [k["query"] for k in cfg["keywords"]]
    head = "".join(f"「{q}」" for q in qs[:n_max])
    return head + (f"ほか{len(qs) - n_max}語" if len(qs) > n_max else "")


def build_first_only(cfg, C, fv, labels, raw, axis_videos, share_rows, BRANDS, OWN, own_b, cat_label, g, card, vrow, rc):
    """初訪の ①自社と他社の発信・②生活者の検索 のページ（_first_only。select_part('first') だけが拾う）"""
    vp = cfg.get("vocab")
    voc = jl(os.path.join(C, str(vp))) if vp and os.path.exists(os.path.join(C, str(vp))) else {}
    ANG_L = {**ANGLE_JA, **{e["id"]: e["label"] for e in voc.get("angles", [])}}
    APP_L = {e["id"]: e["label"] for e in voc.get("appeals", []) + list(rc.get("appeal_extra", []))}
    brands = cfg["brands"]
    short = lambda b: b.get("short") or b["name"]  # noqa: E731
    out = []

    # ── ① 社名で検索すると、誰が語っているか（公式／PR／クリエイター／一般）
    kind_of = post_kind
    info = brand_voices(brands, labels)
    own_i = next((i for i, x in enumerate(info) if x["b"].get("own")), 0)
    own, comps = info[own_i], [x for x in info if not x["b"].get("own")]
    # 「上位N本」は社ごとの判定本数で最も多い値（窓の外のPRを確かめた1本で「上位21本」にならないように）
    n_judged = collections.Counter(x["judged"] for x in info if x["judged"]).most_common(1)[0][0] if any(x["judged"] for x in info) else 0
    if n_judged:
        lead = max(comps, key=lambda x: x["paid"]) if comps else None
        rows = [[short(x["b"]) + ("（貴社）" if x["b"].get("own") else ""), str(x["judged"]), str(len(x["talked"])),
                 str(x["c"]["official"]), str(x["c"]["pr"]), str(x["c"]["creator"]), str(x["c"]["consumer"])] for x in info]
        if lead and own["paid"] == 0 and lead["paid"] > 0:
            head = f"{short(own['b'])}を語るのは個人だけ。公式・PRは0本"
        elif lead and own["paid"] < lead["paid"]:
            head = f"{short(own['b'])}の公式・PRは{own['paid']}本、{short(lead['b'])}は{lead['paid']}本"
        else:
            head = f"{short(own['b'])}は公式・PRで{own['paid']}本を出している"
        sub = f"{short(lead['b'])}は公式{lead['c']['official']}本・PR{lead['c']['pr']}本" if lead else ""
        t = g("voices")
        out.append(dict(type="table", _id="voices", _first_only=True,
                        kicker=f"社名で検索した上位{n_judged}本（「{own_b['query']}」ほか{len(comps)}社）",
                        headline=t.get("headline", head), sub=t.get("sub", sub),
                        head=["社名", "判定", "語られている", "公式", "PR・広告", "クリエイター", "一般"],
                        rows=rows, align=["left"] + ["right"] * 6, col_w=[3.9, 1.7, 2.6, 1.7, 2.1, 2.6, 1.8], emph_rows=[own_i],
                        big=dict(value=f"{own['paid']}本", label=f"{short(own['b'])}の公式・PRの投稿" + (f"（{short(lead['b'])}は{lead['paid']}本）" if lead else ""))))

    # ── ① 競合のPRは、何をやっているか（PR・公式の投稿を再生の多い順に5本＋社ごとの本数）
    pool = []
    for x in comps:
        for p in x["talked"]:
            if kind_of(p) in ("official", "pr") and p["video_id"] in raw:
                pool.append((x, p))
    seen, picked = set(), []
    for x, p in sorted(pool, key=lambda t: -(t[1].get("views") or 0)):
        if p["video_id"] in seen:
            continue
        seen.add(p["video_id"])
        picked.append((x, p))
        if len(picked) >= 5:
            break
    if picked:
        cards = []
        for x, p in picked:
            c = card(vrow(p["video_id"]), views_label(p.get("views")), "再生", ("保存", "いいね"), False)
            c["caption_line"] = f"{short(x['b'])}の{'公式' if kind_of(p) == 'official' else 'PR'}"
            c["is_pr"] = kind_of(p) == "pr"
            cards.append(c)
        lines = []
        for x in sorted(comps, key=lambda x: -x["paid"]):
            if not x["paid"]:
                continue
            ps = [p for p in x["talked"] if kind_of(p) in ("official", "pr")]
            ap = collections.Counter(p.get("appeal") for p in ps if p.get("appeal") not in (None, "none", "other", "unknown")).most_common(1)
            an = collections.Counter(p.get("angle") for p in ps if p.get("angle") not in (None, "other", "unknown")).most_common(1)
            what = f"「{APP_L.get(ap[0][0], ap[0][0])}」の訴求{ap[0][1]}本" if ap else (f"「{ANG_L.get(an[0][0], an[0][0])}」{an[0][1]}本" if an else "")
            lines.append(f"{short(x['b'])}：公式{x['c']['official']}本・PR{x['c']['pr']}本" + (f"。{what}" if what else ""))
        lines = lines[:2] + [f"{short(own['b'])}：公式・PRとも{own['paid']}本" if own["paid"] == 0 else f"{short(own['b'])}：公式{own['c']['official']}本・PR{own['c']['pr']}本"]
        top = max(comps, key=lambda x: x["paid"])
        t = g("comp_pr")
        out.append(dict(type="top5", _id="comp_pr", _first_only=True,
                        kicker=f"社名で検索した上位{n_judged}本のうち、競合の公式・PRの投稿",
                        headline=t.get("headline", f"競合のPRは{short(top['b'])}が最多の{top['paid']}本" + (f"、{short(own['b'])}は0本" if own["paid"] == 0 else "")),
                        sub=t.get("sub", f"競合の公式・PRの投稿 計{sum(x['paid'] for x in comps)}本を再生の多い順に"),
                        factors_title=t.get("factors_title", "社ごとの公式・PRの本数と、多い訴求"), factors=t.get("factors", lines), cards=cards))

    # ── ① 公式アカウントの発信（tiktok-acquire/scripts/account_posts.py が書いた raw/account_<handle>.json）
    def account(h):
        f = os.path.join(C, "raw", f"account_{h.lstrip('@')}.json")
        return jl(f) if os.path.exists(f) else None

    def acc_row(label, h, doc, own_row=False):
        if not doc:
            return [label, f"@{h}", "未取得", "—", "—", "—"], None
        if not doc.get("ok"):
            return [label, f"@{h}", "取得できず", "—", "—", "—"], None
        ps = doc["posts"]
        ts = sorted(p["create_time"] for p in ps if p.get("create_time"))
        days = max(1, (ts[-1] - ts[0]) / 86400) if len(ts) > 1 else 1
        per_month = len(ps) / days * 30
        vmed = med([p.get("views") for p in ps])
        smed = med([p.get("save_rate") for p in ps])
        top = max(ps, key=lambda p: p.get("views") or 0)
        cap = re.sub(r"\s+", " ", re.sub(r"[#@]\S+", "", top.get("caption") or "")).strip()
        cap = (cap[:16] + "…") if len(cap) > 17 else cap
        return [label, f"@{doc['handle']}", f"{len(ps)}本（月{per_month:.0f}本）", views_label(vmed), pct(smed, 2),
                f"{views_label(top.get('views'))}「{cap}」"], dict(n=len(ps), per_month=per_month, vmed=vmed, smed=smed)

    arows, astats, a_own = [], {}, None
    for x in info:
        b = x["b"]
        lab = short(b) + ("（貴社）" if b.get("own") else "")
        hs = b.get("official") or []
        if hs:
            for h in hs:
                r, st_ = acc_row(lab, h, account(h))
                arows.append(r)
                if st_:
                    astats[b["name"]] = st_
        elif b.get("own"):
            arows.append([lab, "無し" if b.get("official_status") == "none" else "未確認", "—", "—", "—", "—"])
        else:
            arows.append([lab, "無し" if b.get("official_status") == "none" else "未確認", "—", "—", "—", "—"])
        if b.get("own"):
            a_own = len(arows) - 1
        for rel in b.get("official_related") or []:
            r, _ = acc_row(f"（参考）{rel.get('label') or short(b)}", rel["handle"], account(rel["handle"]))
            arows.append(r)
    fetched = [h for x in info for h in (x["b"].get("official") or []) + [r["handle"] for r in x["b"].get("official_related") or []] if account(h)]
    if not fetched and any(x["b"].get("official") for x in info):
        # 取得をしていない（account_posts.py 未実行）。「未取得」だらけの表を客先に出さない
        out.append(dict(type="_warn", _first_only=True, text="公式アカウントの投稿を取っていないので「公式アカウント」のページを出さない（python ../tiktok-acquire/scripts/account_posts.py --case <案件>）"))
    elif fetched:
        own_has = bool(own["b"].get("official"))
        cst = [(k, v) for k, v in astats.items() if k != own["b"]["name"]]
        lead_a = max(cst, key=lambda kv: kv[1]["per_month"]) if cst else None
        lead_s = next((short(x["b"]) for x in info if lead_a and x["b"]["name"] == lead_a[0]), "")
        if not own_has and lead_a:
            head = f"{short(own['b'])}は公式TikTokが無く、{lead_s}は月{lead_a[1]['per_month']:.0f}本"
        elif own_has and own["b"]["name"] in astats and lead_a:
            head = f"{short(own['b'])}の公式は再生中央値{views_label(astats[own['b']['name']]['vmed'])}、{lead_s}は{views_label(lead_a[1]['vmed'])}"
        else:
            head = f"{short(own['b'])}と競合の公式TikTokの発信"
        sub = (f"{lead_s}の直近{lead_a[1]['n']}本：再生中央値{views_label(lead_a[1]['vmed'])}・保存率{pct(lead_a[1]['smed'], 2)}" if lead_a else "")
        t = g("official")
        out.append(dict(type="table", _id="official", _first_only=True,
                        kicker="各社の公式TikTokアカウントの直近の投稿（社名の検索とは別に、アカウントのページから取得）",
                        headline=t.get("headline", head), sub=t.get("sub", sub),
                        head=["社名", "公式アカウント", "直近の投稿", "再生 中央値", "保存率 中央値", "再生1位の投稿"], rows=arows,
                        align=["left", "left", "right", "right", "right", "left"], col_w=[3.3, 3.6, 2.6, 2.0, 2.2, 4.0],
                        emph_rows=[a_own] if a_own is not None else [], max_rows=8, keep_order=True,
                        note="公式アカウント：公式サイトのSNS一覧などで確かめたもの。未確認＝まだ見つけられていない。"
                             "直近の投稿：アカウントのページの新しい順に最大30本。月の本数＝本数÷最初と最後の投稿の間の日数×30"
                             + (f"。{own['b'].get('official_note')}" if own["b"].get("official_note") else "")))

    # ── ① 足りている・足りない
    share_n = {}
    for r in share_rows:
        for (k, bn), cell in zip(BRANDS, r[1:1 + len(BRANDS)]):
            m = re.match(r"\d+", str(cell))
            share_n[bn] = share_n.get(bn, 0) + (int(m.group(0)) if m else 0)
    mk = ((fv.get("pages") or {}).get("competitors") or {}).get("market") or {}
    rows, emph = [], []

    def judge(mine, best):
        if best <= 0:
            return "差なし（競合も0）"
        if mine <= 0:
            return "足りない（0）"
        return "足りている" if mine >= best * 0.8 else "少ない"

    def add(label, mine_txt, mine, best_x, best, best_txt):
        j = judge(mine, best)
        rows.append([label, mine_txt, f"{short(best_x['b'])} {best_txt}" if best_x else "—", j])
        if j.startswith("足りない") or j == "少ない":
            emph.append(len(rows) - 1)

    if comps:
        offs = [x for x in comps if x["b"].get("official")]
        o_own = own["b"].get("official") or []
        o_status = own["b"].get("official_status")
        rows.append(["TikTokの公式アカウント", "あり（" + "・".join("@" + h for h in o_own) + "）" if o_own else ("無し" if o_status == "none" else "未確認"),
                     f"{short(offs[0]['b'])}（@{offs[0]['b']['official'][0]}）" if offs else "—",
                     ("足りない（無し）" if offs else "差なし（競合も未確認）") if not o_own else "足りている"])
        if not o_own and offs:
            emph.append(len(rows) - 1)
        bo = max(comps, key=lambda x: x["c"]["official"])
        add("社名の検索に出る公式の投稿", f"{own['c']['official']}本", own["c"]["official"], bo, bo["c"]["official"], f"{bo['c']['official']}本")
        bp = max(comps, key=lambda x: x["c"]["pr"])
        add("社名の検索に出るPR・広告", f"{own['c']['pr']}本", own["c"]["pr"], bp, bp["c"]["pr"], f"{bp['c']['pr']}本")
        rate = lambda x: (x["c"]["creator"] + x["c"]["consumer"]) / x["judged"] if x["judged"] else 0  # noqa: E731
        bv = max(comps, key=rate)
        add("個人・クリエイターに語られている", f"{own['c']['creator'] + own['c']['consumer']}本／{own['judged']}本", rate(own), bv, rate(bv),
            f"{bv['c']['creator'] + bv['c']['consumer']}本／{bv['judged']}本")
        if share_n:
            bs_ = max(comps, key=lambda x: share_n.get(x["b"]["name"], 0))
            add("一般検索の上位に名前が出る", f"{share_n.get(own['b']['name'], 0)}本", share_n.get(own["b"]["name"], 0), bs_,
                share_n.get(bs_["b"]["name"], 0), f"{share_n.get(bs_['b']['name'], 0)}本")
        if mk.get("brands"):
            ob = next((x for x in mk["brands"] if x.get("own")), None)
            cb = max([x for x in mk["brands"] if not x.get("own") and not x.get("few")] or [None], key=lambda x: x["share"] if x else -1)
            if ob:
                j = "足りている" if ob.get("fit") else "ずれている"
                rows.append(["市場が保存する型に合う", f"{round(ob['share'] * 100)}%",
                             (f"{cb['short']} {round(cb['share'] * 100)}%" if cb else "—") + f"（市場 {round(mk['coverage'] * 100)}%）", j])
                if not ob.get("fit"):
                    emph.append(len(rows) - 1)
        lacks = [r[0] for i, r in enumerate(rows) if i in emph]
        short_name = {"TikTokの公式アカウント": "公式アカウント", "社名の検索に出る公式の投稿": "公式の投稿", "社名の検索に出るPR・広告": "PR",
                      "個人・クリエイターに語られている": "個人の発信", "一般検索の上位に名前が出る": "一般検索での名前"}
        ln = [short_name.get(x, "市場の型") for x in lacks]
        head = ("足りないのは" + "・".join(ln[:3])) if ln else f"{short(own['b'])}の発信は、競合と比べて足りている"
        oks = [short_name.get(r[0], "") for i, r in enumerate(rows) if i not in emph and r[3] == "足りている"]
        sub = (f"足りているのは{'・'.join(x for x in oks if x)}" if any(oks) else "")
        t = g("standing")
        out.append(dict(type="table", _id="standing", _first_only=True,
                        kicker=f"{short(own['b'])}と競合{len(comps)}社（社名で検索した上位{n_judged}本・一般検索の上位）",
                        headline=t.get("headline", head), sub=t.get("sub", sub),
                        head=["見るところ", short(own["b"]), "競合で最も多い社", "判定"], rows=rows,
                        align=["left", "left", "left", "left"], col_w=[6.2, 3.6, 4.9, 3.0], emph_rows=emph,
                        note="判定：貴社が競合の最多の8割以上＝足りている、0本＝足りない、それ以外＝少ない。市場が保存する型＝"
                        f"「{cfg['keywords'][0]['query']}」の保存上位の型に、社名で検索した投稿が入る割合" + (f"。公式アカウント：{own['b'].get('official_note')}" if own["b"].get("official_note") else "")))

    # ── ② 一般検索ワードごと：上位に出る動画と、再生・ENG率・保存の上位3本
    min_eng = rc.get("top_eng_min_views", rc.get("top_save_min_views", 20_000))
    kw_over = g("kw_pages", []) if isinstance(g("kw_pages", []), list) else []
    for i, k in enumerate(cfg["keywords"][:3]):
        q = k["query"]
        vs = next((vs for qq, kind, vs, _b in axis_videos if kind == "カテゴリ" and qq == q), [])
        if not vs:
            continue
        judged = [v for v in vs if any(ax["kind"] == "category" and ax["name"] == k["name"] and ax.get("relevance")
                                       for ax in (labels.get(v["id"]) or {}).get("axes", []))]
        rel = [v for v in judged if any(ax["kind"] == "category" and ax["name"] == k["name"] and ax.get("relevance") == "relevant"
                                        for ax in (labels.get(v["id"]) or {}).get("axes", []))]
        strip = []
        for r, v in enumerate(vs[:8], 1):
            s_ = v.get("stats") or {}
            strip.append(dict(video_id=v["id"], cover=f"assets/covers/{v['id']}.jpg", url=v.get("url"), rank=r,
                              views_label=views_label(s_.get("playCount")), is_pr=is_pr(v)))
        xs = [vrow(v["id"]) for v in rel if v["id"] in raw]
        cols = []
        for title, key, val, flt in (("再生の上位3本", lambda x: x["views"], lambda x: views_label(x["views"]) + "再生", lambda x: True),
                                     (f"ENG率の上位3本（{views_label(min_eng)}再生以上）", lambda x: x["eng"] or 0, lambda x: "ENG率 " + pct(x["eng"], 1), lambda x: x["views"] >= min_eng),
                                     ("保存数の上位3本", lambda x: (x["v"].get("stats") or {}).get("collectCount") or 0,
                                      lambda x: f"保存 {(x['v'].get('stats') or {}).get('collectCount') or 0:,}", lambda x: True)):
            top = sorted([x for x in xs if flt(x)], key=lambda x: -key(x))[:3]
            cols.append(dict(title=title, items=[dict(video_id=x["vid"], cover=f"assets/covers/{x['vid']}.jpg", url=x["v"].get("url"),
                                                     value=val(x), author=x["author"], angle=ANG_L.get((labels.get(x["vid"]) or {}).get("angle"), ""))
                                                for x in top]))
        ang = collections.Counter((labels.get(v["id"]) or {}).get("angle") for v in rel if (labels.get(v["id"]) or {}).get("angle") not in (None, "other", "unknown")).most_common(1)
        lab = k.get("label") or q
        if i == 0 and ((fv.get("pages") or {}).get("now") or {}).get("headline"):
            head, sub = fv["pages"]["now"]["headline"], fv["pages"]["now"].get("sub", "")
        else:
            head = f"「{lab}」の上位は「{ANG_L.get(ang[0][0], ang[0][0])}」が最多" if ang else f"「{lab}」の上位に出る動画"
            sub = f"関連{len(rel)}本中{ang[0][1]}本" if ang else f"判定した上位{len(judged)}本"
        ov = kw_over[i] if i < len(kw_over) and isinstance(kw_over[i], dict) else {}
        out.append(dict(type="kwpage", _id=f"kw_{i + 1}", _first_only=True, kicker=f"「{q}」で検索した上位{len(judged) or len(vs)}本",
                        headline=ov.get("headline", head), sub=ov.get("sub", sub), strip=strip, cols=cols,
                        note=f"上の列は検索画面の表示順（1〜8位）。下の3列は判定で関連と決めた{len(rel)}本の中の順位"))

    # ── 章扉（①〜⑤）。題と中身は原稿（first_part{n}_title / first_part{n}_items）で差し替えられる
    o = short(own["b"])
    parts = [
        ("fpart1", "PART 1　自社と競合の発信", f"{o}と競合は、TikTokで何を発信しているか",
         ["社名で検索すると、誰が語っているか", "競合のPR・公式アカウントは、何をやっているか", f"{o}に足りている発信・足りない発信"],
         "社名で検索した上位を1本ずつ判定し、公式・PR・個人の投稿に分けた"),
        ("fpart2", "PART 2　生活者の検索", f"生活者が「{cat_label}」で検索すると、何が出てくるか",
         ["一般検索の語ごとに、上位に出る・見られる・保存される動画", "一般検索での各社の名前の出方", "市場が保存する型と、指名検索のずれ"],
         "生活者が使う一般の検索語で、表示順のまま上位を取得した"),
        ("fpart4", "PART 4　興味を持たれる要素", "保存・反応される動画は、何でできているか",
         ["見せ方×広告配信の保存率", "再生・ENG率・保存の上位5本の共通点", "冒頭の秒単位フックと、伸びている型"],
         "上位の投稿を実際に見て、冒頭・見せ方・訴求に分けた"),
        ("fpart5", "PART 5　結論", f"{o}が作るべきコンテンツ",
         [f"保存される型×{o}の企画の種", "次回お持ちするもの"], "ここまでの差から、まず作る動画を決めた"),
    ]
    for pid, label, title, items, desc in parts:
        n = pid[-1]
        out.append(dict(type="part", _id=pid, _first_only=True, label=label, title=g(f"first_part{n}_title", title),
                        items=g(f"first_part{n}_items", items), desc=desc))
    return out


# 口コミに入っていないサイト（review-scraper が取らない理由）。営業が「楽天は入ってる？」「Amazonは？」と聞かれたときに答えられるように
REVIEW_NOT_INCLUDED = "Amazon・LIPS・Qoo10（自動での取得を断っているサイト）"   # 価格.com・マイベストは 2026-10-06 から取れる（承諾のある案件だけ）


def add_how(pages, ctx):
    """各ページのノートの先頭に「このページは何を見て、何を出しているか」を入れる（2026-10-06 打ち合わせ
    「スライドメモに、これは何をやってて何を出してるものです。質問された時もそれを見れば営業が答えられる」）"""
    c = ctx
    T_ = {
        "summary": ("この資料の各ページの結果", "結論を3つ。数字はそれぞれのページと同じ"),
        "voices": (f"TikTokで各社の名前（{c['brand_qs']}）を検索し、検索画面の表示順の上位を取得。1本ずつ画像と本文をAIが見て、"
                   "その社の商品が主役か・話の中で語られているか・カテゴリ外の話題で触れているかを判定した（判定の証拠を残している）",
                   "その社が語られている投稿を、投稿者の種類ごとに数えた本数。公式＝その社の公式アカウント、PR・広告＝#PR・#提供などの表記か広告配信の印がある投稿、"
                   "クリエイター＝フォロワー1万人以上、一般＝1万人未満"),
        "comp_pr": ("上と同じ社名の検索結果のうち、競合の公式アカウントの投稿とPR・広告の投稿",
                    "再生の多い順に5本と、社ごとの本数・多い訴求（訴求は決めた選択肢から1つ選ぶ判定）"),
        "official": ("各社の公式TikTokアカウントのページ（公式サイトのSNS一覧などで確かめたアカウントだけ）。新しい順に最大30本",
                     "投稿の本数と1か月あたりの本数、再生と保存率の中央値、いちばん再生された投稿"),
        "own": (f"「{c['own_q']}」で検索した上位の投稿を1本ずつ見て、中身を分けた", "中身の分類ごとの本数"),
        "standing": ("この章の前のページの数字（社名の検索・公式アカウント・一般検索での名前の出方・市場が保存する型）",
                     "貴社と、競合で最も多い社を並べた判定。貴社が最多の8割以上＝足りている、0本＝足りない、それ以外＝少ない"),
        "share": (f"一般の検索語（{c['kw_qs']}）ごとの上位30本の本文・ハッシュタグ・投稿者", "各社の名前（表記ゆれを含む）か公式アカウントが出た本数"),
        "fv_competitors": (f"「{c['primary']}」で保存数の多い上位の投稿の見せ方（型）と、社名で検索した投稿の見せ方",
                           "市場の上位に多い型に、各社の投稿が入る割合（点線＝市場の割合）"),
        "fv_now": (f"「{c['primary']}」でTikTokを検索した画面（ログインなし・並び替えなしの表示順）", "上位の投稿と、多い見せ方"),
        "ad": (f"すべての検索で関連と判定した投稿{c['n_rel']}本", "見せ方ごとの保存率の中央値を、広告配信の有無で分けて比べたもの（広告で伸ばした数字と混ぜないため）"),
        "top_views": (f"一般の検索語（{c['kw_qs']}）の上位で関連と判定した{c['n_cat']}本", "再生数の多い順に5本と、5本に共通する点（AIが動画を実際に見て書いた）"),
        "top_eng": (f"一般の検索語（{c['kw_qs']}）の上位で関連と判定した{c['n_cat']}本のうち{c['min_v']}再生以上",
                    "ENG率（いいね＋保存＋コメント＋シェア）÷再生の高い順に5本と、5本に共通する点"),
        "top_saves": (f"一般の検索語（{c['kw_qs']}）の上位で関連と判定した{c['n_cat']}本", "保存数の多い順に5本と、5本に共通する点"),
        "top_save": (f"一般の検索語（{c['kw_qs']}）の上位で関連と判定した{c['n_cat']}本のうち{c['min_v']}再生以上", "保存率の高い順に5本"),
        "patterns": (f"分析した{c['n_an']}本の動画（実際に取得してコマに分け、テロップと発話を書き起こしたもの）", "保存されている投稿に共通する作りの型（AIがコマを実際に見て分けた）"),
        "proposals": ("保存される型と、貴社に足りない発信", "貴社が作る動画の企画の種（仮説）と、参考にした投稿"),
        "fv_next": ("—", "次回お持ちするものと、教えていただきたいこと"),
        "fv_appendix": ("—", "調査の前提（取得日・判定のしかた・PRの判定・数字の定義）"),
        "entry": (f"分析した{c['n_an']}本の冒頭0〜3秒", "入り方の種類ごとの本数と、再生・保存率・ENG率の中央値"),
        "creator": (f"分析した{c['n_an']}本の投稿者", "保存率の高い順の投稿者と、冒頭の入り方・発信者のタイプ・フォロワー"),
        "tier": (f"関連と判定した投稿{c['n_rel']}本", "フォロワーの規模ごとの保存率（広告配信の有無で分けた）"),
        "diff": ("一般の検索語ごとの上位30本", "上位10本と11〜30位で、PR・再生・保存率・見せ方を比べたもの"),
    }
    rv = (f"{c['rv_src']}の口コミ{c['rv_n']:,}件を1件ずつ読んで判定した（入っていないサイト：{REVIEW_NOT_INCLUDED}）") if c.get("rv_n") else ""
    if rv:
        T_["rv_voice"] = (rv + "。良いと書いた点と不満を書いた点を、決めた分類から選んで分けた",
                          "分類ごとの件数と割合。赤い行＝強み（良いと書いた口コミが5件以上・15%以上で、不満の1.5倍以上）")
        T_["rv_shots"] = ("良い点の1位と不満の1位の口コミの、サイトの実際の画面（その口コミ1件の枠を撮ったもの。投稿者の名前は写していない）",
                          "引用した一文（黄色の線）と、押すと元の口コミが開くリンク。価格.com・@cosme は口コミ1件、ほかのサイトは一覧・商品ページが開く")
        T_["rv_comp"] = ("社名で検索した上位の、各社の公式・PRの投稿の訴求（判定の選択肢から1つ）と、各社の口コミの強み",
                         "社ごとの判定。合っている＝強みをPRで推している、アピールすべき＝強みなのにPRが無い、訴求を変えるべき＝PRで推しているのに口コミで評価が少ない")
        T_["rv_vs_pr"] = ("貴社の口コミの強みと、貴社・競合の公式・PRの投稿のうちその訴求の本数（個人の投稿は括弧）",
                          "強みごとの判定と、競合のPRに多い訴求・貴社の不満の1位。語れば伸びるとは断定しない")
    for k, what in (("years", "年ごとの件数"), ("effects", c.get("review_effect_how", "書かれている良さごとの件数と割合")), ("unsat", "書かれている不満ごとの件数"),
                    ("purchase", "買ったきっかけごとの件数"), ("scene", "使う場面・ブランドへの信頼が書かれた件数"),
                    ("review_reading1", "口コミから読み取れること"), ("review_reading2", "口コミから読み取れること"), ("reviews", "口コミの調査対象と件数")):
        if rv:
            T_[k] = (rv, what)
    for p in pages:
        pid = page_id(p)
        if pid.startswith("kw_") and p.get("type") == "kwpage":
            q = p.get("kicker", "").split("」")[0].lstrip("「")
            p["how"] = {"見ているもの": f"生活者が使う一般の検索語「{q}」でTikTokを検索した結果（ログインなし・並び替えなしの表示順）",
                        "出しているもの": "上の列＝検索画面の1〜8位。下の3列＝判定で関連と決めた投稿の中で、再生・ENG率（いいね＋保存＋コメント＋シェア）÷再生・保存数の上位3本"}
        elif pid.startswith("hook"):
            p["how"] = {"見ているもの": "上位から選んだ1本の動画を実際に取得し、冒頭を秒ごとのコマに分けてテロップと発話を書き起こしたもの",
                        "出しているもの": "最初の数秒で何を見せ、何と言っているか"}
        elif pid in T_ and T_[pid][1]:
            p["how"] = {"見ているもの": T_[pid][0], "出しているもの": T_[pid][1]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", required=True)
    ap.add_argument("--run", required=True)
    ap.add_argument("--reviews", help="口コミの収集・分類フォルダ。research.review_collect=trueなら必須。未回答の旧案件も明示指定で口コミありとして扱う")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--no-videos", action="store_true", help="個別投稿の構成分析（1本2枚）を外した本編だけの版を作る")
    ap.add_argument("--plain-name", action="store_true", help="--no-videos でもファイル名に「_本編」を付けない（3つだけ作るときの提案版）")
    ap.add_argument("--out", default="research.json")
    ap.add_argument("--skin", help="外側の見た目（FMT）。既定は元のFMT（@deepdive）。@vector のようにキット同梱の名前か、案件フォルダからの skin.json。"
                                   "none で明朝の話す資料（2026-10-06 までの既定）。原稿（synthesis.json）の skin でも指定できる")
    ap.add_argument("--part", choices=["all", "first", "concrete"], default="all",
                    help="first＝初訪版（現状・発見・企画の種・次回）、concrete＝具体提案版（口コミ・保存される型・競合差・台本・進め方）。既定 all は統合版")
    ap.add_argument("--selection", help="分析した動画の一覧（id を持つ JSON 配列）。既定は <run>/selection.json、無ければ <案件>/../video30_candidates.json")
    a = ap.parse_args()
    C, R = (os.path.abspath(os.path.expanduser(x)) for x in (a.case, a.run))
    cfg = read_json(os.path.join(C, "case.json"))
    review_collect = resolve_review_collect(cfg, bool(a.reviews))
    RV = os.path.abspath(os.path.expanduser(a.reviews)) if review_collect else os.path.join(C, "_no_reviews")
    fv = read_json(os.path.join(C, "first_visit.json"))
    rcfg = cfg.get("research") or {}
    spec_p = rcfg.get("review_spec")
    if spec_p and re.fullmatch(r"@[\w-]+", str(spec_p)):   # キット同梱の分類表（@card → references/research/review_spec_card.json）
        spec_p = os.path.join(HERE, "..", "references", "research", f"review_spec_{spec_p[1:]}.json")
    spec_p = os.path.join(C, spec_p) if spec_p and not os.path.isabs(spec_p) else (spec_p or DEFAULT_REVIEW_SPEC)
    spec = jl(spec_p)
    global EFFECT_JA, UNSAT_JA, PURCHASE_JA, SCENE_JA, BRANDS
    EFFECT_JA, UNSAT_JA, PURCHASE_JA, SCENE_JA = spec["effects"], spec["unsatisfied"], spec["purchase"], spec["scene"]
    NOUN = spec.get("product_noun") or "商品"
    # effects の意味は分類表で決める。カード・器具は良悪双方の言及、
    # 従来のヘアケアは基本的に良さ（香りなど both_directions は別表示）。
    effects_semantics = spec.get("effects_semantics", "positive")
    if effects_semantics not in ("positive", "mentions"):
        raise InputGateError("口コミの分類表 effects_semantics は positive または mentions を指定する")
    effects_mentions = effects_semantics == "mentions"
    effects_title = "口コミで言及された観点" if effects_mentions else f"何に良い{NOUN}だと思われているか"
    effects_head = "言及された観点（件数・割合）" if effects_mentions else "書かれている良さ（件数・割合）"
    effects_note = "良い点・不満の両方の言及。満足の割合とは異なる" if effects_mentions else ""
    BRANDS = [(b.get("review_key") or re.sub(r"\W+", "_", b["name"]).strip("_"), b["name"]) for b in cfg["brands"]]
    own_b = next((b for b in cfg["brands"] if b.get("own")), cfg["brands"][0])
    OWN = own_b.get("short") or own_b["name"]
    PRIMARY = next((k["query"] for k in cfg["keywords"] if k.get("primary")), cfg["keywords"][0]["query"])
    ACQ = cfg.get("acquired_on") or (fv.get("project") or {}).get("acquired_on") or ""
    rc = rcfg
    apply_research_config(rcfg, cfg, C)
    own_s, cat_name, acq = OWN, PRIMARY, ACQ
    syn_p = os.path.join(C, "authored", "synthesis.json")
    S = jl(syn_p) if os.path.exists(syn_p) else {}
    def g(k, d=None):
        value = S.get(k, d if d is not None else {})
        if k in {"summary", "proposals"} and a.part != "all" and isinstance(value, dict):
            override = S.get(f"{k}_{a.part}")
            if isinstance(override, dict):
                value = {**value, **override}
        return value
    missing = []

    raw, axis_videos = {}, []
    axes = [(k["query"], k["file"], "カテゴリ", None) for k in cfg["keywords"]] + \
           [(b["query"], b["file"], "貴社" if b.get("own") else "競合", b) for b in cfg["brands"]]
    for q, f, kind, b in axes:
        vs = jl(os.path.join(C, f))["videos"]
        axis_videos.append((q, kind, vs, b))
        for v in vs:
            raw.setdefault(v["id"], v)
    labels = {p["video_id"]: p for p in jl(os.path.join(C, "labels.json"))["posts"]}
    sel_p = a.selection or next((p for p in (os.path.join(R, "selection.json"), os.path.join(os.path.dirname(C), "video30_candidates.json"))
                                if os.path.exists(p)), None)
    validated = validate_research_inputs(case_dir=C, run_dir=R, cfg=cfg, raw=raw, labels=labels,
                                        synthesis=S, selection_path=sel_p, reviews_dir=RV,
                                        explicit_reviews=bool(a.reviews), part=a.part, review_spec=spec)
    sel, anat, page = validated["selection"], validated["anatomy"], validated["page"]
    zero_reviews = validated["review_observation"] if validated["review_observation"] and validated["review_observation"]["status"] == "observed_zero" else None
    # 投稿の訴求の判定し直し（appeal_overrides.json：{video_id: {appeal, why, seen}}）。labels.json の判定（一覧シートのコードで確定）
    # は書き換えず、語彙に無い訴求（research.appeal_extra のデザイン・決済など）を足すときに使う（2026-10-06）
    _ov_p = os.path.join(C, "appeal_overrides.json")
    if os.path.exists(_ov_p):
        for vid, ov in jl(_ov_p).items():
            if vid in labels and ov.get("appeal"):
                labels[vid] = dict(labels[vid], appeal=ov["appeal"], appeal_overridden=True)
    official = {}
    for b in cfg["brands"]:
        for oid in b.get("official") or []:
            official[oid.lower()] = b["name"]

    # ── 検索面の全体像
    ov_rows = []
    for q, kind, vs, _b in axis_videos:
        rs = [rates(v) for v in vs]
        ov_rows.append([f"{kind}｜{q}", f"{sum(is_pr(v) for v in vs)} / {len(vs)}",
                        pct(med([r[0] for r in rs if r[0] is not None])), pct(med([r[1] for r in rs if r[1] is not None])),
                        med_label([(v.get('stats') or {}).get('playCount') for v in vs]),
                        f"{sum(1 for v in vs if ((v.get('author') or {}).get('followerCount') or 0) < 10_000)} / {len(vs)}"])

    cat_axes = [(q, vs) for q, kind, vs, _b in axis_videos if kind == "カテゴリ"]
    # ── 露出シェア（カテゴリ語の上位30本に、本文・タグで名前が出る投稿／公式アカウントの投稿）
    share_rows = []
    # 5社以外で名前を数えたいブランド（case.json の research.other_brands＝{表示名: 正規表現}）
    others_pat = rcfg.get("other_brands") or {}
    bmap = {b["name"]: b for b in cfg["brands"]}

    def named(v, b):
        uid = ((v.get("author") or {}).get("uniqueId") or "").lower()
        off = official.get(uid) == b["name"]
        return off or bool(re.search(b["match"], txt(v), re.I)), off

    for q, vs in cat_axes:
        top = vs[:30]
        cells = [q]
        for _k, bn in BRANDS:
            hits = [named(v, bmap[bn]) for v in top]
            n, off = sum(h[0] for h in hits), sum(h[1] for h in hits)
            cells.append(f"{n}" + (f"（公式{off}）" if off else ""))
        oth = collections.Counter()
        for v in top:
            for nm, pat in others_pat.items():
                if re.search(pat, txt(v), re.I):
                    oth[nm] += 1
        cells.append("・".join(f"{k} {c}" for k, c in oth.most_common(3)) or "—")
        share_rows.append(cells)
    # 紙面の大きな数字：自社の名前が出た本数／カテゴリ上位の総数
    own_names = [bn for _k, bn in BRANDS if bmap[bn].get("own")]
    share_tot = sum(len(vs[:30]) for _q, vs in cat_axes)
    share_own = sum(named(v, bmap[own_names[0]])[0] for _q, vs in cat_axes for v in vs[:30]) if own_names else 0
    share_big = dict(value=f"{share_own}/{share_tot}", label=f"カテゴリ上位{share_tot}本のうち、{own_names[0] if own_names else '自社'}の名前が出た本数") if own_names and share_tot else None

    # ── 上位10本の見せ方・ハッシュタグ ／ 上位 vs 下位
    mix_rows, diff_rows = [], []
    REL_OUT = {"off_category": rc.get("off_category_label", "カテゴリ外"), "irrelevant": "無関係", "other_brand": "他社の商品", "unsure": "判定不可"}

    def angle_of(v, q):
        """その検索面で関連と確定した投稿だけ見せ方を数える。関連でない投稿は理由（カテゴリ外など）で数える"""
        p = labels.get(v["id"]) or {}
        kname = next((k["name"] for k in cfg["keywords"] if k["query"] == q), q)
        ax = next((a for a in p.get("axes", []) if a["kind"] == "category" and a["name"] == kname), None)
        if ax and ax.get("relevance") and ax["relevance"] != "relevant":
            return REL_OUT.get(ax["relevance"], "—")
        return ANGLE_JA.get(p.get("angle") or "unknown", "—")

    for q, vs in cat_axes:
        top10, rest = vs[:10], vs[10:30]
        am = collections.Counter(angle_of(v, q) for v in top10)
        ht = collections.Counter(h.lower() for v in vs[:30] for h in (v.get("hashtags") or []) if h.lower() not in ("fyp", "おすすめ", "おすすめにのりたい"))
        mix_rows.append([q, "・".join(f"{k}{c}" for k, c in am.most_common()), " ".join(f"#{k}（{c}）" for k, c in ht.most_common(6))])
        for name, grp in (("上位10本", top10), ("11〜30位", rest)):
            rs = [rates(v) for v in grp]
            am2 = collections.Counter(angle_of(v, q) for v in grp)
            diff_rows.append([f"{q}｜{name}", f"{sum(is_pr(v) for v in grp)} / {len(grp)}",
                              med_label([(v.get('stats') or {}).get('playCount') for v in grp]),
                              pct(med([r[0] for r in rs if r[0] is not None])), pct(med([r[1] for r in rs if r[1] is not None])),
                              "・".join(f"{k}{c}" for k, c in am2.most_common(2)),
                              med_label([(v.get('author') or {}).get('followerCount') or 0 for v in grp])])

    # ── 投稿者の内訳（関連と確定した投稿・窓内）
    poster_rows = []
    for q, kind, vs, b in axis_videos:
        axname = ("category", next(k["name"] for k in cfg["keywords"] if k["query"] == q)) if b is None else \
                 ("own" if b.get("own") else "competitor", b["name"])
        cnt = collections.Counter(p.get("poster") for p in labels.values() for ax in p["axes"]
                                  if (ax["kind"], ax["name"]) == axname and ax.get("in_window") and ax.get("relevance") == "relevant")
        poster_rows.append([f"{kind}｜{q}", str(sum(cnt.values()))] + [str(cnt.get(k, 0)) for k in ("official", "creator_pr", "creator", "consumer")])

    # ── 動画の判定（30本）
    # 選定・DL・コマ・判定・紙面原稿・統合原稿は副作用の前に共通ゲートで検証済み。

    def vrow(vid):
        v = raw[vid]
        s = v.get("stats") or {}
        sv, eng = rates(v)
        return dict(vid=vid, v=v, views=s.get("playCount") or 0, sv=sv, eng=eng, pr=is_pr(v), ad=v.get("isAd") is True,
                    shown=any(b in ("tag", "body") for b in pr_basis(v)),
                    fol=(v.get("author") or {}).get("followerCount") or 0, author=(v.get("author") or {}).get("uniqueId"))

    analysed = [vrow(r["id"]) for r in sel if r["id"] in anat]
    def entry_of(x):
        e = anat[x["vid"]]["entry"]
        if e == "other" and (labels.get(x["vid"]) or {}).get("angle") in ("ranking", "compare"):
            return "rank"
        return e

    def agg(grp, label):
        # 最後の列は「視聴者に見える表記（#PR等のタグ・本文の提供表記）」の本数。広告フラグだけのものは数えない
        return [label, str(len(grp)), med_label([x['views'] for x in grp]), pct(med([x['sv'] for x in grp]), 3),
                pct(med([x['eng'] for x in grp])), str(sum(x['shown'] for x in grp))]

    # 選び方に左右されない比較：判定済みの関連投稿（全検索の判定窓）を広告配信の有無×見せ方で
    rel_ids = [p["video_id"] for p in labels.values() if any(ax.get("relevance") == "relevant" and ax.get("in_window") for ax in p["axes"])]
    relx = [vrow(i) for i in rel_ids if i in raw]
    # 見せ方×広告配信（同じ見せ方どうしで配信の有無を比べる。見せ方の構成の違いを配信の差と取り違えないため）
    ANG = ANG_ORDER or [("ranking", "ランキング"), ("compare", "比較"), ("review", "レビュー"), ("talk", "解説"),
           ("beforeafter", "ビフォアフ"), ("newlist", "新作"), ("other", "その他")]
    ang_of = lambda x: (labels.get(x["vid"]) or {}).get("angle")

    def cell2(grp):
        return [str(len(grp)), pct(med([x["sv"] for x in grp]), 3) if grp else "—"]
    ad_rows = []
    rk_all = [x for x in relx if ang_of(x) in ("ranking", "compare")]
    ot_all = [x for x in relx if ang_of(x) not in ("ranking", "compare")]
    ad_rows.append([f"{rc.get('rank_group_label', 'ランキング・比較')}（計）"] + cell2([x for x in rk_all if not x["ad"]]) + cell2([x for x in rk_all if x["ad"]]))
    ad_rows.append(["それ以外（計）"] + cell2([x for x in ot_all if not x["ad"]]) + cell2([x for x in ot_all if x["ad"]]))
    for a_, lab in ANG:
        grp = [x for x in relx if ang_of(x) == a_]
        if grp:
            ad_rows.append([f"　{lab}"] + cell2([x for x in grp if not x["ad"]]) + cell2([x for x in grp if x["ad"]]))
    grp = [x for x in relx if not x["ad"] and x["shown"]]
    ad_rows.append(["（参考）配信なしで PR・提供の表記あり"] + cell2(grp) + ["", ""])
    # 紙面は棒グラフで見せる（表は話す人のノートへ）。広告配信なし・3本以上の見せ方だけ、保存率の高い順に6つまで
    ad_bars = []
    for a_, lab in ANG:
        grp = [x for x in relx if ang_of(x) == a_ and not x["ad"]]
        if len(grp) >= 3 and a_ != "other":
            ad_bars.append(dict(label=lab, value=round(med([x["sv"] for x in grp]) * 100, 3), text=pct(med([x["sv"] for x in grp]), 2), sub=f"{len(grp)}本"))
    ad_bars = sorted(ad_bars, key=lambda b: -b["value"])[:6]
    for i, b in enumerate(ad_bars):
        b["emph"] = i == 0
    rk = [x for x in relx if not x["ad"] and (labels.get(x["vid"]) or {}).get("angle") in ("ranking", "compare")]
    ot = [x for x in relx if not x["ad"] and (labels.get(x["vid"]) or {}).get("angle") not in ("ranking", "compare")]
    ad_stats = dict(n=len(relx), ad=len([x for x in relx if x["ad"]]), rank_sv=med([x["sv"] for x in rk]), other_sv=med([x["sv"] for x in ot]),
                    ad_sv=med([x["sv"] for x in relx if x["ad"]]), noad_sv=med([x["sv"] for x in relx if not x["ad"]]))

    ENTRY_LAB = {**ENTRY_JA, "rank": rc.get("rank_entry_label", "格付け・一覧入り")}
    by_entry = collections.defaultdict(list)
    for x in analysed:
        by_entry[entry_of(x)].append(x)
    # 広告配信の投稿が無い案件もある（HARIO: 0本）。空の区分は行を出さない
    entry_rows = [agg(grp, f"分析{len(analysed)}本｜広告配信{lab}") for lab, grp in
                  (("あり", [x for x in analysed if x["ad"]]), ("なし", [x for x in analysed if not x["ad"]])) if grp]
    for e in ["rank"] + ENTRY_ORDER:
        grp = [x for x in by_entry.get(e, []) if not x["ad"]]
        if grp:
            entry_rows.append(agg(grp, f"　配信なし｜{ENTRY_LAB[e]}"))

    creator_rows = []
    for x in sorted(analysed, key=lambda x: -(x["sv"] or 0)):
        an, pg = anat[x["vid"]], page.get(x["vid"], {})
        tier = next(t for t, lo, hi in TIERS if lo <= x["fol"] < hi)
        creator_rows.append([f"@{x['author']}", ENTRY_LAB.get(entry_of(x)), pg.get("creator_type_short") or an.get("creator_type", "—"),
                             f"{x['fol']:,}", tier.split("（")[0], views_label(x["views"]), pct(x["sv"], 3),
                             "広告" if x["ad"] else ("PR" if x["pr"] else "")])
    tier_rows = []
    for t, lo, hi in TIERS:
        na = [x for x in relx if lo <= x["fol"] < hi and not x["ad"]]
        ya = [x for x in relx if lo <= x["fol"] < hi and x["ad"]]
        if na or ya:
            tier_rows.append([t, str(len(na)), pct(med([x['sv'] for x in na]), 3) if na else "—", f"{med([x['views'] for x in na]):,.0f}" if na else "—",
                              str(len(ya)), pct(med([x['sv'] for x in ya]), 3) if ya else "—"])

    # ── TOP5（カテゴリ3面で関連と確定した投稿の和集合）
    cat_ids = {p["video_id"] for p in labels.values() if any(ax["kind"] == "category" and ax.get("relevance") == "relevant" for ax in p["axes"])}
    cat = [vrow(i) for i in cat_ids if i in raw]

    def dur_label(sec):
        try:
            sec = int(round(float(sec)))
        except (TypeError, ValueError):
            return "-"
        return f"{sec // 60}分{sec % 60:02d}秒" if sec >= 60 else f"{sec}秒"

    def card(x, value_label, unit, first=("再生", "いいね"), full=False):
        """上位5本のカード。既定は stats の先頭2つ（first の順）だけ紙面に。full=True は参考資料（冷凍食品 コンビニ TOP5）と同じく
        表示名・その他の数字すべて・投稿日｜尺を紙面に出す（2026-10-05 本人「こうゆう項目を入れたい」）"""
        v = x["v"]
        s = v.get("stats") or {}
        ct = dt.datetime.fromtimestamp(v.get("createTime") or 0).strftime("%Y/%m/%d")
        allst = {"再生": f"{x['views']:,}", "いいね": f"{s.get('diggCount') or 0:,}", "コメント": f"{s.get('commentCount') or 0:,}",
                 "シェア": f"{s.get('shareCount') or 0:,}", "保存": f"{s.get('collectCount') or 0:,}", "保存率": pct(x["sv"], 2), "ENG率": pct(x["eng"], 2)}
        order = list(first) + [k for k in allst if k not in first]
        if full:
            allst = {k: allst[k] for k in ("再生", "いいね", "コメント", "シェア", "保存")}
            order = list(allst)
        return dict(video_id=x["vid"], url=v.get("url"), cover=f"assets/covers/{x['vid']}.jpg", author=x["author"],
                    display_name=(v.get("author") or {}).get("nickname") or x["author"],
                    followers_label=views_label(x["fol"]), value_label=value_label, value_unit=unit, is_pr=x["pr"],
                    stats=[[k, allst[k]] for k in order if k != unit and not (unit == "保存数" and k == "保存")],
                    full_stats=full, posted=f"{ct} 投稿｜尺 {dur_label(v.get('duration'))}",
                    meta=f"{ct} 投稿｜尺 {dur_label(v.get('duration'))}｜{'広告配信あり' if x['ad'] else '広告配信なし'}\n{short_url(v.get('url'))}")
    top_views = sorted(cat, key=lambda x: -x["views"])[:5]
    top_save = sorted([x for x in cat if x["views"] >= rc.get("top_save_min_views", 20_000)], key=lambda x: -(x["sv"] or 0))[:5]
    # ENG率＝（いいね＋保存＋コメント＋シェア）÷再生。再生の少ない投稿で率だけ跳ねないよう、保存率と同じ下限をかける（2026-10-02 追加）
    # 保存数（件数）の上位5本（参考資料 冷凍食品 コンビニ TOP5 の③）
    top_saves = sorted(cat, key=lambda x: -((x["v"].get("stats") or {}).get("collectCount") or 0))[:5]
    top_eng = sorted([x for x in cat if x["views"] >= rc.get("top_eng_min_views", rc.get("top_save_min_views", 20_000))], key=lambda x: -(x["eng"] or 0))[:5]

    # ── 指名検索（貴社軸）
    own_counts = collections.Counter()
    for p in labels.values():
        for ax in p["axes"]:
            if ax["kind"] == "own" and ax.get("in_window"):
                own_counts[ax.get("relevance")] += 1

    # ── 口コミ
    rv = [json.loads(l) for l in open(os.path.join(RV, "reviews.jsonl"), encoding="utf-8")] if os.path.exists(os.path.join(RV, "reviews.jsonl")) else []
    rv_by = {(r["review_id"], r["product_id"]): r for r in rv}
    rl = collections.defaultdict(list)
    # A verified zero result has no reviews to classify. Historical labels left
    # in the directory must never create fictitious nonzero review statistics.
    for f in (glob.glob(os.path.join(RV, "labels", "*.jsonl")) if rv else []):
        stem = os.path.basename(f)[:-6]
        key = next((k for k, _bn in BRANDS if stem.startswith(k)), stem)
        for line in open(f, encoding="utf-8"):
            if line.strip():
                rl[key].append(json.loads(line))
    if rv and not rl:
        if a.reviews:
            missing.append("口コミの判定が無い（labels/*.jsonl）")
    # 同じ口コミが別ストアの商品ページにも載る（Yahoo!）。件数は (サイト, 口コミID) で1件に数える
    for key in list(rl):
        seen_r, uniq = set(), []
        for l in rl[key]:
            k2 = (l.get("site"), l["review_id"])
            if k2 not in seen_r:
                seen_r.add(k2)
                uniq.append(l)
        rl[key] = uniq
    n_dup = len(rv) - len({(r.get("site"), r["review_id"]) for r in rv})
    rv_uniq = len(rv) - n_dup
    summ = {}
    if os.path.exists(os.path.join(RV, "acquire_log.json")):
        for pr in jl(os.path.join(RV, "acquire_log.json")).get("products", []):
            summ[pr.get("product_id") or pr.get("id")] = pr
    brand_short = {k: (bmap[bn].get("short") or bn) for k, bn in BRANDS}
    review_sites = list(rc.get("review_sites") or ["cosme", "rakuten"])
    # サイトに出ていた口コミの総数（reviews/summary.md の「取得 / サイト表示」）。商品名で product_id に対応づける
    site_total = {}
    sp = os.path.join(RV, "summary.md")
    if os.path.exists(sp):
        name2pid = {(r["site"], r["product_name"]): r["product_id"] for r in rv}
        for line in open(sp, encoding="utf-8"):
            m = re.match(r"\|\s*(楽天市場|@cosme|Yahoo!ショッピング)\s*\|\s*(.+?)\s*\|\s*(\d+)\s*/\s*(\d+)\s*\|", line)
            if not m:
                continue
            site = {"楽天市場": "rakuten", "@cosme": "cosme", "Yahoo!ショッピング": "yahoo"}[m.group(1)]
            nm = m.group(2).replace("\\|", "|")
            pid = next((pid for (st, pn), pid in name2pid.items() if st == site and pn.strip() == nm.strip()), None)
            if pid:
                site_total[(site, pid)] = int(m.group(4))
    rv_rows, eff_rows, unsat_rows, purch_rows, scene_rows = [], [], [], [], []
    rv_stats = {}
    for key, bn in BRANDS:
        short = brand_short[key]
        ls = rl.get(key, [])
        n = len(ls)
        if not n:
            continue
        sites = collections.Counter(l.get("site") for l in ls)
        ratings = collections.defaultdict(list)
        for l in ls:
            r0 = rv_by.get((l["review_id"], l.get("product_id")))
            rt = (r0 or {}).get("rating_5", (r0 or {}).get("rating"))
            if rt is not None:
                ratings[r0["site"]].append(float(rt))
        gift = sum(1 for l in ls if l.get("gift_or_pr"))
        c_eff = collections.Counter(e for l in ls for e in (l.get("effects") or []))
        c_uns = collections.Counter(e for l in ls for e in (l.get("unsatisfied") or []))
        c_pur = collections.Counter(e for l in ls for e in (l.get("purchase") or []))
        c_sce = collections.Counter(e for l in ls for e in (l.get("scene") or []))
        trust = sum(1 for l in ls if l.get("brand_trust"))
        rv_stats[key] = dict(n=n, sites=dict(sites), gift=gift, eff=c_eff, uns=c_uns, pur=c_pur, sce=c_sce, trust=trust,
                             rating={s: round(sum(v) / len(v), 2) for s, v in ratings.items()})
        buy = [l for l in ls if (rv_by.get((l["review_id"], l.get("product_id"))) or {}).get("purchase") == "購入品"]
        brt = [float(rv_by[(l["review_id"], l["product_id"])]["rating_5"]) for l in buy if rv_by[(l["review_id"], l["product_id"])].get("rating_5") is not None]
        rv_stats[key]["buy_n"] = len(buy)
        rv_stats[key]["buy_rating"] = round(sum(brt) / len(brt), 2) if brt else None
        rv_stats[key]["buy_unsat"] = sum(1 for l in buy if l.get("unsatisfied"))
        rv_stats[key]["unsat_all"] = sum(1 for l in ls if l.get("unsatisfied"))
        rv_stats[key]["sat"] = collections.Counter(e for l in ls for e in (l.get("satisfied") or []))
        cos = [rv_by[(l["review_id"], l["product_id"])] for l in ls if l.get("site") == "cosme"]
        dates = sorted((r0.get("posted_at") or "")[:7] for r0 in cos if r0.get("posted_at"))
        rv_stats[key]["cos_years"] = collections.Counter((r0.get("posted_at") or "")[:4] for r0 in cos if r0.get("posted_at"))
        pids = {(l.get("site"), l.get("product_id")) for l in ls}
        tot = {st: sum(site_total.get((st2, pid), 0) for st2, pid in pids if st2 == st) for st in ("rakuten", "cosme")}
        rv_stats[key]["site_total"] = tot
        rk_full = tot["rakuten"] and tot["rakuten"] == sites.get("rakuten", 0)
        if "cosme" in review_sites:
            rv_rows.append([short, f"{tot['rakuten']:,}／{tot['cosme']:,}", f"{sites.get('rakuten', 0)}／{sites.get('cosme', 0)}",
                            f"{rv_stats[key]['rating'].get('rakuten', 0):.2f}" if rk_full else "—（先頭200件）",
                            f"{rv_stats[key]['rating'].get('cosme', 0):.2f}" if rv_stats[key]["rating"].get("cosme") else "—",
                            f"{rv_stats[key]['buy_rating']:.2f}（{len(buy)}件）" if brt else "—",
                            f"{dates[0].replace('-', '/')}〜{dates[-1].replace('-', '/')}" if dates else "—"])
        else:
            rv_rows.append([short] + [str(sites.get(sk, 0)) for sk in review_sites] + [str(n),
                            "／".join(f"{SITE_JA.get(sk, sk)} {rv_stats[key]['rating'][sk]:.2f}" for sk in review_sites if sk in rv_stats[key]["rating"]) or "—",
                            f"{rv_stats[key]['unsat_all']}／{n}（{rv_stats[key]['unsat_all'] / n:.0%}）"])
    eff_ids = [e for e in EFFECT_JA if any(rv_stats[k]["eff"].get(e) for k in rv_stats)]
    cell = lambda c, k: f"{c}（{c / rv_stats[k]['n']:.0%}）"
    for e in eff_ids:
        both = e in (spec.get("both_directions") or [])
        lab = f"{EFFECT_JA[e]}（言及。良い・悪いの両方）" if both else EFFECT_JA[e]
        eff_rows.append([lab] + [cell(rv_stats[k]["eff"].get(e, 0), k) if k in rv_stats else "—" for k, _bn in BRANDS])
        if both:
            eff_rows.append([f"　うち{EFFECT_JA[e]}が良いと書かれたもの"] + [cell(rv_stats[k]["sat"].get(e, 0), k) if k in rv_stats else "—" for k, _bn in BRANDS])
    # 言及型の分類は同じ観点IDを良さ・不満の両方で使う。
    # 追加の不満IDだけを数えると、会員サイトや使い勝手などが抜ける。
    unsat_labels = {**EFFECT_JA, **UNSAT_JA} if effects_mentions else UNSAT_JA
    for e in unsat_labels:
        if any(rv_stats[k]["uns"].get(e) for k in rv_stats):
            unsat_rows.append([unsat_labels[e]] + [str(rv_stats[k]["uns"].get(e, 0)) if k in rv_stats else "—" for k, _bn in BRANDS])
    years = sorted({y for k in rv_stats for y in rv_stats[k]["cos_years"] if y})
    year_rows = []
    for y in years:
        year_rows.append([f"{y}年"] + [str(rv_stats[k]["cos_years"].get(y, 0)) if k in rv_stats else "—" for k, _bn in BRANDS])
    for e in PURCHASE_JA:
        if any(rv_stats[k]["pur"].get(e) for k in rv_stats):
            purch_rows.append([PURCHASE_JA[e]] + [str(rv_stats[k]["pur"].get(e, 0)) if k in rv_stats else "—" for k, _bn in BRANDS])
    for e in SCENE_JA:
        if any(rv_stats[k]["sce"].get(e) for k in rv_stats):
            scene_rows.append([SCENE_JA[e]] + [str(rv_stats[k]["sce"].get(e, 0)) if k in rv_stats else "—" for k, _bn in BRANDS])

    # ── 競合差の詳細
    comp_rows = []
    cat_den = sum(len(cv[:30]) for _q, cv in cat_axes)
    for key, bn in BRANDS:
        b = bmap[bn]
        rel = sum(1 for p in labels.values() for ax in p["axes"] if ax["name"] == bn and ax.get("in_window") and ax.get("relevance") == "relevant")
        win = sum(1 for p in labels.values() for ax in p["axes"] if ax["name"] == bn and ax.get("in_window"))
        vs = next(v for _q, _kind, v, bb in axis_videos if bb is b)
        catn = sum(1 for _q, cv in cat_axes for v in cv[:30] if named(v, b)[0])
        ents = collections.Counter(ENTRY_LAB[entry_of(x)] for x in analysed if named(x["v"], b)[0])
        st_ = rv_stats.get(key)
        top_eff = "・".join(f"{EFFECT_JA[e].split('（')[0]} {c / st_['n']:.0%}" for e, c in [x for x in st_["eff"].most_common() if x[0] not in (spec.get("both_directions") or [])][:2]) if st_ else "—"
        comp_rows.append([b.get("short") or bn, f"{catn} / {cat_den}", f"{rel} / {win}", f"{sum(is_pr(v) for v in vs)} / {len(vs)}",
                          pct(med([rates(v)[0] for v in vs if rates(v)[0] is not None]), 2),
                          "・".join(f"{k}{c}" for k, c in ents.most_common()) or "—", top_eff])

    # ── 動画ページ（保存率順）とコマの写し
    def copy_frame(src_rel, vid):
        src = src_rel if os.path.isabs(src_rel) else os.path.join(R, src_rel)
        if not os.path.exists(src):
            missing.append(f"コマが無い: {src}")
            return None
        dst_rel = f"assets/frames/{vid}/{os.path.basename(src)}"
        if not a.check:
            os.makedirs(os.path.join(C, os.path.dirname(dst_rel)), exist_ok=True)
            shutil.copy2(src, os.path.join(C, dst_rel))
        return dst_rel

    video_pages = []
    order = sorted(analysed, key=lambda x: -(x["sv"] or 0))
    for i, x in enumerate(order, 1):
        an, pg = anat[x["vid"]], page.get(x["vid"], {})
        frames = []
        for fr in an.get("frames", [])[:5]:
            rel = copy_frame(fr["file"], x["vid"])
            if rel:
                no = re.sub(r"\D", "", os.path.basename(fr["file"])).lstrip("0") or "0"
                frames.append(dict(label_no=no.zfill(2), path=rel, caption=fr.get("caption", "")))
        v = x["v"]
        desc = re.sub(r"\s+", " ", v.get("desc") or "").strip()
        quote = f"「{desc[:26]}…」" if len(desc) > 26 else (f"「{desc}」" if desc else "")
        video_pages.append(dict(
            type="video", no=i, total=len(order), entry=ENTRY_LAB.get(entry_of(x)), author=x["author"], video_id=x["vid"], url=v.get("url"),
            headline=(pg.get("headline") or an.get("headline", "")).rstrip("。"),
            meta=f"{quote}　保存率{pct(x['sv'], 3)}・フォロワー{x['fol']:,}・{'広告配信あり' if x['ad'] else ('PR表記あり・広告配信なし' if x['pr'] else 'PR表記なし・広告配信なし')}・{pg.get('creator_type_short') or ''}",
            kpis=[["再生", views_label(x["views"])], ["保存率", pct(x["sv"], 3)], ["ENG率", pct(x["eng"])]],
            lead_image=frames[0]["path"] if frames else f"assets/covers/{x['vid']}.jpg",
            axes=pg.get("axes") or an.get("axes", {}), essence=pg.get("essence") or an.get("essence", ""), frames=frames,
            frames_note="5コマで見る「どう始まり、何を見せ、どう終わるか」。番号は抜き出したコマの通し番号",
            story=pg.get("story") or an.get("story", ""), cta=pg.get("cta") or an.get("cta", ""), observed=an.get("observed", "")))

    # ── 秒単位フック（synthesis の hooks[]。コマは run-dir から写す）
    hook_pages = []
    for hk in g("hooks", []):
        if a.part == "first" and hk.get("part", 3) != 3 or a.part == "concrete" and hk.get("part", 3) != 4:
            continue
        beats = []
        for bt in hk.get("beats", []):
            rel = copy_frame(bt["file"], hk["video_id"])
            beats.append(dict(sec=bt["sec"], path=rel, telop=bt.get("telop", ""), speech=bt.get("speech", "")))
        vv = raw.get(hk["video_id"], {})
        hook_pages.append(dict(type="hook", kicker=hk.get("kicker", "秒単位フック"), headline=hk.get("headline", ""), sub=hk.get("sub", ""),
                               video_id=hk["video_id"], url=vv.get("url"), beats=beats, point_title=hk.get("point_title"), points=hk.get("points", []),
                               part=hk.get("part", 3)))

    # ③ 口コミ×PR投稿の判定（分類表に appeal_map がある業種だけ。2026-10-06）
    _vp0 = cfg.get("vocab")
    _voc0 = jl(os.path.join(C, str(_vp0))) if _vp0 and os.path.exists(os.path.join(C, str(_vp0))) else {}
    _app_ids = {e["id"] for e in _voc0.get("appeals", [])} | {e["id"] for e in rc.get("appeal_extra", [])}
    J = review_judgments(cfg, spec, rl, labels, BRANDS, rc, appeal_ids=_app_ids or None)
    numbers = {"review_vs_pr": {nm: dict(n=r["n"], strong=r["strong"], weak=r["weak"], paid=len(r["paid"]), main=r["main"],
                                         pa=dict(r["pa"]), verdicts=r["verdicts"], issuer=r["issuer"],
                                         cats={c: v for c, v in r["cats"].items() if v["pos"] or v["neg"]}) for nm, r in J.items()},
               "overview": ov_rows, "share": share_rows, "mix": mix_rows, "diff": diff_rows, "poster": poster_rows,
               "entry": entry_rows, "creator": creator_rows, "tier": tier_rows, "own_counts": dict(own_counts),
               "top_views": [(x["vid"], x["author"], x["views"]) for x in top_views], "top_save": [(x["vid"], x["author"], round((x["sv"] or 0) * 100, 3)) for x in top_save],
               "top_eng": [(x["vid"], x["author"], round((x["eng"] or 0) * 100, 3)) for x in top_eng],
               "reviews": rv_rows, "review_years": year_rows, "ad_rows": ad_rows, "ad_stats": ad_stats, "effects": eff_rows, "unsat": unsat_rows, "purchase": purch_rows, "scene": scene_rows,
               "trust": {k: v["trust"] for k, v in rv_stats.items()}, "competitors": comp_rows,
               "n_analysed": len(analysed), "n_reviews": len(rv), "n_reviews_unique": rv_uniq, "n_review_labels": sum(len(v) for v in rl.values()),
               "review_buyers": {k: {kk: v[kk] for kk in ("buy_n", "buy_rating", "buy_unsat", "rating", "n", "trust")} for k, v in rv_stats.items()}}
    if a.check or missing:
        print("不足:" if missing else "不足なし")
        for m in missing:
            print("  -", m)
        return 1 if missing else 0
    json.dump(numbers, open(os.path.join(C, "research_numbers.json"), "w"), ensure_ascii=False, indent=1)

    # ── ページの並び（①現状と発見＝現状・保存される型・顧客の声・企画の種／②具体提案＝差分・コマ解剖・競合差・台本・進め方）
    T = lambda key: g("text", {}).get(key, {})
    bs = [brand_short[k] for k, _bn in BRANDS]

    def ref_of(ref):
        """参考投稿のサムネ。image（コマのパス）があればそれを写して使う（カバーに肝の画面が写っていないとき）"""
        if not ref or not ref.get("video_id"):
            return ref
        ref = dict(ref)
        ref["cover"] = copy_frame(ref["image"], ref["video_id"]) if ref.get("image") else f"assets/covers/{ref['video_id']}.jpg"
        ref["url"] = raw.get(ref["video_id"], {}).get("url")
        return ref

    def table(key, kicker, head, rows, align, col_w, **kw):
        t = {k: v for k, v in T(key).items() if k not in ("rows", "head", "col_w", "font")}
        if key == "reviews":
            if not t.get("headline"):
                t["headline"] = "口コミの調査範囲と各社の件数"
            if not t.get("sub"):
                t["sub"] = f"{rv_site_txt}の利用者口コミ{rv_uniq:,}件。評価は取得分の平均"
        return dict(type="table", kicker=kicker, **t, head=head, rows=rows, align=align, col_w=col_w, _id=key, **kw)

    def effects_table():
        p = table("effects", K("effects", effects_title), [effects_head] + bs, eff_rows,
                  ["left"] + ["right"] * nb, bw(4.8), font=13, emph_max="row")
        if effects_note:
            p["note"] = "。".join(str(v).rstrip("。") for v in (p.get("note"), effects_note) if v)
        return p

    def review_table_pages(p):
        """口コミの根拠を行選択で隠さず、読みやすい行数で続きの頁へ送る。"""
        key = p["_id"]
        defaults = {
            "effects": ("口コミで言及された観点を各社で比べる" if effects_mentions else "口コミで良いと書かれた観点を比べる",
                        f"口コミ{rv_uniq:,}件。良い点・不満の両方の言及（複数分類）" if effects_mentions else f"口コミ{rv_uniq:,}件。1件が複数の観点に入る"),
            "unsat": ("口コミで不満が書かれた観点を比べる", f"口コミ{rv_uniq:,}件。不満が書かれた観点を複数分類"),
            "purchase": ("口コミに書かれた購入・申込の理由", f"口コミ{rv_uniq:,}件。本文で理由が明示されたものを複数分類"),
            "scene": ("口コミに書かれた使う場面とブランドへの信頼", f"口コミ{rv_uniq:,}件。1件が複数の場面に入る"),
        }
        if not p.get("headline"):
            p["headline"] = defaults[key][0]
        if not p.get("sub"):
            p["sub"] = defaults[key][1]
        rows = p["rows"]
        total = max(1, (len(rows) + 5) // 6)
        out = []
        for part in range(total):
            start = part * 6
            q = dict(p, rows=rows[start:start + 6], max_rows=6, keep_order=True, font_size=17)
            if total > 1:
                q["kicker"] = f"{p['kicker']}（{part + 1}/{total}）"
            for field in ("pin_rows", "emph_rows"):
                if field in p:
                    indices = [i if i >= 0 else len(rows) + i for i in p[field]]
                    q[field] = [i - start for i in indices if start <= i < start + len(q["rows"])]
            out.append(q)
        return out

    K = lambda key, d: (g("kickers", {}) or {}).get(key, d)   # 見出しの小見出しを案件ごとに差し替える
    nb = len(bs)
    # 列幅：社数で等分。5社のときは N organic で手で詰めた元の幅を使う
    LEGACY_W = {(3.9, 5.8): [3.9, 1.5, 1.5, 2.0, 1.5, 1.5, 5.8], (4.8, 0.0): [4.8, 2.6, 2.6, 2.6, 2.6, 2.5], (5.2, 0.0): [5.2, 2.5, 2.5, 2.5, 2.5, 2.5],
                (5.6, 0.0): [5.6, 2.4, 2.4, 2.4, 2.4, 2.5], (3.2, 0.0): [3.2, 2.9, 2.9, 2.9, 2.9, 2.9]}
    bw = lambda first, rest=0.0, total=17.7: (LEGACY_W[(first, rest)] if nb == 5 and (first, rest) in LEGACY_W
                                              else [first] + [round((total - first - rest) / nb, 2)] * nb + ([rest] if rest else []))
    n_cat, n_comp = len(cfg["keywords"]), sum(1 for b in cfg["brands"] if not b.get("own"))
    rv_site_txt = "・".join(SITE_JA.get(sk, sk) for sk in review_sites)
    # 中扉の題に出す検索語の呼び名（keywords[].label があればそれ。「クレジットカード おすすめ」→「クレカ」等で34字に収める）
    cat_label = next((k.get("label") for k in cfg["keywords"] if k.get("query") == cat_name and k.get("label")), cat_name)
    pages = []
    appendix_pages = []   # 本編の後ろ（URL一覧の前）に置く付録
    pages.append(dict(type="insights", kicker="この資料で分かったこと", _id="summary", **g("summary")))
    # ① PART1 現状
    pages.append(dict(type="part", label="① 現状と発見　PART 1　現状", title=g("part1_title", f"「{cat_label}」のTikTok検索は、いまこうなっている"),
                      desc=f"検索キーワード{len(axis_videos)}つ（カテゴリ{n_cat}・貴社1・競合{n_comp}）の検索結果を表示順のまま取得し、上位を1本ずつ判定", items=g("part1_items", [])))
    pages.append(table("overview", "検索結果の全体像", ["検索キーワード", "PR・広告配信", "保存率 中央値", "ENG率 中央値", "再生 中央値", "フォロワー1万未満"],
                       ov_rows, ["left", "right", "right", "right", "right", "right"], [6.0, 2.1, 2.4, 2.4, 2.4, 2.4], emph_rows=[3]))
    pages.append(table("share", "一般キーワードでの露出シェア（自社×競合）", ["検索キーワード（上位30本）"] + bs + [f"{nb}社以外で名前が多いブランド"],
                       share_rows, ["left"] + ["right"] * nb + ["left"], bw(3.9, 5.8), big=share_big))
    pages.append(dict(type="fv", page="now", override=g("now_override", {})))
    pages.append(table("mix", "上位10本に多い見せ方・ハッシュタグ", ["検索キーワード", "上位10本の見せ方", "上位30本に多いハッシュタグ（本数）"],
                       mix_rows, ["left", "left", "left"], [3.4, 5.4, 8.9]))
    pages.append(table("poster", "公式アカウントの出方・投稿者の内訳", ["検索キーワード", "関連（判定した上位）", "公式", "PRクリエイター", "クリエイター", "一般"],
                       poster_rows, ["left", "right", "right", "right", "right", "right"], [6.4, 2.6, 1.6, 2.5, 2.3, 2.3]))
    pages.append(dict(type="fv", page="competitors", override={"kicker": f"「{cat_name}」の保存上位と、社名で検索した上位の投稿", **g("competitors_override", {})}))
    own_rows = T("own").get("rows", [])
    if not own_rows:
        # 原稿が無いときも「未記入」を0件へ置き換えず、判定済みの実件数を使う。
        own_rows = [[REL_OUT.get(key, "貴社の商品" if key == "relevant" else "言及"), str(n), "検索結果の窓内を判定"]
                    for key, n in own_counts.items()]
        if not own_rows:
            own_rows = [["判定窓内の貴社投稿", "0", "取得した検索結果内に投稿が無い"]]
    def _n(v):
        m = re.match(r"\d+", str(v).strip())
        return int(m.group(0)) if m else 0
    own_bars = [dict(label=str(r[0]), value=_n(r[1]), text=f"{_n(r[1])}本", emph=(i == 0)) for i, r in enumerate(own_rows) if len(r) > 1]
    pages.append(table("own", f"「{own_b['query']}」で出るもの", ["中身", "本数", "内訳（検索の表示順）"], own_rows,
                       ["left", "right", "left"], [5.2, 1.4, 11.1],
                       # 2026-10-02：「1・4・5・6…位」の順位の羅列は読み物になる。紙面は本数の棒、順位は話すことへ
                       chart=dict(title=f"「{own_b['query']}」の上位の中身（本数）", bars=own_bars) if len(own_bars) >= 2 else None))
    # ① PART2 保存される型
    pages.append(dict(type="part", label="① 現状と発見　PART 2　保存される型", title="保存されている投稿は、何が違うか",
                      desc=f"判定した関連投稿{len(relx)}本で広告配信の有無と見せ方を比べ、{len(analysed)}本は実際に見て作りを分けた", items=g("part2_items", [])))
    pages.append(table("ad", f"見せ方×広告配信の保存率（判定した関連投稿{len(relx)}本）", ["見せ方", "配信なし 本数", "配信なし 保存率", "配信あり 本数", "配信あり 保存率"],
                       ad_rows, ["left", "right", "right", "right", "right"], [6.6, 2.6, 2.9, 2.6, 2.9], emph_rows=[0, 1], font=13,
                       chart=dict(title=f"見せ方別の保存率（中央値・広告配信なし・3本以上）", bars=ad_bars) if len(ad_bars) >= 2 else None))
    # 再生・ENG率・保存率の上位5本（3枚並べる。2026-10-02：「冷凍食品 コンビニ」の TOP5 資料の要素を、話す資料の型で）
    min_v = views_label(rc.get("top_save_min_views", 20_000)).replace(".0", "")
    src_lab = f"「{cat_name}」など{n_cat}検索の上位{len(cat)}本より"
    saves_lab = lambda x: f"{(x['v'].get('stats') or {}).get('collectCount') or 0:,}"  # noqa: E731
    for key, xs, unit, lab, first, kdef, sdef, full in (
            ("top_views", top_views, "再生", lambda x: views_label(x["views"]), ("いいね", "保存"), "再生数 TOP5", src_lab, True),
            ("top_eng", top_eng, "ENG率", lambda x: pct(x["eng"], 2), ("再生", "保存"), "ENG率 TOP5",
             f"{src_lab}（{min_v}再生以上）｜ENG率＝（いいね＋保存＋コメント＋シェア）÷再生", True),
            ("top_saves", top_saves, "保存数", saves_lab, ("再生", "いいね"), "保存数 TOP5", src_lab, True),
            ("top_save", top_save, "保存率", lambda x: pct(x["sv"], 2), ("再生", "保存"), f"保存率の上位5本（{min_v}再生以上）", "", False)):
        t = g(key)
        if not xs:
            continue
        pages.append(dict(type="top5", _id=key, kicker=t.get("kicker", kdef), headline=t.get("headline", kdef), sub=t.get("sub", sdef),
                          factors_title=t.get("factors_title", ""), factors=t.get("factors", []), cards=[card(x, lab(x), unit, first, full) for x in xs]))
    pages.append(table("entry", f"冒頭0〜3秒の入り方と保存率（分析{len(analysed)}本）", ["区分", "本数", "再生 中央値", "保存率 中央値", "ENG率 中央値", "うちPR・提供の表記"],
                       entry_rows, ["left", "right", "right", "right", "right", "right"], [7.2, 1.6, 2.4, 2.4, 2.4, 1.7], emph_rows=[0, 1],
                       max_rows=max(len(entry_rows), 1), keep_order=True, font_size=17))
    if g("sns_reading"):
        pages.append(dict(type="insights", kicker="読み解き", _id="sns_reading", **g("sns_reading")))
    # 2026-10-02：3枚（8行×8列）に分けていたのを1枚に。紙面は保存率の上位8本、9位以下は話すことへ。全本は付録のURL一覧にある
    pages.append(table("creator", "誰が投稿しているか（保存率の高い順・上位8本）", ["投稿者", "冒頭の入り方", "発信者のタイプ", "フォロワー", "規模", "再生", "保存率", "広告/PR"],
                       creator_rows, ["left", "left", "left", "right", "left", "right", "right", "left"], [3.6, 2.4, 3.9, 1.8, 1.3, 1.5, 1.6, 1.3],
                       max_rows=8, keep_order=True, emph_max="col", **({} if T("creator").get("sub") else dict(sub="保存率の高い順。広告＝広告配信あり、PR＝配信なしでPR・提供の表記あり"))))
    pages.append(table("tier", f"フォロワー規模別の保存率（判定した関連投稿{len(relx)}本）", ["フォロワー規模", "配信なし 本数", "配信なし 保存率", "配信なし 再生", "配信あり 本数", "配信あり 保存率"],
                       tier_rows, ["left", "right", "right", "right", "right", "right"], [5.0, 2.4, 2.6, 2.6, 2.4, 2.7], emph_max="col"))
    pages += [h for h in hook_pages if h["part"] == 3]
    for pat in g("patterns", []):
        pages.append(dict(type="insights", kicker="実動画から見える、保存されている型", _id="patterns", **pat))
    # ① PART3 顧客の声
    if zero_reviews:
        pages.append(dict(type="part", _id="part3", label="① 現状と発見　PART 3　顧客の声",
                          title="取得対象の利用者口コミは0件", desc="取得した各対象のサイト表示が0件。取得失敗とは区別した観測結果。",
                          items=["調査対象と出典", "口コミから強み・不満を判断できない"]))
        zero_rows = []
        for index, source in enumerate(zero_reviews["sources"], 1):
            target = source.get("product_name") or source.get("name") or source.get("product_id") or source.get("id") or f"取得対象{index}"
            if source.get("brand"):
                target = f"{source['brand']}｜{target}"
            url = source.get("url") or source.get("source")
            zero_rows.append([target, {"text": f"{SITE_FULL.get(source.get('site'), source.get('site') or '取得元')}｜{short_url(url)}", "url": url}, "0件"])
        pages.append(dict(type="table", _id="rv_zero", kicker="口コミ取得の観測結果",
                          headline="取得対象の利用者口コミは0件", sub="口コミから強み・不満を判断できない",
                          head=["取得対象", "出典（対象URL）", "利用者口コミ"], rows=zero_rows,
                          align=["left", "left", "right"], col_w=[5.2, 10.5, 2.0], max_rows=6,
                          no_emph=True, keep_order=True))
    if rv_rows:
        pages.append(dict(type="part", label="① 現状と発見　PART 3　顧客の声", title=K("part3_title", "口コミでは、何について語られているか" if effects_mentions else f"口コミでは、何に良い{NOUN}だと思われているか"),
                          desc=f"{rv_site_txt}の口コミ{rv_uniq:,}件を1件ずつ読んで判定（件数は判定の集計）", items=g("part3_items", []),
                          # 紙面に口コミの出どころ（2026-10-06 打ち合わせ「楽天入ってる？と聞かれたら、楽天と◯◯です、Amazonは無しと言えるように」）
                          sources=f"口コミの出どころ：{'・'.join(SITE_FULL.get(k, k) for k in review_sites)}（計{rv_uniq:,}件）\n入っていない：Amazon・LIPS・Qoo10"
                                  + "".join(f"・{SITE_FULL[k]}" for k in ("kakaku", "mybest") if k not in review_sites)))
        # 2026-10-02：口コミの件数・平均・期間の表は「どう調べたか」なので付録へ（後ろの appendix_pages で足す）
        if "cosme" in review_sites:
            appendix_pages.append(table("reviews", "付録　口コミの調査対象と件数", ["ブランド", "口コミの総数（楽天／@cosme）", "判定した件数（楽天／@cosme）", "楽天平均（全件取得）", "@cosme平均（取得分）", "うち購入品の平均", "@cosme取得分の期間"],
                               rv_rows, ["left", "right", "right", "right", "right", "right", "left"], [2.0, 3.1, 2.9, 2.4, 2.2, 2.4, 2.7], appendix=True))
            pages.append(table("years", "@cosmeの口コミは、いつ書かれたか（年別の件数）", ["年"] + bs, year_rows, ["left"] + ["right"] * nb, bw(3.2), font=13, emph_max="row"))
        else:
            ns = len(review_sites)
            appendix_pages.append(table("reviews", "付録　口コミの調査対象と件数", ["ブランド"] + [SITE_JA.get(sk, sk) for sk in review_sites] + ["判定した件数", "平均評価（5段階）", "不満が書かれた口コミ"],
                               rv_rows, ["left"] + ["right"] * (ns + 1) + ["left", "right"], [2.6] + [1.8] * ns + [2.1, 17.7 - 2.6 - 1.8 * ns - 2.1 - 3.8, 3.8], appendix=True))
        review_tables = [effects_table(),
                         table("unsat", "不満の中身", ["不満（本文に書かれたもの）"] + bs, unsat_rows, ["left"] + ["right"] * nb, bw(5.2), emph_max="row"),
                         table("purchase", "買ったきっかけ", ["買ったきっかけ（本文に書かれたもの）"] + bs, purch_rows, ["left"] + ["right"] * nb, bw(5.6), font=13, emph_max="row"),
                         table("scene", "使う場面・ブランドへの信頼", ["分類｜中身"] + bs,
                               [[f"場面｜{r[0]}"] + r[1:] for r in scene_rows] +
                               [["ブランドへの信頼が言葉になっている"] + [str(rv_stats[k]["trust"]) if k in rv_stats else "—" for k, _bn in BRANDS]],
                               ["left"] + ["right"] * nb, bw(5.6), pin_rows=[-1], emph_max="row")]
        for p in review_tables:
            pages += review_table_pages(p)
        for k in ("review_reading1", "review_reading2"):
            if g(k):
                pages.append(dict(type="insights", _id=k, kicker=g(k).get("kicker", "口コミの読み解き"), **{kk: vv for kk, vv in g(k).items() if kk != "kicker"}))
    # ① 企画の種
    if g("proposals"):
        prop = json.loads(json.dumps(g("proposals")))
        for it in prop.get("items", []):
            it["reference"] = ref_of(it.get("reference"))
        items = prop.pop("items")
        for offset in range(0, len(items), 3):
            pages.append(dict(type="proposals", _id="proposals", kicker=f"保存される型×{OWN} の企画の種",
                              **prop, items=items[offset:offset + 3], item_offset=offset))
    # ── 初訪だけのページ（2026-10-06 本人「①自社の投稿/発話 VS 他社のPR：何が足りていて足りないか
    #    ②一般検索ワードで何が上位表示され、再生・ENG・保存されているか」）。統合版・具体提案版には入れない（_first_only）
    # 黒文字（小見出し）に何で検索したかを書く（2026-10-06 本人「検索した場合何で検索したかを黒文字の部分で記載」）
    sw = search_words(cfg)
    for p in pages:
        pid = p.get("_id")
        if pid == "share":
            p["kicker"] = f"{sw}で検索した上位30本に、各社の名前が出た本数"
        elif pid == "own":
            p["kicker"] = f"「{own_b['query']}」で検索した上位{sum(own_counts.values())}本の中身"
        elif pid in ("top_views", "top_eng", "top_saves", "top_save") and "「" not in p.get("kicker", ""):
            p["kicker"] = f"{sw}で検索した上位の関連{len(cat)}本｜" + re.sub(r"（カテゴリ\d+検索）", "", p.get("kicker", ""))
        elif pid == "ad":
            p["kicker"] = f"検索{len(axis_videos)}語の上位から判定した関連{len(relx)}本｜見せ方×広告配信の保存率"
    first_only = build_first_only(cfg, C, fv, labels, raw, axis_videos, share_rows, BRANDS, OWN, own_b, cat_label, g, card, vrow, rc)
    qa_notes = [p["text"] for p in first_only if p.get("type") == "_warn"]
    for t in qa_notes:
        print(f"注意: {t}")
    pages += [p for p in first_only if p.get("type") != "_warn"]
    if J:
        _vp = cfg.get("vocab")
        _voc = jl(os.path.join(C, str(_vp))) if _vp and os.path.exists(os.path.join(C, str(_vp))) else {}
        _app = {e["id"]: e["label"] for e in _voc.get("appeals", []) + list(rc.get("appeal_extra", []))}
        pages += review_vs_pr_pages(cfg, spec, J, rl, rv_by, g, _app, "・".join(SITE_FULL.get(k, k) for k in review_sites),
                                    rc.get("review_window", "期間は付録"), case_dir=C)
    # ② 具体提案
    pages.append(dict(type="part", label="② 具体提案", title="企画の種を、撮れる台本にする", desc="上位と下位の差・冒頭のコマ・競合との差から、3本の構成を決めた", items=g("part4_items", [])))
    pages.append(table("diff", "上位10本と11〜30位の差", ["検索｜範囲", "PR投稿", "再生 中央値", "保存率 中央値", "ENG率 中央値", "多い見せ方", "フォロワー 中央値"],
                       diff_rows, ["left", "right", "right", "right", "right", "left", "right"], [4.8, 1.6, 2.2, 2.2, 2.2, 2.8, 1.9], font=15, emph_max="col"))
    pages += [h for h in hook_pages if h["part"] == 4]
    comp_head = ["ブランド", "カテゴリ上位", "自社名検索で関連", "自社名検索のPR", "自社名検索の保存率", f"{len(analysed)}本での主な入り方", rc.get("comp_effect_head", ("口コミで多い言及" if effects_mentions else "口コミで多い良さ") + (f"（{'・'.join(EFFECT_JA[e].split('（')[0] for e in spec.get('both_directions') or [])}以外）" if spec.get("both_directions") else ""))]
    comp_align, comp_w = ["left", "right", "right", "right", "right", "left", "left"], [1.8, 2.2, 1.9, 1.9, 1.9, 3.2, 4.8]
    if not rv_rows:   # 口コミが無い業種：口コミの列（全行「—」）を出さない（2026-10-05 JAL カード）
        comp_head, comp_align, comp_w = comp_head[:-1], comp_align[:-1], [2.2, 2.6, 2.6, 2.4, 2.6, 5.3]
        comp_rows = [r[:-1] for r in comp_rows]
    pages.append(table("competitors", "競合差の詳細", comp_head, comp_rows, comp_align, comp_w, font=15, emph_max="col"))
    if g("blanks"):
        pages.append(dict(type="insights", kicker=f"{OWN} が取れる空白", _id="blanks", **g("blanks")))
    for sc in (g("scripts", []) if a.part != "first" else []):
        sc = json.loads(json.dumps(sc))
        sc["reference"] = ref_of(sc.get("reference"))
        pages.append(dict(type="script", **sc))
    if g("kit"):
        pages.append(dict(type="insights", kicker="KEEP / IMPROVE / TRY", _id="kit", **g("kit")))
    if T("plan"):
        pl = T("plan")
        pages.append(dict(type="table", _id="plan", kicker="進め方と役割分担（案）", headline=pl.get("headline"), sub=pl.get("sub"), note=pl.get("note"),
                          head=pl["head"], rows=pl["rows"], align=["left"] * len(pl["head"]), col_w=pl.get("col_w"), font=pl.get("font", 14), no_emph=True))
    pages.append(dict(type="fv", page="next", override=g("next_override", {})))
    # 実画面の解剖（本編だけの版では外す）
    if not a.no_videos:
        pages.append(dict(type="part", label="実画面の解剖", title=f"個別投稿の構成分析（{len(video_pages)}本）", desc="保存率の高い順。1本につき2枚（観点の解剖／5コマ）",
                          items=[f"冒頭の入り方：{'・'.join(f'{ENTRY_LAB[e]}{len(by_entry.get(e, []))}本' for e in ['rank'] + ENTRY_ORDER if by_entry.get(e))}",
                                 "観察範囲：動画はシーン変化＋最大4秒間隔のコマと音声の自動書き起こし、写真投稿は全枚", f"数字は取得時点（{ACQ}）のもの。広告配信の有無は各ページに記載"]))
        pages += video_pages
    pages += appendix_pages
    # 付録：参考投稿のURL一覧
    url_rows = [[str(i), f"@{x['author']}", views_label(x["views"]), pct(x["sv"], 3), "あり" if x["ad"] else "",
                 {"text": short_url(x["v"].get("url")), "url": x["v"].get("url")}]
                for i, x in enumerate(order, 1)]
    for k in range(0, len(url_rows), 15):
        pages.append(dict(type="table", _id="urls", kicker=f"付録　分析した{len(order)}本のURL（{k // 15 + 1}/{(len(url_rows) + 14) // 15}）", headline=f"分析した{len(order)}本の投稿URL",
                          sub=("保存率の高い順。数字は取得時点" if a.no_videos else "保存率の高い順（個別分析のページと同じ並び）。数字は取得時点"), head=["No", "投稿者", "再生", "保存率", "広告配信", "URL"],
                          rows=url_rows[k:k + 15], align=["right", "left", "right", "right", "left", "left"], col_w=[0.7, 3.2, 1.4, 1.5, 1.4, 9.5], font=12, max_rows=15, appendix=True))
    ap_ = dict(fv.get("appendix") or {})
    prem = [list(r) for r in (ap_.get("premise") or [])]
    for r in prem:
        for old, new_ in (g("premise_replace", {}) or {}).items():
            r[1] = r[1].replace(old, new_)
    # 一般検索の語の選び方（受付で Claude が候補を出し、営業が1〜3語選ぶ。case.json の keyword_candidates。2026-10-06）
    cands = [c if isinstance(c, str) else c.get("query", "") for c in (cfg.get("keyword_candidates") or [])]
    if cands:
        chosen = [k["query"] for k in cfg["keywords"]]
        prem = [["検索語の選び方", f"生活者が使う一般の検索語の候補{len(cands)}語（{'／'.join(cands)}）から、"
                 f"営業が{len(chosen)}語（{'・'.join(chosen)}）を選んだ"]] + prem
    extra = [list(r) for r in g("premise_extra", [])]
    # 口コミを使ったのに、原稿の付録に「口コミの章は設けていない」が残っていると紙面で食い違う（JAL 10-06：口コミ692件を足した後も残っていた）。
    # 口コミがあるときは、その行を口コミの実際の出どころ・件数の行に差し替えて知らせる
    if rv_rows:
        rv_line = [f"口コミ", f"{rv_site_txt}の口コミ{rv_uniq:,}件（{rc.get('review_window', '期間は口コミの章')}）を1件ずつ読んで判定。"
                   "サイトの表示順の先頭から取ったもので、書いた人の偏りがある"]
        for r in extra:
            if r and str(r[0]).startswith("口コミ") and re.search(r"設けていない|対象外|無い|なし", str(r[1])):
                print(f"注意: 原稿の付録「{r[0]}」が口コミ無しの言い方のため、実際の件数の行に差し替えた（synthesis.json の premise_extra を直す）", file=sys.stderr)
                r[:] = rv_line
    ap_["premise"] = (extra + prem)[:12]
    pages.append(dict(type="fv", page="appendix", appendix=ap_))

    for p in pages:
        if p.get("type") == "table":
            p.setdefault("rows", [])
            if not p["rows"]:
                # 判定を終えた結果の0件は観測。口コミ未収集や分析0本は入力ゲートで停止する。
                p["rows"] = [["判定対象内の該当項目は0件"] + ["—"] * max(0, len(p.get("head", [])) - 1)]
    rv_src = rv_site_txt
    add_how(pages + appendix_pages, dict(brand_qs="・".join(f"「{b['query']}」" for b in cfg["brands"]), kw_qs="・".join(f"「{k['query']}」" for k in cfg["keywords"]),
                                         primary=cat_name, own_q=own_b["query"], n_rel=len(relx), n_cat=len(cat), min_v=min_v, n_an=len(analysed),
                                         rv_src=rv_src, rv_n=rv_uniq if rv_rows else 0,
                                         review_effect_how="観点ごとの言及件数と割合。" + effects_note if effects_mentions else "書かれている良さごとの件数と割合"))
    rs = {"project": {"cover_title": g("cover_title", fv["project"].get("cover_title")), "footer": fv["project"].get("footer"),
                      "file": g("file", f"{re.sub(r'\W+', '_', OWN).strip('_')}_TikTok{'口コミ' if rv_rows else ''}調査と提案.pptx"),
                      # 表紙の題の下に置く「何をどれだけ調べたか」の1行（2026-10-02 表紙の作り直し）
                      "cover_sub": g("cover_sub", f"TikTok検索{len(axis_videos)}つ・投稿{len(relx)}本を判定・動画{len(analysed)}本を解剖" + (f"・口コミ{rv_uniq:,}件" if rv_rows else ""))}, "pages": pages}
    # 表紙の写真：9:16 に切りそろえた写しを assets/covers_916/ に作る（PowerPoint・Keynote どちらで開いても同じ形に。2026-10-02）
    cc = []
    for c in (fv.get("cover_cards") or [])[:3]:
        src = os.path.join(C, c.get("cover") or "")
        dst_rel = f"assets/covers_916/{c.get('video_id')}.jpg"
        try:
            from PIL import Image
            im = Image.open(src).convert("RGB")
            w, h = im.size
            tw = min(w, round(h * 9 / 16)); th = min(h, round(w * 16 / 9))
            l, t = (w - tw) // 2, (h - th) // 2
            os.makedirs(os.path.join(C, "assets", "covers_916"), exist_ok=True)
            im.crop((l, t, l + tw, t + th)).save(os.path.join(C, dst_rel), quality=90)
            cc.append(dict(c, cover=dst_rel))
        except Exception:
            cc.append(c)
    if cc:
        rs["project"]["cover_cards"] = cc
    # 元のFMTの表紙（cover_style: deepdive）で「対象」「検索面」の行に出す
    rs["project"]["cover_brands"] = [b["name"] + ("（自社）" if b.get("own") else "") for b in cfg["brands"]]
    rs["project"]["cover_keywords"] = [k["query"] for k in cfg["keywords"]]
    if qa_notes:
        rs["project"]["qa_notes"] = qa_notes   # 生成ログの QA に載る（初訪の版だけでなく全版。どれも同じ取得なので）
    # 既定は元のFMT（2026-10-06 本人「これでSkills」）。既定のときはファイル名に印を入れない
    skin, marked = resolve_skin(a.skin or S.get("skin"))
    if skin:
        rs["project"]["skin"] = skin
        # 既定と違うスキンの版が、既定の版（送付済みのことがある）を上書きしないよう、名前に印を入れる。
        # 版の印（_初訪・_本編・_統合）より前に入れる（build_parts.sh が「<名前>_<版>.pptx」で探すため）
        mark = skin_file_mark(skin, C) if marked else ""
        if mark and mark not in rs["project"]["file"]:
            rs["project"]["file"] = re.sub(r"\.pptx$", f"{mark}.pptx", rs["project"]["file"])
    if a.no_videos and not a.plain_name:
        rs["project"]["file"] = re.sub(r"\.pptx$", "_本編.pptx", rs["project"]["file"])
    if a.part != "all":
        rs = select_part(rs, a.part, g)
        if a.part != "first":
            rs["pages"] = [p for p in rs["pages"] if not p.get("_first_only")]
    else:
        rs["pages"] = [p for p in rs["pages"] if not p.get("_first_only")]
        # 統合版も他の2つと名前と表紙で見分けられるようにする（_統合／RESEARCH & PROPOSAL）
        rs["project"]["file"] = re.sub(r"(_本編)?\.pptx$", lambda m: f"_統合{m.group(1) or ''}.pptx", rs["project"]["file"])
        rs["project"]["cover_kicker"] = "TIKTOK SEARCH — RESEARCH & PROPOSAL"
    pages = rs["pages"]
    rs["quality_contract"] = validated["quality_contract"]
    headlines = g("headlines", {})
    if not isinstance(headlines, dict) or any(not isinstance(value, str) or not value.strip() for value in headlines.values()):
        raise InputGateError("原稿の headlines はページIDから空でない大見出しへのオブジェクトで指定する")
    for p in rs["pages"]:
        pid = page_id(p)
        # 版ごとの原稿の差し替え後に大見出しだけを反映する。
        # 小キッカー、章番号、箇条書きは保持する。
        headline = headlines.get(pid)
        if headline:
            if p.get("type") == "part":
                p["title"] = headline
            elif p.get("type") == "fv":
                p["override"] = {**(p.get("override") or {}), "headline": headline}
            else:
                p["headline"] = headline
        p["id"] = pid  # 品質監査のページ役割は版選別後もPPTXへ引き継ぐ。
        p.pop("_id", None)   # 選別用の目印。紙面には使わないので書き出さない
        p.pop("_first_only", None)
    json.dump(rs, open(os.path.join(C, a.out), "w"), ensure_ascii=False, indent=1)
    print(f"→ research.json（{len(pages)}項目・動画{len(video_pages)}本・口コミ{len(rv)}件／判定{numbers['n_review_labels']}件）")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except InputGateError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"入力検証で停止: 必須入力が無い/不正です ({exc})。取得・判定・統合原稿の工程へ戻って修正してください", file=sys.stderr)
        sys.exit(1)
