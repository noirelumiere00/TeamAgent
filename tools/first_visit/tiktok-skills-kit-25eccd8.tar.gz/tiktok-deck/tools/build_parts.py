#!/usr/bin/env python3
"""Portable build entry point: CASE RUN [REVIEWS] [SELECTION.json] [options].

Default outputs: 初訪・具体提案・統合. --all keeps the legacy five variants.
--only first_visit builds just 初訪 through the same pipeline.
Artifacts are staged, checked, and then published. A successful build remains
build_verified until a separate recorded review confirms every rendered page.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
import zipfile

import runtime

DECK = Path(__file__).resolve().parents[1]


class BuildError(RuntimeError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def variants(all_variants=False):
    if all_variants:
        return [("first", ["--no-videos"], "research_first.json", "初訪"),
                ("concrete", ["--no-videos"], "research_concrete.json", "具体提案_本編"),
                ("concrete", [], "research_concrete_full.json", "具体提案"),
                ("all", ["--no-videos"], "research_all_main.json", "統合_本編"),
                ("all", [], "research_all.json", "統合")]
    return [("first", ["--no-videos"], "research_first.json", "初訪"),
            ("concrete", ["--no-videos", "--plain-name"], "research_concrete.json", "具体提案"),
            ("all", [], "research_all.json", "統合")]


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case")
    parser.add_argument("run")
    parser.add_argument("legacy_inputs", nargs="*")
    parser.add_argument("--reviews")
    parser.add_argument("--selection")
    parser.add_argument("--pdf", action="store_true")
    parser.add_argument("--render", action="store_true", help="全ページをPNGへ描画（--pdfはこれを含む）")
    parser.add_argument("--skin")
    output_mode = parser.add_mutually_exclusive_group()
    output_mode.add_argument("--all", action="store_true")
    output_mode.add_argument("--only", choices=["first_visit"], help="指定した1版だけを生成（first_visit: 初訪）")
    parser.add_argument("--review-shots", action="store_true")
    parser.add_argument("--python", help="生成・前検に使うPython。環境変数TIKTOK_SKILLS_PYTHONでも指定可")
    parser.add_argument("--node", help="PPTX生成に使うNode.js。環境変数TIKTOK_SKILLS_NODEでも指定可")
    parser.add_argument("--soffice", help="LibreOffice実行ファイル（SOFFICE_BINARYでも指定可）")
    parser.add_argument("--font-directory", action="append", help="描画時のフォント探索先。複数可（TIKTOK_FONT_DIRECTORIESでも指定可）")
    parser.add_argument("--fontconfig-file", help="既存のFontconfig設定（FONTCONFIG_FILEでも指定可）")
    args = parser.parse_intermixed_args(argv)
    for value in args.legacy_inputs:
        key = "selection" if value.lower().endswith(".json") else "reviews"
        if getattr(args, key):
            parser.error(f"{key} が複数指定されています")
        setattr(args, key, value)
    args.render = args.render or args.pdf
    return args


def case_path(case: Path, value: str | None):
    if value is None:
        return None
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (case / path).resolve()


def source_version():
    commit = None
    try:
        result = subprocess.run(["git", "-C", str(DECK), "rev-parse", "HEAD"],
                                capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            commit = result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    fingerprint = hashlib.sha256()
    for path in (DECK / "tools/build_parts.py", DECK / "tools/build_research_json.py",
                 DECK / "tools/preflight.py", DECK / "src/build_research.js"):
        fingerprint.update(path.read_bytes())
    version = DECK.parent / "VERSION"
    return {"git_commit": commit, "source": str(DECK),
            "source_sha256": fingerprint.hexdigest(),
            "installed_version": os.environ.get("TIKTOK_SKILLS_VERSION") or (version.read_text(encoding="utf-8").strip() if version.is_file() else None)}


def slide_count(path: Path) -> int:
    with zipfile.ZipFile(path) as deck:
        count = sum(bool(re.fullmatch(r"ppt/slides/slide\d+\.xml", name)) for name in deck.namelist())
    if not count:
        raise BuildError(f"PPTXにスライドがありません: {path}")
    return count


def execute_build(args, *, run_process=None, validate=True) -> int:
    """run_process is injectable for process-failure regression tests."""
    runtime.configure_stdio()
    run_process = run_process or subprocess.run
    case = Path(args.case).expanduser().resolve()
    if not case.is_dir():
        print(f"案件フォルダがありません: {case}", file=sys.stderr)
        return 1
    output = case / "output"
    work = output / "作業"
    build_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    build_dir = work / "builds" / build_id
    stage = build_dir / "staging"
    stage.mkdir(parents=True)
    status_path = work / "delivery_status.json"
    prior_status = {}
    if status_path.is_file():
        try:
            prior_status = json.loads(status_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
    targets = variants(args.all)
    if args.only:
        only_kind = {"first_visit": "first"}[args.only]
        targets = [t for t in targets if t[0] == only_kind]
    status = {"schema_version": 1, "build_id": build_id, "status": "incomplete", "delivery_ready": False,
              "created_at": now(), "updated_at": now(), "case": str(case), "kit_version": source_version(),
              "request": {"run": str(case_path(case, args.run)), "reviews": str(case_path(case, args.reviews)) if args.reviews else None,
                          "selection": str(case_path(case, args.selection)) if args.selection else None,
                          "skin": args.skin, "pdf": args.pdf, "render": args.render,
                          "review_shots": args.review_shots, "targets": [x[3] for x in targets]},
              "runtime": {}, "checks": {"machine_qa": "pending", "render": "pending" if args.render else "not_requested", "visual_qa": "unverified"},
              "commands": [], "artifacts": [], "blockers": [], "previous_outputs": []}

    def save():
        status["updated_at"] = now()
        write_json(status_path, status)
        write_json(build_dir / "delivery_status.json", status)

    # The preceding current manifest identifies prior generated artifacts even
    # if this attempt fails before it can derive filenames from new inputs.
    previous = build_dir / "previous"
    for artifact in prior_status.get("artifacts", []):
        if artifact.get("variant") not in status["request"]["targets"]:
            continue
        prior_paths = []
        for kind in ("pptx", "pdf"):
            item = artifact.get(kind) or {}
            if item.get("path"):
                old = Path(item["path"])
                prior_paths.append(old)
                if kind == "pptx":
                    prior_paths.append(old.with_suffix(".pdf"))
        for old in dict.fromkeys(prior_paths):
            if old and old.parent.resolve() == output.resolve() and old.is_file():
                previous.mkdir(exist_ok=True)
                archived = previous / old.name
                os.replace(old, archived)
                status["previous_outputs"].append(str(archived))
    save()  # Immediately invalidate any prior successful delivery record.
    current_stage = "runtime"
    published = []
    environment = runtime.child_environment()

    def command(argv, label):
        nonlocal current_stage
        current_stage = label
        log = build_dir / f"command-{len(status['commands']) + 1:02d}.txt"
        entry = {"argv": [str(x) for x in argv], "cwd": str(case), "returncode": None, "log": str(log)}
        status["commands"].append(entry)
        save()
        try:
            result = run_process(entry["argv"], cwd=case, env=environment,
                                 capture_output=True, text=True, encoding="utf-8", errors="replace")
            entry["returncode"] = result.returncode
            text = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
        except OSError as exc:
            text = str(exc)
            log.write_text(text, encoding="utf-8")
            save()
            raise BuildError(f"{label} を実行できません: {exc}") from exc
        log.write_text(text, encoding="utf-8")
        if text.strip():
            print(text.rstrip())
        save()
        if result.returncode != 0:
            raise BuildError(f"{label} が終了コード {result.returncode} で失敗しました（{log}）")
        return result

    try:
        python = runtime.python_executable(args.python)
        node = runtime.node_executable(args.node)
        office = runtime.find_soffice(args.soffice)
        fonts = runtime.font_settings(args.font_directory, args.fontconfig_file)
        if office:
            environment["SOFFICE_BINARY"] = office
        status["runtime"] = {"python": python, "node": node, "soffice": office,
                             "fonts": fonts,
                             "native_automation": "unverified until actual render succeeds",
                             "network_browser": "unverified until acquisition/review shots succeeds"}
        save()
        if validate:
            runtime.validate_versions(python, node)
        base = [python, str(DECK / "tools/build_research_json.py"), "--case", str(case), "--run", status["request"]["run"]]
        for option in ("reviews", "selection"):
            if status["request"][option]:
                base += [f"--{option}", status["request"][option]]
        if args.skin:
            base += ["--skin", args.skin]
        if args.review_shots:
            if not args.reviews:
                raise BuildError("--review-shots には口コミフォルダが必要です（[reviews] または --reviews）")
            wanted = case / "review_shots_wanted.json"
            wanted.unlink(missing_ok=True)
            command(base + ["--part", "first", "--no-videos", "--out", str(stage / "review_shots_seed.json")], "口コミ写しの対象生成")
            if wanted.exists():
                entries = json.loads(wanted.read_text(encoding="utf-8"))
                shots_file = case / "assets/review_shots/shots.json"
                captured = json.loads(shots_file.read_text(encoding="utf-8")) if shots_file.exists() else {}
                def has_shot(record):
                    png = record.get("png") if isinstance(record, dict) else None
                    path = (shots_file.parent / png).resolve() if isinstance(png, str) and png else None
                    return path is not None and path.is_relative_to(shots_file.parent.resolve()) and path.is_file() and path.stat().st_size > 0
                needed = [x["review_id"] for x in entries if not has_shot(captured.get(x["review_id"]))]
                if needed:
                    command([node, str(DECK / "tools/review_shots.js"), "--reviews", status["request"]["reviews"], "--out", str(shots_file.parent), *needed], "口コミの実画面取得")
                    captured = json.loads(shots_file.read_text(encoding="utf-8")) if shots_file.exists() else {}
                    missing = [review_id for review_id in needed if not has_shot(captured.get(review_id))]
                    if missing:
                        raise BuildError("口コミの写しが生成されていません: " + ", ".join(missing))

        plans = []
        for part, flags, data_name, variant in targets:
            data = stage / data_name
            command(base + ["--part", part, *flags, "--out", str(data)], f"原稿生成 {variant}")
            if not data.is_file():
                raise BuildError(f"原稿が生成されていません: {data}")
            content = json.loads(data.read_text(encoding="utf-8"))
            filename = content.get("project", {}).get("file")
            if not isinstance(filename, str) or Path(filename).name != filename or not filename.endswith(".pptx"):
                raise BuildError(f"不正な成果物ファイル名: {filename!r}")
            if filename in [x[3] for x in plans]:
                raise BuildError(f"版の出力名が重複しています: {filename}")
            plans.append((part, variant, data, filename))

        # Archive prior files for the exact requested variants before building.
        # On failure they remain recoverable, but cannot appear as current output.
        for _, _, _, filename in plans:
            for old in (output / filename, (output / filename).with_suffix(".pdf")):
                if old.exists():
                    previous.mkdir(exist_ok=True)
                    archived = previous / old.name
                    os.replace(old, archived)
                    status["previous_outputs"].append(str(archived))
        save()
        for part, variant, data, filename in plans:
            pptx = stage / filename
            command([node, str(DECK / "src/build_research.js"), "--case", str(case),
                     "--data", os.path.relpath(data, case), "--out", str(pptx), "--client"], f"PPTX生成 {variant}")
            if not pptx.is_file() or pptx.stat().st_size == 0:
                raise BuildError(f"PPTXが生成されていません: {pptx}")
            pages = slide_count(pptx)
            report = build_dir / f"preflight-{filename}.json"
            try:
                command([python, str(DECK / "tools/preflight.py"), str(pptx), "--json", str(report)], f"前検 {variant}")
            except BuildError:
                status["checks"]["machine_qa"] = "failed"
                raise
            if not report.is_file():
                raise BuildError(f"前検レポートが生成されていません: {report}")
            report_data = json.loads(report.read_text(encoding="utf-8"))
            if report_data.get("machine_qa") == "failed":
                status["checks"]["machine_qa"] = "failed"
                raise BuildError(f"前検レポートが不合格です: {report}")
            artifact = {"part": part, "variant": variant,
                        "pptx": {"path": str(output / filename), "sha256": sha256(pptx), "slide_count": pages},
                        "pdf": None, "preflight_report": str(report),
                        "render": {"status": "not_requested", "page_count": 0, "info_path": None, "pages": []}}
            if args.render:
                render_dir = build_dir / "renders" / pptx.stem
                try:
                    render_command = [python, str(DECK / "tools/render_pptx_any.py"), str(pptx), str(render_dir), "110", "--keep-pdf"]
                    for directory in fonts["directories"]:
                        render_command += ["--font-directory", directory]
                    if fonts["fontconfig_file"]:
                        render_command += ["--fontconfig-file", fonts["fontconfig_file"]]
                    command(render_command, f"全頁レンダリング {variant}")
                    pdf = render_dir / (pptx.stem + ".pdf")
                    if not pdf.is_file() or pdf.stat().st_size == 0:
                        raise BuildError(f"PDFが生成されていません: {pdf}")
                    rendered = sorted(render_dir.glob("slide-*.png"))
                    expected = {f"slide-{n:02d}.png" for n in range(1, pages + 1)}
                    if {p.name for p in rendered} != expected or any(p.stat().st_size == 0 for p in rendered):
                        raise BuildError(f"全頁描画が未完了: {len(rendered)}/{pages}ページ（{render_dir}）")
                    if not (render_dir / "_render_info.txt").is_file():
                        raise BuildError(f"レンダラー記録がありません: {render_dir}")
                    artifact["render"] = {"status": "passed", "page_count": pages,
                                          "info_path": str(render_dir / "_render_info.txt"),
                                          "pages": [{"page": n, "path": str(render_dir / f"slide-{n:02d}.png"), "sha256": sha256(render_dir / f"slide-{n:02d}.png")} for n in range(1, pages + 1)]}
                    if args.pdf:
                        artifact["pdf"] = {"path": str(output / pdf.name), "sha256": sha256(pdf)}
                except BuildError:
                    status["checks"]["render"] = "failed"
                    raise
            status["artifacts"].append(artifact)
            save()
        status["checks"]["machine_qa"] = "passed"
        if args.render:
            status["checks"]["render"] = "passed"
        current_stage = "成果物公開"
        for (_, _, data, filename), artifact in zip(plans, status["artifacts"]):
            destination = output / filename
            os.replace(stage / filename, destination)
            published.append(destination)
            if artifact["pdf"]:
                pdf_path = Path(artifact["pdf"]["path"])
                shutil.copy2(Path(artifact["render"]["info_path"]).parent / pdf_path.name, pdf_path)
                published.append(pdf_path)
            shutil.copy2(data, case / data.name)
            log = stage / "作業" / f"generation_log_{Path(filename).stem}.md"
            if log.is_file():
                shutil.copy2(log, work / log.name)
        status["status"] = "build_verified"
        status["blockers"] = []
        status["pending_steps"] = [{"stage": "visual_qa", "message": "全ページの目視確認は未実施です。生成・前検成功のみでは配布完了になりません。",
                                    "next_step": "--render（または--pdf）で全頁PNGを生成し、各画像を確認したレビュー記録とfinalize_delivery.pyで確定"}]
        save()
        print(f"build_verified: {len(status['artifacts'])}版。目視QA未確認 / delivery_ready=false\n{status_path}")
        return 0
    except (BuildError, ValueError, OSError, zipfile.BadZipFile, json.JSONDecodeError) as exc:
        # A publication failure must not leave a partial new delivery in output.
        for path in published:
            if path.exists():
                os.replace(path, stage / path.name)
        status["status"] = "incomplete"
        status["delivery_ready"] = False
        status["blockers"] = [{"stage": current_stage, "message": str(exc),
                               "next_step": "記録したコマンドとログを確認し、不足入力・依存・前検NGを解消して同じコマンドを再実行"}]
        save()
        print(f"incomplete: {exc}\n{status_path}", file=sys.stderr)
        return 1


def main(argv=None):
    return execute_build(parse_args(argv))


if __name__ == "__main__":
    raise SystemExit(main())
