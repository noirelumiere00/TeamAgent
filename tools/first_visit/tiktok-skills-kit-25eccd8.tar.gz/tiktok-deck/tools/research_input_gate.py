"""Read-only evidence gate shared by research builders and portable runners.

This validates existing evidence, never creates missing evidence or output files.
An opened declaration records provenance; it cannot prove that an AI viewed an image.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from urllib.parse import urlparse

from check_review_labels import norm
from fvlib import AxisError, load_axis, load_vocab, order_is_display, pr_basis, sha256_file
from label_posts import axes_of, axis_key, validate as validate_labels, window_of


class InputGateError(ValueError):
    def __init__(self, problems):
        self.problems = problems
        super().__init__("入力検証で停止しました（未完了の工程を実施して再実行）:\n" +
                         "\n".join(f"  - {p}" for p in problems))


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise InputGateError([f"入力 {path}: 読めるJSONが必要です。取得/判定工程へ戻る ({exc})"]) from exc


def resolve_review_collect(cfg, explicit_reviews):
    """An explicit legacy --reviews means collect=true; absence never means false."""
    if not isinstance(cfg, dict) or (cfg.get("research") is not None and not isinstance(cfg["research"], dict)):
        raise InputGateError(["受付: case.json と research はJSONオブジェクトが必要です。案件設定を直してください"])
    value = (cfg.get("research") or {}).get("review_collect")
    if value is None and explicit_reviews:
        return True
    if not isinstance(value, bool):
        raise InputGateError(["受付: research.review_collect を true/false で確定してください。"
                              "未回答を口コミなしに変換できません（旧案件は明示 --reviews も可）"])
    if value is False and explicit_reviews:
        raise InputGateError(["受付: review_collect=false と --reviews が矛盾しています。口コミ実施の合意を確認し設定を直す"])
    if value is True and not explicit_reviews:
        raise InputGateError(["口コミ取得: review_collect=true です。収集・分類したフォルダを --reviews で指定する"])
    return value


def _text(value):
    return isinstance(value, str) and bool(value.strip()) and value.strip() not in {
        "…", "...", "TODO", "TBD", "（…）", "（ここに記入）", "[DATA NOT PROVIDED]"}


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _seconds(value):
    if _number(value):
        return float(value)
    if isinstance(value, str) and re.fullmatch(r"\s*\d+(?:\.\d+)?(?:秒)?\s*", value):
        return float(value.strip().removesuffix("秒"))
    return None


def _video_url(url, vid):
    try:
        p = urlparse(url)
        return p.scheme == "https" and p.hostname in {"tiktok.com", "www.tiktok.com"} and bool(
            re.fullmatch(r"/@[^/]+/(?:video|photo)/" + re.escape(vid), p.path.rstrip("/")))
    except (TypeError, ValueError):
        return False


class _Gate:
    def __init__(self, run):
        self.run = Path(run).resolve()
        self.problems = []
        self.checked_images = set()

    def fail(self, step, message, resume):
        self.problems.append(f"{step}: {message}。再開: {resume}")

    def load(self, path, step, resume):
        try:
            return read_json(path)
        except InputGateError:
            self.fail(step, f"JSONが無い/壊れている: {path}", resume)
            return None

    def fields(self, obj, fields, step, resume):
        if not isinstance(obj, dict):
            self.fail(step, "空でないJSONオブジェクトが必要", resume)
            return False
        for field in fields:
            if not _text(obj.get(field)):
                self.fail(step, f"{field} の観測/原稿が空", resume)
        return True

    def image(self, file, vid, step):
        if not isinstance(file, str) or not file.strip():
            self.fail(step, f"{vid} の画像パスが空", "コマ抽出/写真取得から画像を実際に開いて選定する")
            return None
        p = (self.run / file).resolve()
        roots = [(self.run / "frames" / vid).resolve(), (self.run / "media" / f"{vid}_photos").resolve()]
        if not any(p.is_relative_to(root) for root in roots):
            self.fail(step, f"画像と投稿IDが一致しない: {file} / {vid}", "当該投稿の画像パスへ修正する")
            return None
        if p not in self.checked_images:
            try:
                from PIL import Image
                with Image.open(p) as im:
                    im.verify()
                with Image.open(p) as im:
                    im.load()
                    if min(im.size) <= 0:
                        raise ValueError("empty image")
                self.checked_images.add(p)
            except (OSError, ValueError, ImportError) as exc:
                self.fail(step, f"開ける実画像が無い: {file} ({exc})", "画像を再取得/再抽出し、画像を開けるPython環境で再検証する")
        return p

    def frame(self, frame, vid, manifest, photo, step):
        if not isinstance(frame, dict):
            self.fail(step, f"{vid} のコマがオブジェクトではない", "ANALYSIS_SPECに従ってコマを選び直す")
            return None
        p = self.image(frame.get("file"), vid, step)
        sec = _seconds(frame.get("sec"))
        if photo and frame.get("sec") is None:
            pass  # Photos have an image order, but no video timestamp.
        elif sec is None or sec < 0:
            self.fail(step, f"{vid} のコマ時刻が不正: {frame.get('sec')}", "抽出metadataの実時刻を記入する")
        elif not photo and p is not None and isinstance(manifest, dict):
            times = manifest.get("timestamps")
            ix = int(p.stem) - 1 if p.stem.isdigit() else -1
            if not isinstance(times, list) or ix < 0 or ix >= len(times) or not _number(times[ix]) or abs(sec - times[ix]) > 0.25:
                self.fail(step, f"{vid} の {p.name} と {sec}秒がframes.jsonに一致しない", "抽出metadataの実時刻を記入する")
            dur = manifest.get("duration_sec")
            if not _number(dur) or sec > dur + 0.25:
                self.fail(step, f"{vid} の時刻/動画長が不正", "コマを再抽出し実時刻を記入する")
        return p


def _required_count(cfg, key, default, gate):
    n = (cfg.get("research") or {}).get(key, default)
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        gate.fail("受付", f"research.{key} は正の整数が必要", "指定する企画/台本数を確定する")
        return default
    return n


def _validate_search_and_cache(gate, case_dir, cfg, labels):
    """Check the whole labelled search window and its cached first-visit source.

    A selected anatomy is not a substitute for the classifications used by
    search charts. In particular, --reopen must invalidate a cached first visit.
    """
    case = Path(case_dir)
    doc = gate.load(case / "labels.json", "検索判定", "label_posts --init/--contact/--apply/--checkを実行する")
    fv = gate.load(case / "first_visit.json", "初訪原稿", "判定を完了しbuild_first_visit.pyで原稿を再生成する")
    if not isinstance(doc, dict):
        return
    try:
        vocab = load_vocab(cfg, str(case))
        errors, _, _ = validate_labels(str(case), cfg, vocab, {**doc, "posts": list(labels.values())})
        for error in errors:
            gate.fail("検索判定", error, "label_posts --contact/--apply/--checkで全対象を判定する")
    except (SystemExit, OSError, ValueError, KeyError, TypeError) as exc:
        gate.fail("検索判定", f"判定データ/語彙を検証できない: {exc}", "取得JSONとlabels.jsonの形式・語彙を直して全対象を判定する")
        return
    windows = window_of(cfg)
    # Historical label sets predate the extra 21-50 comparison window. Do not
    # invent that extra scope for them, but validate every declared source row.
    declared = doc.get("window") or {}
    compare = declared.get("compare", ((cfg.get("first_visit") or {}).get("window") or {}).get("compare", 0))
    source_files = []
    for axis in axes_of(cfg):
        source_files.append(axis["file"])
        try:
            videos, meta = load_axis(str(case), axis["file"], allow_empty=axis["kind"] != "category")
            ok, why = order_is_display(meta)
            if not ok:
                gate.fail("検索取得", f"{axis_key(axis)}: {why}", "表示順の検索結果を再取得して判定する")
            top = windows["category"] if axis["kind"] == "category" else windows["own"] if axis["kind"] == "own" else windows["brand"]
            for rank, video in enumerate(videos, 1):
                required = rank <= top or (axis["kind"] == "competitor" and bool(pr_basis(video))) or (axis["kind"] != "category" and rank <= compare)
                if not required:
                    continue
                vid = video.get("id")
                post = labels.get(vid, {})
                rows = [a for a in post.get("axes", []) if isinstance(a, dict) and (a.get("kind"), a.get("name")) == (axis["kind"], axis["name"])]
                if len(rows) != 1 or rows[0].get("confirmed") is not True or not _text(rows[0].get("relevance")):
                    gate.fail("検索判定", f"{axis_key(axis)} {rank}位 {vid} の判定が無い/未確定", "当該軸の全対象を実画像で判定する（未判定は0本・言及へ変換しない）")
                elif rows[0].get("rank") != rank or rows[0].get("in_window") is not (rank <= top):
                    gate.fail("検索判定", f"{axis_key(axis)} {vid} の順位/判定窓が取得JSONに一致しない", "label_posts --initから表示順と判定窓を更新する")
        except (AxisError, OSError, ValueError, KeyError, TypeError) as exc:
            gate.fail("検索取得/判定", f"{axis_key(axis)} を照合できない: {exc}", "当該検索を取得し全対象を判定する")
    fingerprints = fv.get("inputs_sha256") if isinstance(fv, dict) else None
    if not isinstance(fingerprints, dict):
        gate.fail("初訪原稿", "first_visit.jsonの元入力の指紋が無い", "build_first_visit.pyで現在の判定から原稿を再生成する")
        return
    for file in ["labels.json", *source_files]:
        if file not in fingerprints or fingerprints[file] != sha256_file(str(case / file)):
            gate.fail("初訪原稿", f"{file} がcached原稿の元入力に一致しない", "現在の取得/判定を確認しbuild_first_visit.pyで原稿を再生成する")
    for file in ("fv_copy.json", "assets/covers/manifest.json"):
        if file in fingerprints and fingerprints[file] != sha256_file(str(case / file)):
            gate.fail("初訪原稿", f"{file} がcached原稿の元入力に一致しない", "build_first_visit.pyで原稿を再生成する")
    if fingerprints.get("_vocab") != vocab.get("_sha"):
        gate.fail("初訪原稿", "語彙がcached原稿の元入力に一致しない", "判定を見直しbuild_first_visit.pyで原稿を再生成する")
    # Old caches only store a byte hash of case.json. Research-only options are
    # routinely added later, so that hash cannot distinguish a stale search
    # setup from an unrelated proposal-count/review option change. Search axes,
    # their raw files and vocabulary are checked directly above.


def _validate_reviews(gate, reviews_dir, cfg, spec):
    rv = Path(reviews_dir)
    log = gate.load(rv / "acquire_log.json", "口コミ取得", "review-scraperで取得し取得ログを保存する")
    products = log.get("products") if isinstance(log, dict) else None
    if not isinstance(products, list) or not products:
        gate.fail("口コミ取得", "取得対象/結果の記録が無い", "商品URLと取得結果をacquire_log.jsonへ記録する")
        products = []
    def jsonl(path):
        try:
            rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
            if any(not isinstance(row, dict) for row in rows):
                raise ValueError("each row must be object")
            return rows
        except (OSError, ValueError) as exc:
            gate.fail("口コミ取得/分類", f"読めるJSONLが無い: {path} ({exc})", "口コミを収集し1件ずつ分類する")
            return []
    source = jsonl(rv / "reviews.jsonl")
    if not source:
        # A parser/permission failure or an empty [] is not an observation of zero reviews.
        zero = products and all(isinstance(p, dict) and p.get("status") == "0件" and
                               p.get("site_total") == 0 and p.get("fetched") == 0 and
                               _text(p.get("url") or p.get("source")) and not p.get("error") for p in products)
        if not zero:
            gate.fail("口コミ取得", "有効な口コミ0件という観測を確認できない（空ファイル/取得失敗は未収集）", "対象URLを取得し0件のサイト表示を取得ログへ記録する")
        return {"status": "observed_zero", "count": 0, "sources": products} if zero else None
    def keys(row):
        values = tuple(row.get(k) for k in ["site", "review_id", "product_id"])
        if not all(_text(v) for v in values):
            gate.fail("口コミ取得/分類", "site/review_id/product_idは空でない文字列が必要", "原文と分類のIDを修正する")
            return ("", "", "")
        return values
    src = {keys(row): row for row in source}
    if any(not all(k) for k in src) or any(not _text(r.get("body")) and not _text(r.get("title")) for r in source):
        gate.fail("口コミ取得", "口コミID・商品ID・サイト・原文が欠けている", "原文を再取得する")
    product_ids = {str(p.get("product_id") or p.get("id")) for p in products if isinstance(p, dict) and
                   p.get("status") in {"OK", "途中で失敗（取れた分のみ）"} and _text(p.get("url") or p.get("source"))}
    if any(str(row.get("product_id")) not in product_ids for row in source):
        gate.fail("口コミ取得", "口コミ原文に対応する取得ログが無い", "取得した商品ID・URLと結果をログへ記録する")
    label_files = sorted((rv / "labels").glob("*.jsonl"))
    if not label_files:
        gate.fail("口コミ分類", "labels/*.jsonl が無い", "取得した口コミを1件ずつ分類する")
    labels, seen = [], set()
    brand_keys = [b.get("review_key") or re.sub(r"\W+", "_", b["name"]).strip("_") for b in cfg["brands"]]
    product_brands = {(p.get("site"), str(p.get("product_id") or p.get("id"))): p.get("brand")
                      for p in products if isinstance(p, dict)}
    for file in label_files:
        rows = jsonl(file)
        brand_key = next((key for key in brand_keys if file.stem == key or file.stem.startswith(key + "_")), None)
        if not brand_key:
            gate.fail("口コミ分類", f"案件のブランドに対応しない分類: {file.name}", "case.jsonのreview_keyに対応するファイルへ分類する")
        by_brand = rv / "by_brand" / file.name
        if by_brand.exists():
            wanted = jsonl(by_brand)
            if {keys(r) for r in wanted} != {keys(r) for r in rows} or len(wanted) != len(rows):
                gate.fail("口コミ分類", f"{file.name} の分類件数/IDがby_brand入力に一致しない", "抜け/他社混入を修正して全件分類する")
        brand_cfg = next((b for b, key in zip(cfg["brands"], brand_keys) if key == brand_key), {})
        aliases = {brand_key, brand_cfg.get("name"), brand_cfg.get("short")} - {None}
        for row in rows:
            key = keys(row)
            acquired_brand = product_brands.get((row.get("site"), str(row.get("product_id"))))
            if acquired_brand and acquired_brand not in aliases or not acquired_brand and not by_brand.exists():
                gate.fail("口コミ分類", f"{file.name} の商品/ブランド対応を照合できない: {key}", "by_brand入力を保存するか取得ログに商品ごとのbrandを記録する")
            if key in seen:
                gate.fail("口コミ分類", f"分類の口コミIDが重複: {key}", "重複を除き1件ずつ判定する")
            seen.add(key)
        labels.extend(rows)
    if seen != set(src):
        gate.fail("口コミ分類", f"原文と分類のID集合が違う（未分類{len(set(src)-seen)} / 不明{len(seen-set(src))}）", "取得した全口コミに対応する分類を保存する")
    effects = set(spec.get("effects", {}))
    allowed = {"effects": effects, "satisfied": effects, "unsatisfied": effects | set(spec.get("unsatisfied", {})),
               "purchase": set(spec.get("purchase", {})), "scene": set(spec.get("scene", {}))}
    for row in labels:
        key = keys(row)
        for field, ids in allowed.items():
            values = row.get(field)
            if not isinstance(values, list) or any(not isinstance(v, str) or v not in ids for v in values):
                gate.fail("口コミ分類", f"{key} の {field} が未判定/分類表外", "分類表に従って判定する（該当なしは明示[]）")
        quote = norm(row.get("quote")) if isinstance(row.get("quote"), str) else ""
        original = src.get(key, {})
        title, body = (original.get(k) if isinstance(original.get(k), str) else "" for k in ["title", "body"])
        has_claim = any(row.get(k) for k in allowed) or any(row.get(k) is True for k in ["brand_trust", "beginner", "gift_or_pr"])
        if (has_claim and not quote) or (quote and quote.rstrip("…") not in norm(title + body)):
            gate.fail("口コミ分類", f"{key} の引用が空/原文に無い", "原文から判定根拠を引用する")
    return {"status": "collected", "count": len(source)}


def validate_research_inputs(*, case_dir, run_dir, cfg, raw, labels, synthesis,
                             selection_path, reviews_dir=None, explicit_reviews=False,
                             part="all", review_spec=None):
    """Return validated selection/anatomy/page/contract, or raise before any write."""
    gate = _Gate(run_dir)
    review_collect = resolve_review_collect(cfg, explicit_reviews)
    _validate_search_and_cache(gate, case_dir, cfg, labels)
    sel = gate.load(selection_path, "Step 8 選定", "分析対象を選びselection.jsonを保存する") if selection_path else None
    if not isinstance(sel, list) or not sel:
        gate.fail("Step 8 選定", "selectionは空でないid付きJSON配列が必要", "分析対象を選ぶ（空の[]で回避しない）")
        sel = []
    ids, selected = [], []
    for row in sel:
        vid = row.get("id") if isinstance(row, dict) else None
        if not isinstance(vid, str) or not re.fullmatch(r"\d{6,25}", vid):
            gate.fail("Step 8 選定", f"投稿IDの型/値が不正: {vid}", "取得したTikTokの文字列IDを記入する")
            continue
        if vid in ids:
            gate.fail("Step 8 選定", f"投稿IDが重複: {vid}", "選定を重複なしに直す")
            continue
        ids.append(vid)
        if vid not in raw:
            gate.fail("Step 8 選定", f"取得JSONに無い投稿ID: {vid}", "検索取得データから分析対象を選ぶ")
            continue
        if not _video_url(raw[vid].get("url"), vid) or (row.get("url") and row["url"] != raw[vid].get("url")):
            gate.fail("Step 8 選定", f"投稿IDとURLが一致しない: {vid}", "取得JSONの当該投稿URLを使用する")
        post = labels.get(vid)
        if not isinstance(post, dict) or not isinstance(post.get("axes"), list) or not post["axes"]:
            gate.fail("検索判定", f"{vid} のlabels判定が無い/空", "検索結果を判定しlabels.jsonを保存する")
        selected.append(row)
    anatomy, page, manifests = {}, {}, {}
    for row in selected:
        vid = row["id"]
        an = gate.load(Path(run_dir) / "anatomy" / f"{vid}.json", "構成分析", "実コマと書き起こしを見てanatomyを作る")
        pg = gate.load(Path(run_dir) / "anatomy_page" / f"{vid}.json", "紙面原稿", "anatomyから紙面用の短い版を作る")
        if not isinstance(an, dict):
            continue
        anatomy[vid] = an
        if an.get("video_id") != vid or (isinstance(pg, dict) and pg.get("video_id") != vid):
            gate.fail("構成分析/紙面原稿", f"投稿IDが一致しない: {vid}", "同じ投稿IDに対応する判定/原稿を作る")
        if an.get("url") and an["url"] != raw[vid].get("url"):
            gate.fail("構成分析", f"URLが一致しない: {vid}", "当該投稿の実物を分析し直す")
        gate.fields(an, ["entry_detail", "creator_type", "headline", "essence", "story", "cta", "observed", "voice", "save_reason_on_screen"], f"構成分析 {vid}", "ANALYSIS_SPECの観測項目を記入する")
        for field in ["problem_first", "has_person"]:
            if not isinstance(an.get(field), bool):
                gate.fail("構成分析", f"{vid} の{field}が未判定", "ANALYSIS_SPECに従いtrue/falseで判定する")
        if not _text(an.get("product_reveal")):
            gate.fail("構成分析", f"{vid} のproduct_revealが未判定", "最初/途中/最後/出ないを記入する")
        entries = (cfg.get("research") or {}).get("entry_labels") or {k: k for k in ["empathy", "ingredient", "product", "demo", "other"]}
        if an.get("entry") not in entries:
            gate.fail("構成分析", f"{vid} のentryが未判定/分類外", "商材の入口分類を判定する")
        for obj, label in [(an, "構成分析"), (pg, "紙面原稿")]:
            if gate.fields(obj, (["headline", "creator_type_short", "essence", "story", "cta"] if label == "紙面原稿" else []), f"{label} {vid}", "観測に基づく原稿を記入する"):
                gate.fields(obj.get("axes"), ["hook", "visual", "telop", "price", "brand", "hypothesis"], f"{label} axes {vid}", "6項目を観測/仮説として記入する")
        if isinstance(pg, dict):
            page[vid] = pg
        frames = an.get("frames")
        photo = raw[vid].get("mediaType") == "photo"
        if photo:
            photo_files = sorted((Path(run_dir) / "media" / f"{vid}_photos").glob("*.jpg"))
            expected = raw[vid].get("imageCount")
            if not isinstance(expected, int) or isinstance(expected, bool) or expected < 1:
                gate.fail("写真取得", f"{vid} の投稿の実写真枚数imageCountが不明", "全写真枚数を取得JSONへ記録する（保存できた枚数だけで例外扱いしない）")
                expected = len(photo_files)
            if not expected or len(photo_files) != expected:
                gate.fail("写真取得", f"{vid} の写真枚数が取得JSONに一致しない", "投稿の全写真を取得する")
            count, manifest = min(5, expected), None
        else:
            count = 5
            manifest = gate.load(Path(run_dir) / "frames" / vid / "frames.json", "コマ抽出", "動画をDLしてextract_framesを実行する")
            manifests[vid] = manifest
            if isinstance(manifest, dict) and (manifest.get("video_id") != vid or manifest.get("coverage_ok") is not True):
                gate.fail("コマ抽出", f"{vid} の投稿ID/全尺カバーが未検証", "動画全尺をコマ抽出する")
            media = Path(run_dir) / "media" / f"{vid}.mp4"
            if not media.is_file() or media.stat().st_size == 0:
                gate.fail("動画DL", f"{vid} の実動画が無い", "当該投稿の動画をDLする")
            tr = gate.load(Path(run_dir) / "transcripts" / f"{vid}.json", "書き起こし", "音声を処理する（発話なしも結果を保存）")
            if isinstance(tr, dict) and (tr.get("video_id") != vid or not isinstance(tr.get("no_speech"), bool) or not isinstance(tr.get("segments"), list)):
                gate.fail("書き起こし", f"{vid} の結果が未完了/ID不一致", "音声の書き起こし/発話なし判定を保存する")
        if not isinstance(frames, list) or len(frames) != count or count < 1:
            gate.fail("構成分析", f"{vid} は{count}コマ必要（写真5枚未満だけ実枚数可）", "実画像から冒頭/途中/締めを選びANALYSIS_SPECに従って追記する")
            frames = frames if isinstance(frames, list) else []
        frame_paths = []
        previous_sec = None
        for index, frame in enumerate(frames, start=1):
            p = gate.frame(frame, vid, manifest, photo, "構成分析コマ")
            sec = _seconds(frame.get("sec")) if isinstance(frame, dict) else None
            if sec is not None and previous_sec is not None and sec < previous_sec:
                gate.fail("構成分析コマ", f"{vid} の{index - 1}→{index}コマが時間順でない（{previous_sec:g}秒→{sec:g}秒）",
                          "anatomy.framesを実時刻の昇順で冒頭→途中→締めに並べ直す（同時刻は可）")
            previous_sec = sec
            if isinstance(frame, dict) and not _text(frame.get("caption")):
                gate.fail("構成分析コマ", f"{vid} のコマ見出しが空", "実画面の短い見出しを書く")
            if p is not None:
                frame_paths.append(p)
        if len(set(frame_paths)) != len(frame_paths):
            gate.fail("構成分析コマ", f"{vid} のコマ画像が重複", "異なる実画像を選ぶ")
        opened = an.get("opened")
        if not isinstance(opened, list) or not opened:
            gate.fail("構成分析", f"{vid} のopened観測記録が空", "実画像を開き、開いたパスを記録する")
            opened = []
        # Older analyses also record optional zoom crops in an ephemeral scratchpad.
        # The required source images below must be present/openable; extra historical
        # paths do not substitute for them and need not survive into a portable kit.
        opened_paths = set()
        for file in opened:
            if isinstance(file, str):
                path = (gate.run / file).resolve()
                opened_paths.add(path)
                if path.is_relative_to(gate.run):
                    gate.image(file, vid, "opened観測記録")
        required_opened = set(frame_paths)
        if photo:
            required_opened.update(p.resolve() for p in photo_files)
        else:
            contact = gate.image(f"frames/{vid}/contact.jpg", vid, "全体観測")
            required_opened.add(contact)
        if not required_opened.issubset(opened_paths):
            gate.fail("構成分析", f"{vid} の選定コマ/全体画像がopenedに無い", "コンタクトシートと各実コマ（写真は全部）を開いて記録する")

    # Validate authored requirements for the selected route, including part overrides.
    syn = synthesis
    if not isinstance(syn, dict) or not syn:
        gate.fail("統合原稿", "authored/synthesis.json が無い/空", "観測を統合して結論・企画・台本を執筆する")
        syn = {}
    def effective(key):
        base = syn.get(key)
        out = dict(base) if isinstance(base, dict) else {}
        override = syn.get(f"{key}_{'first' if part == 'first' else 'concrete'}") if part != "all" else None
        if isinstance(override, dict):
            out.update(override)
        return out
    summary = effective("summary")
    gate.fields(summary, ["headline", "sub"], "結論", "summaryに資料の結論を書く")
    items = summary.get("items")
    if not isinstance(items, list) or len(items) < 3:
        gate.fail("結論", "現状・発見・次の一歩の3項目が必要", "summary.itemsを観測根拠付きで執筆する")
    for item in items if isinstance(items, list) else []:
        gate.fields(item, ["title", "evidence", "implication"], "結論本文", "結論と実データの根拠・意味を書く")
    proposal_count = _required_count(cfg, "proposal_count", 3, gate)
    proposals = effective("proposals")
    gate.fields(proposals, ["headline", "sub"], "企画", "proposalsへ指定数の具体企画を書く")
    pi = proposals.get("items")
    if not isinstance(pi, list) or len(pi) < proposal_count:
        gate.fail("企画", f"指定{proposal_count}本の企画が必要", "proposals.itemsを実投稿の根拠付きで執筆する")
    for item in pi if isinstance(pi, list) else []:
        gate.fields(item, ["title", "body", "evidence"], "企画本文", "企画内容と根拠を書く")
    patterns = syn.get("patterns")
    if not isinstance(patterns, list) or not patterns:
        gate.fail("勝ち型統合", "patterns が無い/空", "分析した投稿から保存/再生される型をまとめる")
    for pattern in patterns if isinstance(patterns, list) else []:
        if gate.fields(pattern, ["headline", "sub"], "勝ち型統合", "観測から型を説明する"):
            rows = pattern.get("items")
            if not isinstance(rows, list) or not rows:
                gate.fail("勝ち型統合", "patterns.items が空", "型の根拠と示唆を書く")
            for item in rows if isinstance(rows, list) else []:
                gate.fields(item, ["title", "evidence", "implication"], "勝ち型本文", "観測根拠と示唆を書く")
    script_count = _required_count(cfg, "script_count", 3, gate) if part != "first" else 0
    scripts = syn.get("scripts")
    if script_count and (not isinstance(scripts, list) or len(scripts) < script_count):
        gate.fail("台本", f"指定{script_count}本の台本が必要", "scriptsへ秒単位の台本を書く")
    for script in (scripts if isinstance(scripts, list) and script_count else []):
        if gate.fields(script, ["headline", "sub", "basis"], "台本本文", "台本と構成の根拠を書く"):
            rows = script.get("rows")
            if not isinstance(rows, list) or not rows:
                gate.fail("台本本文", "台本の秒単位rowsが空", "時間/画/テロップ/発話/ねらいを書く")
            for row in rows if isinstance(rows, list) else []:
                # Photo scripts may intentionally have no speech.
                if not isinstance(row, list) or len(row) < 5 or not all(_text(row[i]) for i in [0, 1, 2, 4]):
                    gate.fail("台本本文", "台本の時間/画/テロップ/ねらいが空", "秒単位の構成を執筆する（発話なしは可）")
    hooks = syn.get("hooks")
    needed_parts = {3} if part == "first" else ({4} if part == "concrete" else {3, 4})
    if not isinstance(hooks, list) or not needed_parts.issubset({h.get("part", 3) for h in hooks if isinstance(h, dict)}):
        gate.fail("秒単位フック", f"パート{sorted(needed_parts)}のhooksが必要", "代表投稿の実コマと発話からhooksを執筆する")
    for hook in hooks if isinstance(hooks, list) else []:
        if isinstance(hook, dict) and hook.get("part", 3) not in needed_parts:
            continue
        if not gate.fields(hook, ["headline", "sub", "video_id"], "秒単位フック", "代表投稿のフックを執筆する"):
            continue
        vid = hook.get("video_id")
        if not isinstance(vid, str) or vid not in anatomy:
            gate.fail("秒単位フック", f"未分析の投稿を参照: {vid}", "selectionで選定し当該投稿を構成分析する")
            continue
        beats = hook.get("beats")
        if not isinstance(beats, list) or not beats:
            gate.fail("秒単位フック", f"{vid} のbeatsが空", "フックの実コマ/時刻/画面の言葉/発話を記入する")
        for beat in beats if isinstance(beats, list) else []:
            gate.frame(beat, vid, manifests.get(vid), raw[vid].get("mediaType") == "photo", "秒単位フック")
            gate.fields(beat, ["telop", "speech"], "秒単位フック本文", "テロップと発話を記入する（無い場合は無しと書く）")
    # Optional references still must point to acquired, analysed evidence.
    def references(value):
        if isinstance(value, dict):
            ref = value.get("reference")
            if isinstance(ref, dict) and ref.get("video_id"):
                vid = ref["video_id"]
                if not isinstance(vid, str) or vid not in raw:
                    gate.fail("原稿の根拠", f"未取得の参照投稿: {vid}", "検索取得データにある根拠へ直す")
                elif ref.get("image"):
                    gate.image(ref["image"], vid, "原稿の参照画像")
            for child in value.values():
                references(child)
        elif isinstance(value, list):
            for child in value:
                references(child)
    references([summary, proposals, patterns, [h for h in (hooks or []) if isinstance(h, dict) and h.get("part", 3) in needed_parts],
                scripts if script_count else []])
    review_observation = _validate_reviews(gate, reviews_dir, cfg, review_spec or {}) if review_collect else None
    if gate.problems:
        raise InputGateError(gate.problems)
    contract = {"schema_version": 1, "route": "research", "part": part, "selected_ids": ids,
                "n_analysed": len(anatomy), "review_collect": review_collect,
                "required_proposal_count": proposal_count, "required_script_count": script_count}
    if review_observation and review_observation["status"] == "observed_zero":
        contract["review_observation"] = review_observation
    return {"selection": sel, "anatomy": anatomy, "page": page, "quality_contract": contract,
            "review_observation": review_observation}
