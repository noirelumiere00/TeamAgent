"""Explicit, portable executable discovery shared by the CLI and doctor.

No installed skill directory or shell is assumed. Explicit overrides are strict:
an invalid override is an error rather than a silent switch to another runtime.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys


def configure_stdio() -> None:
    """Keep CLI output readable when Windows redirects it through an ANSI pipe."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def child_environment() -> dict[str, str]:
    """Use one encoding for child Python output and the parent's captured logs."""
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8:replace"
    environment["PYTHONUTF8"] = "1"
    return environment


def executable(value: str, label: str) -> str:
    expanded = os.path.expanduser(value)
    candidate = shutil.which(expanded)
    if candidate:
        # Keep a venv's symlink path: resolving it changes Python's prefix and
        # silently drops the installed environment's packages.
        return os.path.abspath(candidate)
    path = Path(expanded)
    if path.is_file() and (os.name == "nt" or os.access(path, os.X_OK)):
        return os.path.abspath(path)
    raise ValueError(f"{label} が見つかりません: {value}")


def python_executable(explicit: str | None = None) -> str:
    return executable(explicit or os.environ.get("TIKTOK_SKILLS_PYTHON") or sys.executable, "Python")


def node_executable(explicit: str | None = None) -> str:
    return executable(explicit or os.environ.get("TIKTOK_SKILLS_NODE") or "node", "Node.js")


def find_soffice(explicit: str | None = None) -> str | None:
    override = explicit or os.environ.get("SOFFICE_BINARY")
    if override:
        return executable(override, "LibreOffice")
    for name in ("soffice.com", "soffice", "libreoffice",
                 "/Applications/LibreOffice.app/Contents/MacOS/soffice",
                 "C:/Program Files/LibreOffice/program/soffice.com",
                 "C:/Program Files (x86)/LibreOffice/program/soffice.com",
                 "C:/Program Files/LibreOffice/program/soffice.exe",
                 "C:/Program Files (x86)/LibreOffice/program/soffice.exe"):
        try:
            return executable(name, "LibreOffice")
        except ValueError:
            pass
    return None


def font_settings(directories: list[str] | None = None, config_file: str | None = None) -> dict:
    """Validate explicit renderer font inputs without changing document fonts."""
    values = [*(directories or []), *filter(None, os.environ.get("TIKTOK_FONT_DIRECTORIES", "").split(os.pathsep))]
    paths = []
    for value in values:
        path = Path(value).expanduser().resolve()
        if not path.is_dir():
            raise ValueError(f"font-directory がありません: {value}")
        if str(path) not in paths:
            paths.append(str(path))
    config = config_file or os.environ.get("FONTCONFIG_FILE")
    if config:
        path = Path(config).expanduser().resolve()
        if not path.is_file():
            raise ValueError(f"FONTCONFIG_FILE がありません: {config}")
        config = str(path)
    return {"directories": paths, "fontconfig_file": config, "glyphs_and_format": "unverified: inspect actual rendered images"}


def ytdlp_executable(explicit: str | None = None) -> str | None:
    """Match acquisition order: explicit binary, PATH, configured/kit venv."""
    override = explicit or os.environ.get("YTDLP_BINARY")
    if override:
        return executable(override, "yt-dlp")
    candidate = shutil.which("yt-dlp")
    if candidate:
        return os.path.abspath(candidate)
    venvs = [os.environ.get("TIKTOK_SKILLS_VENV"), str(Path(__file__).resolve().parents[2] / ".venv")]
    for value in filter(None, venvs):
        for relative in ("bin/yt-dlp", "Scripts/yt-dlp.exe", "Scripts/yt-dlp"):
            try:
                return executable(str(Path(value).expanduser() / relative), "yt-dlp")
            except ValueError:
                pass
    return None


def probe(argv: list[str], cwd: Path | None = None) -> dict:
    """Run a bounded, read-only capability probe; never execute through a shell."""
    try:
        result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=20)
        return {"status": "available" if result.returncode == 0 else "unavailable",
                "returncode": result.returncode,
                "detail": (result.stdout.strip() or result.stderr.strip())[:2000]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"status": "unavailable", "detail": str(exc)}


def validate_versions(python: str, node: str) -> None:
    p = probe([python, "-c", "import sys; print('.'.join(map(str,sys.version_info[:3]))); raise SystemExit(0 if sys.version_info >= (3,10) else 1)"])
    if p["status"] != "available":
        raise ValueError(f"基本生成には Python 3.10 以上が必要です: {p['detail']}")
    n = probe([node, "-e", "console.log(process.version);process.exit(Number(process.versions.node.split('.')[0])>=20?0:1)"])
    if n["status"] != "available":
        raise ValueError(f"基本生成には Node.js 20 以上が必要です: {n['detail']}")
