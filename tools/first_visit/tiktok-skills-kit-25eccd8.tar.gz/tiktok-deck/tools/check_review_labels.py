#!/usr/bin/env python3
"""check_review_labels.py — 口コミ判定（<reviews>/labels/*.jsonl）の機械検査

口コミを1件ずつ読んで判定する作業を並列のエージェントに任せたとき、次の事故が実際に起きた（2026-09 N organic）:
  - 共有の作業フォルダで補助スクリプトが上書きされ、他ブランドの判定行が混ざった
  - 判定の件数が入力と合わないまま「全件読んだ」と報告された
そこで、報告ではなく実物で次を確かめる:
  1. 件数が入力（<reviews>/by_brand/<名前>.jsonl）と一致する
  2. review_id の重複が無く、集合が入力と一致する（他ブランドの行が混ざっていない）
  3. 分類の id が分類表（review_spec の effects／unsatisfied／purchase／scene）にある
  4. quote（根拠の引用）が、その口コミの原文（タイトル＋本文）にそのまま含まれる

使い方:
  python3 tools/check_review_labels.py --reviews <口コミのフォルダ> [--spec <分類表.json>] [名前 ...]
  （名前を省くと labels/ の全ファイル。終了コード: 問題なし 0／あり 1）
"""
from __future__ import annotations

import argparse
import collections
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SPEC = os.path.join(HERE, "..", "references", "research", "review_spec_haircare.json")


def norm(s: str | None) -> str:
    return re.sub(r"\s+", "", s or "")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--reviews", required=True, help="reviews.jsonl・by_brand/・labels/ があるフォルダ")
    ap.add_argument("--spec", default=DEFAULT_SPEC, help="分類表（既定はヘアケア用）")
    ap.add_argument("only", nargs="*", help="検査する labels/<名前>.jsonl の名前（省略で全部）")
    a = ap.parse_args()
    rv = os.path.abspath(os.path.expanduser(a.reviews))
    spec = json.load(open(a.spec, encoding="utf-8"))
    eff = set(spec["effects"])
    allow = {"effects": eff, "satisfied": eff, "unsatisfied": eff | set(spec["unsatisfied"]),
             "purchase": set(spec["purchase"]), "scene": set(spec["scene"])}

    src = {}
    for line in open(os.path.join(rv, "reviews.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        src[(r["review_id"], r["product_id"])] = r
    by_brand = {os.path.basename(f)[:-6]: [json.loads(x) for x in open(f, encoding="utf-8") if x.strip()]
                for f in glob.glob(os.path.join(rv, "by_brand", "*.jsonl"))}

    bad = 0
    files = sorted(glob.glob(os.path.join(rv, "labels", "*.jsonl")))
    if not files:
        print(f"labels/*.jsonl がありません: {rv}")
        return 1
    for f in files:
        stem = os.path.basename(f)[:-6]
        if a.only and stem not in a.only:
            continue
        ls = [json.loads(x) for x in open(f, encoding="utf-8") if x.strip()]
        want = by_brand.get(stem)
        probs = []
        keys = [(l["review_id"], l.get("product_id")) for l in ls]
        if want is not None:
            if len(ls) != len(want):
                probs.append(f"件数 {len(ls)} ≠ 入力 {len(want)}")
            if set(keys) != {(r["review_id"], r["product_id"]) for r in want}:
                probs.append("入力と review_id の集合が違う（他の担当の行が混ざった・抜けた可能性）")
        else:
            probs.append(f"入力 by_brand/{stem}.jsonl が無いので件数を照合できない")
        if len(set(keys)) != len(keys):
            probs.append(f"review_id の重複 {len(keys) - len(set(keys))}件")
        qbad = 0
        for l in ls:
            for k, ok in allow.items():
                extra = set(l.get(k) or []) - ok
                if extra:
                    probs.append(f"{l['review_id']} の {k} に分類表に無い id {sorted(extra)}")
            q = norm(l.get("quote"))
            if q:
                r0 = src.get((l["review_id"], l.get("product_id"))) or {}
                if q.rstrip("…") not in norm((r0.get("title") or "") + (r0.get("body") or "")):
                    qbad += 1
        if qbad:
            probs.append(f"引用が原文に無い {qbad}件")
        c = collections.Counter(e for l in ls for e in l.get("effects") or [])
        print(f"{stem}: {len(ls)}件 {'OK' if not probs else 'NG'}  effects上位 {c.most_common(4)}")
        for p in probs[:10]:
            print("   -", p)
        bad += bool(probs)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
