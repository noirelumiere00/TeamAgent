// research.js — 初訪（ストーリー型）＋口コミ調査＋SNSクリエイティブ分析＋個別投稿の構成分析を1本にまとめる
//
// 2026-09 N organic 案件で追加。見本（サプリフィットマスク 口コミ SNS調査）と DHC 本編（具体提案）の
// ページの型を、初訪と同じ版面（クリーム地・明朝見出し・ゴシック本文）で描く。
// 数字はすべて research.json（tools/build_research_json.py が取得データから計算）から読む。ここでは計算しない。
const fs = require('fs');
const path = require('path');
const T = require('../theme');
const { fit, fitBalanced, widthUnits } = require('../helpers/text');
const { addDataTable } = require('../components/comparisonTable');
const SK = require('../components/skin');
const { S, HEAD_MAX, SUB_MAX, flushTalk, useSkin, addStorySlide, addStoryFooter, addBadge, addThumb, addEmptySlot, resetStory } = require('../components/storySlide');
const { countSlide } = require('../components/slideBase');
const { caseRoot } = require('../helpers/caseRoot');
const FVS = require('./firstVisit');
const { fitBox, linkTo } = require('../helpers/imageBox');

const ROOT = caseRoot();
const W = T.content.w;
const X0 = T.margin.l;
const STATS = { images: 0, missing: [], qa: [] };
function researchStats() { return STATS; }

let ACCENT = T.brandColors[0];
let BLUE = T.brandColors[1];
// 大きな数字の色・結論の文の色（スキンで変えられる。FMTでは大きい数字は灰、強調の赤は小さく添えるだけ）
const BIG = () => T.color.bigNumber || ACCENT;
const READ = () => T.color.reading || BLUE;
const SHADOW = () => (SK.getSkin() && SK.getSkin().card_shadow ? { shadow: { ...SK.getSkin().card_shadow } } : {});

// 左上の番号。統合資料ではページ番号と同じにする（ctx.kickOffset=0）。初訪単体は従来どおり表紙を除いた番号
/** 紙面の字の下限（初訪は16pt。build_research_json が project.min_text に入れる。2026-10-06 本人「細かい文字が多く見づらい」） */
const MT = () => T.minText || 14;

function kick(ctx, text) {
  // スキン（FMT）では番号を付けない（ページ番号は右下にだけ出す）
  if (SK.framed()) return text;
  return `${String(ctx.page - (ctx.kickOffset ?? 1)).padStart(2, '0')}　${text}`;
}

/** 案件フォルダの中の画像だけを置く（assets/ 配下）。無ければ記録して null */
function img(rel, where) {
  if (!rel) return null;
  const abs = path.resolve(ROOT, rel);
  if (!abs.startsWith(path.join(ROOT, 'assets') + path.sep) || !fs.existsSync(abs)) {
    STATS.missing.push(`${rel} ← ${where}`);
    return null;
  }
  STATS.images += 1;
  return abs;
}

function para(s, text, box, opt = {}) {
  if (!text) return;
  s.addText(text, {
    x: box.x, y: box.y, w: box.w, h: box.h,
    fontFace: opt.mincho ? T.font.mincho : T.font.gothic,
    fontSize: fit(text, box.w, box.h, { base: opt.size || 13, min: opt.min || 10, lineHeight: opt.lh || 1.4, quiet: true }),
    bold: !!opt.bold, color: opt.color || T.color.text, valign: opt.valign || 'top',
    lineSpacingMultiple: opt.lsm || 1.2, align: opt.align || 'left', margin: 0,
  });
}

// ───────────────────────────────── 章扉（黒地。章の問いと、この章で見せるものだけ）
function slidePart(pptx, pg, ctx) {
  if (SK.framed()) return slidePartSkinned(pptx, pg, ctx);
  if (SK.opt('part_style') === 'numeral') return slidePartNumeral(pptx, pg, ctx);
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.dark };
  s._talk = [];
  s.talk = (t) => { if (t && String(t).trim()) s._talk.push(String(t).trim()); };
  s._headLen = String(pg.title || '').length;
  s.addText(kick(ctx, pg.label || ''), { x: X0, y: 1.55, w: W, h: 0.5, fontFace: T.font.gothic, fontSize: 18, bold: true, color: T.color.partKicker, charSpacing: 1.2, valign: 'middle', margin: 0 });
  s.addText(pg.title || '', { x: X0, y: 2.2, w: W, h: 1.9, fontFace: T.font.mincho, fontSize: fit(pg.title || '', W, 1.9, { base: 48, min: 34, lineHeight: 1.2, quiet: true }), bold: true, color: T.color.darkText, valign: 'middle', margin: 0 });
  s.talk(pg.desc);
  const items = pg.items || [];
  const step = 1.05;
  const y0 = 5.0;
  items.forEach((t, i) => {
    const y = y0 + i * step;
    s.addShape('line', { x: X0, y, w: W, h: 0, line: { color: T.color.darkRule, width: 0.75 } });
    s.addText(String(i + 1).padStart(2, '0'), { x: X0, y: y + 0.12, w: 1.1, h: 0.8, fontFace: T.font.en, fontSize: 26, bold: true, color: T.color.darkSub, valign: 'middle', margin: 0 });
    s.addText(t, { x: X0 + 1.3, y: y + 0.12, w: W - 1.3, h: 0.8, fontFace: T.font.gothic, fontSize: fit(t, W - 1.3, 0.8, { base: 22, min: 18, quiet: true }), color: T.color.darkText, valign: 'middle', margin: 0 });
  });
  if (pg.sources) s.addText(pg.sources, { x: X0, y: y0 + Math.max(items.length, 1) * step + 0.3, w: W, h: 0.6, fontFace: T.font.gothic, fontSize: fit(pg.sources, W, 0.6, { base: 18, min: 16, quiet: true }), color: T.color.darkSub, valign: 'middle', margin: 0 });
  addStoryFooter(s, ctx.footer, true);
  return s;
}

// 中扉（スキンあり）：FMTの白地のまま、見出しの位置に章名、大きな問いと、この章で見せる3つ
function slidePartSkinned(pptx, pg, ctx) {
  const skin = SK.getSkin();
  if (skin.part && skin.part.background) return slidePartBackground(pptx, pg, ctx, skin.part);
  const s = pptx.addSlide();
  countSlide();
  s._talk = [];
  s.talk = (t) => { if (t && String(t).trim()) s._talk.push(String(t).trim()); };
  s._headLen = String(pg.title || '').length;
  SK.drawFrame(s);
  SK.drawTitleBar(s);
  const t = skin.title;
  s.addText(kick(ctx, pg.label || ''), { x: t.x, y: t.y, w: t.w, h: t.h, fontFace: T.font.gothic, fontSize: t.base || 26, bold: true, color: t.color || T.color.text, valign: 'middle', margin: 0 });
  s.addText(pg.title || '', { x: X0, y: 3.1, w: W, h: 1.6, fontFace: T.font.mincho, fontSize: fit(pg.title || '', W - 0.8, 1.6, { base: 46, min: 34, lineHeight: 1.2, quiet: true }), bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  s.talk(pg.desc);
  const items = pg.items || [];
  const y0 = 5.4;
  items.forEach((it, i) => {
    const y = y0 + i * 1.05;
    s.addShape('line', { x: X0, y, w: W, h: 0, line: { color: T.color.ruleThin, width: 0.75 } });
    s.addText(String(i + 1).padStart(2, '0'), { x: X0, y: y + 0.12, w: 1.1, h: 0.8, fontFace: T.font.en, fontSize: 26, bold: true, color: BIG(), valign: 'middle', margin: 0 });
    s.addText(it, { x: X0 + 1.3, y: y + 0.12, w: W - 1.3, h: 0.8, fontFace: T.font.gothic, fontSize: fit(it, W - 1.3, 0.8, { base: 22, min: 18, quiet: true }), color: T.color.text, valign: 'middle', margin: 0 });
  });
  addStoryFooter(s, ctx.footer);
  return s;
}

// 中扉（元のFMT）：黒地・輪郭だけの大きな数字・左下に題・右下にこの章で見せるもの（2026-10-06）
function slidePartNumeral(pptx, pg, ctx) {
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.dark };
  s._talk = [];
  s.talk = (t) => { if (t && String(t).trim()) s._talk.push(String(t).trim()); };
  s._headLen = String(pg.title || '').length;
  const label = String(pg.label || '');
  const m = /PART\s*(\d+)[　 ]*(.*)$/.exec(label);
  const no = m ? m[1] : '';
  const name = m ? m[2].trim() : label;
  SK.setPart(no ? `PART ${no}${name ? ` — ${name}` : ''}` : name);
  s.addText(no ? `PART ${no}${name ? `　${name}` : ''}` : label, { x: X0, y: 0.95, w: 9.0, h: 0.4, fontFace: T.font.gothic, fontSize: Math.max(15, MT()), bold: true, color: T.color.darkSub, charSpacing: 4, valign: 'middle', margin: 0 });
  if (no) s.addText(no, { x: 1.05, y: 1.45, w: 4.0, h: 3.4, fontFace: T.font.en, fontSize: 300, bold: true, color: T.color.dark, outline: { size: 1.1, color: '4A4B50' }, align: 'left', valign: 'middle', margin: 0 });
  // 題は1行に収まるならその大きさで（2行に折ると「いまこ／うなっている」のように語の途中で切れる）
  const tw = 11.0;
  let title = String(pg.title || '');
  const sizeFor = (t) => Math.floor((tw * 72 * 0.92) / Math.max(1, ...t.split('\n').map(widthUnits)));
  if (sizeFor(title) < 28 && !title.includes('\n')) {
    // 2行にするときは、真ん中に近い「、」の後ろで折る（無ければ fit に任せる）
    const cuts = [...title.matchAll(/[、。]/g)].map((m) => m.index + 1).filter((i) => i < title.length);
    if (cuts.length) {
      const mid = title.length / 2;
      const at = cuts.reduce((a, b) => (Math.abs(b - mid) < Math.abs(a - mid) ? b : a));
      title = `${title.slice(0, at)}\n${title.slice(at)}`;
    }
  }
  const tsize = title.includes('\n') || sizeFor(title) >= 28
    ? Math.max(24, Math.min(40, sizeFor(title)))
    : fitBalanced(title, tw, 1.6, { base: 40, min: 28, lineHeight: 1.2, minTail: 6 });
  s.addText(title, { x: X0, y: 6.6, w: tw, h: 1.6, fontFace: T.font.mincho, fontSize: tsize, bold: true, color: T.color.darkText, valign: 'bottom', margin: 0 });
  s.talk(pg.desc);
  if (pg.sources) s.addText(pg.sources, { x: X0, y: 8.45, w: 10.6, h: 0.9, fontFace: T.font.gothic, fontSize: fit(pg.sources, 10.6, 0.9, { base: 18, min: 16, lineHeight: 1.3, quiet: true }), color: T.color.darkText, valign: 'top', margin: 0 });
  const items = pg.items || [];
  const ix = 12.6;
  const iw = T.slide.w - T.margin.r - ix;
  const rowH = Math.min(0.95, 3.6 / Math.max(1, items.length));
  let y = 6.35;
  items.forEach((it, i) => {
    s.addShape('line', { x: ix, y, w: iw, h: 0, line: { color: T.color.darkRule, width: 0.75 } });
    s.addText(String(i + 1).padStart(2, '0'), { x: ix, y: y + 0.1, w: 0.9, h: rowH - 0.16, fontFace: T.font.gothic, fontSize: Math.max(15, MT()), bold: true, color: T.color.darkSub, valign: 'middle', margin: 0 });
    s.addText(it, { x: ix + 1.0, y: y + 0.08, w: iw - 1.0, h: rowH - 0.14, fontFace: T.font.gothic, fontSize: fit(it, iw - 1.0, rowH - 0.14, { base: 17, min: 14, lineHeight: 1.25, quiet: true }), color: T.color.darkText, valign: 'middle', margin: 0 });
    y += rowH;
  });
  if (items.length) s.addShape('line', { x: ix, y, w: iw, h: 0, line: { color: T.color.darkRule, width: 0.75 } });
  addStoryFooter(s, ctx.footer, true);
  return s;
}

// 中扉（スキン：全面の背景画像）。ベクトルのFMT：青の全面に白い題を中央。この章で見せるものは題の下に白で（2026-10-06）
function slidePartBackground(pptx, pg, ctx, part) {
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.dark };
  SK.drawBackground(s, part.background);
  s._talk = [];
  s.talk = (t) => { if (t && String(t).trim()) s._talk.push(String(t).trim()); };
  s._headLen = String(pg.title || '').length;
  const col = part.color || 'FFFFFF';
  const sub = part.sub || 'D6E0EE';
  const items = pg.items || [];
  const ty = items.length ? 2.2 : 3.6;
  s.addText(kick(ctx, pg.label || ''), { x: X0, y: ty - 0.75, w: W, h: 0.55, fontFace: T.font.gothic, fontSize: 22, bold: true, color: sub, align: 'center', valign: 'middle', margin: 0 });
  s.addText(pg.title || '', { x: X0, y: ty, w: W, h: 2.0, fontFace: T.font.mincho, fontSize: fit(pg.title || '', W - 0.8, 2.0, { base: 54, min: 36, lineHeight: 1.25, quiet: true }), bold: true, color: col, align: 'center', valign: 'middle', margin: 0 });
  s.talk(pg.desc);
  const iw = 13.0;
  const ix = (T.slide.w - iw) / 2;
  items.forEach((it, i) => {
    const y = 5.15 + i * 1.0;
    s.addShape('line', { x: ix, y, w: iw, h: 0, line: { color: sub, width: 0.75 } });
    s.addText(String(i + 1).padStart(2, '0'), { x: ix, y: y + 0.1, w: 1.1, h: 0.8, fontFace: T.font.en, fontSize: 26, bold: true, color: sub, valign: 'middle', margin: 0 });
    s.addText(it, { x: ix + 1.3, y: y + 0.1, w: iw - 1.3, h: 0.8, fontFace: T.font.gothic, fontSize: fit(it, iw - 1.3, 0.8, { base: 22, min: 18, quiet: true }), color: col, valign: 'middle', margin: 0 });
  });
  addStoryFooter(s, ctx.footer, true);
  return s;
}

// ───────────────────────────────── 表のページ
// 紙面の表は MAX_ROWS 行まで・字は16pt前後で、行の間をあける。入りきらない行と注記は「話すこと」（ノート）へ回す。
// 比べる表（pg.chart）は棒グラフで見せ、表そのものはノートへ回す
const MAX_ROWS = 6;
const cellStr = (c) => ((c && typeof c === 'object') ? String(c.text ?? '') : String(c ?? '')).trim();
const rowStr = (head, r) => r.map((c, i) => `${(head[i] || '').replace(/\s+/g, '')}:${cellStr(c)}`).filter((x) => !/:$/.test(x)).join('｜');

/**
 * 紙面に載せる行の番号（元の並び順）を返す。行が多い表は、件数の多い行（数字の列の合計が大きい行）と
 * pin_rows・emph_rows を残す。先頭から切ると、並びの後ろにある決め手の行（例：ブランドへの信頼）が落ちるため
 */
function pickRows(all, pg, maxRows) {
  const idx = all.map((_, i) => i);
  if (all.length <= maxRows || pg.keep_order) return idx.slice(0, maxRows);
  const num = (c) => { const m = cellStr(c).replace(/,/g, '').match(/^-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : 0; };
  const weight = (i) => all[i].slice(1).reduce((t, c) => t + num(c), 0);
  const pinned = [...new Set([...(pg.pin_rows || []), ...(pg.emph_rows || [])].map((i) => (i < 0 ? all.length + i : i)))];
  const rest = idx.filter((i) => !pinned.includes(i)).sort((a, b) => weight(b) - weight(a));
  return [...pinned, ...rest].slice(0, maxRows).sort((a, b) => a - b);
}

function drawBars(s, ch, box) {
  const bars = ch.bars || [];
  if (ch.title) s.addText(ch.title, { x: box.x, y: box.y, w: box.w, h: 0.4, fontFace: T.font.gothic, fontSize: Math.max(15, MT()), color: T.color.sub, valign: 'middle', margin: 0 });
  const top = box.y + (ch.title ? 0.65 : 0);
  // 棒が少ないときも紙面の高さを使う（4本で下が2.4in空いていた）
  const rowH = Math.min(1.45, (box.y + box.h - top) / Math.max(bars.length, 1));
  const labelW = 4.6;
  const valW = 2.1;
  const barX = box.x + labelW + 0.2;
  const barW = box.w - labelW - valW - 0.5;
  const max = ch.max || Math.max(...bars.map((b) => b.value), 1e-9);
  bars.forEach((b, i) => {
    const y = top + i * rowH;
    const col = b.emph ? ACCENT : T.color.bar;
    s.addText([{ text: b.label, options: { fontSize: 19, bold: !!b.emph, color: T.color.text } },
      ...(b.sub ? [{ text: `  ${b.sub}`, options: { fontSize: MT(), color: T.color.sub } }] : [])],
    { x: box.x, y, w: labelW, h: rowH * 0.8, fontFace: T.font.gothic, valign: 'middle', margin: 0 });
    const bh = Math.min(0.46, rowH * 0.5);
    const by = y + (rowH * 0.8 - bh) / 2;
    s.addShape('rect', { x: barX, y: by, w: barW, h: bh, fill: { color: T.color.track }, line: { width: 0 } });
    s.addShape('rect', { x: barX, y: by, w: Math.max(0.04, barW * b.value / max), h: bh, fill: { color: col }, line: { width: 0 } });
    s.addText(b.text || String(b.value), { x: barX + barW + 0.2, y, w: valW, h: rowH * 0.8, fontFace: T.font.gothic, fontSize: b.emph ? 26 : 22, bold: true, color: b.emph ? ACCENT : T.color.text, align: 'right', valign: 'middle', margin: 0 });
  });
}

function slideTable(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const head0 = pg.head || [];
  const all = pg.rows || [];
  const y = S.top + 0.25;
  const maxH = S.bottom - y - 0.2;
  if (pg.chart && (pg.chart.bars || []).length) {
    drawBars(s, pg.chart, { x: X0, y, w: W, h: maxH });
    s.talk(`表（${all.length}行）：\n${all.map((r) => rowStr(head0, r)).join('\n')}`);
    s.talk(pg.note);
    return s;
  }
  const maxRows = pg.max_rows || MAX_ROWS;
  const keep = pickRows(all, pg, maxRows);
  const shown = keep.map((i) => all[i]);
  const hidden = all.filter((_, i) => !keep.includes(i));
  if (hidden.length) s.talk(`紙面に載せていない行（${hidden.length}行）：\n${hidden.map((r) => rowStr(head0, r)).join('\n')}`);
  s.talk(pg.note);
  (pg.talk || []).forEach((t) => s.talk(t));   // 口コミの引用など、紙面に載せない根拠（2026-10-06）
  // 大きな数字（pg.big）があれば左に置き、表は右に寄せる
  let tx = X0;
  let tw = W;
  if (pg.big && pg.big.value) {
    const bw = 4.4;
    s.addText(pg.big.value, { x: X0, y: y + 0.2, w: bw, h: 1.5, fontFace: T.font.en, fontSize: 66, bold: true, color: BIG(), valign: 'middle', margin: 0 });
    para(s, pg.big.label || '', { x: X0, y: y + 1.8, w: bw, h: 1.2 }, { size: 17, min: 15, color: T.color.text, bold: true });
    tx = X0 + bw + 0.6;
    tw = W - bw - 0.6;
  }
  // 紙面に載る行で全部空の列は出さない（HARIO の投稿者の表で「広告/PR」が24行とも空だった。2026-10-02）
  const live = head0.map((_, ci) => shown.some((r) => cellStr(r[ci]) !== ''));
  const dropCols = head0.map((_, ci) => ci).filter((ci) => !live[ci] && shown.length);
  if (dropCols.length) s.talk(`空の列を外した：${dropCols.map((ci) => head0[ci]).join('・')}`);
  const keepCol = (_, ci) => !dropCols.includes(ci);
  const n = shown.length;
  const dense = maxRows > MAX_ROWS;
  // 行が少ない表は、行を高く・字を大きくして紙面の高さを使い切る（下半分が空いていた。JCB の表の使い方に合わせる）
  const fontSize = Math.max(MT(), pg.font_size || (dense ? 14 : (n <= 4 ? 20 : n <= 6 ? 18 : 17)));
  const rowH = n ? Math.max(dense ? 0.5 : 0.8, Math.min(dense ? 1.05 : 1.6, (maxH - 0.7) / n)) : undefined;
  const colW = (pg.col_w || head0.map(() => tw / head0.length)).filter(keepCol);
  const rows = shown.map((r) => r.filter(keepCol)).map((r, ri) => r.map((c, ci0) => {
    const ci = head0.map((_, k) => k).filter((k) => !dropCols.includes(k))[ci0];
    const o = (c && typeof c === 'object') ? { ...c } : { text: c };
    if ((pg.align || [])[ci]) o.align = o.align || pg.align[ci];
    if ((pg.emph_rows || []).includes(keep[ri])) { o.bold = true; o.color = o.color || ACCENT; }
    return o;
  }));
  // 答えのマスだけ強調色にする（JCB の表の型）。emph_max='row'＝行ごとに一番大きい数字（社を横に並べた表）、
  // 'col'＝列ごとに一番大きい数字（率を並べた表）。同じ値が並ぶとき・0 のときは塗らない
  if (pg.emph_max) {
    const num = (c) => { const m = cellStr(c).replace(/,/g, '').match(/^-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : null; };
    const mark = (o) => { o.bold = true; o.color = ACCENT; };
    if (pg.emph_max === 'row') {
      rows.forEach((r) => {
        const v = r.map((c, ci) => (ci === 0 ? null : num(c)));
        const mx = Math.max(...v.filter((x) => x !== null));
        if (mx > 0 && v.filter((x) => x === mx).length === 1) mark(r[v.indexOf(mx)]);
      });
    } else {
      (rows[0] || []).forEach((_, ci) => {
        if (ci === 0) return;
        const v = rows.map((r) => num(r[ci]));
        if (v.filter((x) => x !== null).length < 2) return;
        const mx = Math.max(...v.filter((x) => x !== null));
        if (mx > 0 && v.filter((x) => x === mx).length === 1) mark(rows[v.indexOf(mx)][ci]);
      });
    }
  }
  const head = head0.map((h, ci) => ({ text: h, align: (pg.align || [])[ci] || 'left' })).filter(keepCol);
  // 見出しで言ったことを表の中で見せる（JCB は各表の答えのマスを強調色にした）。強調が1つも無い表は生成ログに出す
  const hasEmph = (pg.emph_rows || []).length || pg.big || rows.some((r) => r.some((c) => c.color || c.bold));
  if (!hasEmph && !pg.appendix && !pg.no_emph && !/^付録/.test(pg.kicker || '')) STATS.qa.push(`強調の無い表 p${ctx.page || '?'}: 「${String(pg.headline || '').slice(0, 20)}」（見出しの答えの行を emph_rows で示す）`);
  addDataTable(s, { x: tx, y, w: tw, head, rows, colW, fontSize, rowH, headFontSize: Math.max(14, MT()), maxH, minFs: MT(), labelFill: pg.label_fill ? T.color.labelFill : null });
  return s;
}

// ───────────────────────────────── 1-2-3 の読み解き
// 紙面は「言い切り（title）」と「だから何（implication）」だけ。根拠の文（evidence）は話すことへ。
// 決め手の数字（stat）があれば、右に大きく置く
function slideInsights(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const items = pg.items || [];
  const top = S.top + 0.2;
  const per = (S.bottom - top) / Math.max(items.length, 1);
  const numW = 1.0;
  const rightW = SK.framed() ? 6.65 : 6.4;
  const leftW = W - numW - rightW - 0.6;
  items.forEach((it, i) => {
    const y = top + i * per;
    if (i > 0) s.addShape('line', { x: X0, y, w: W, h: 0, line: { color: T.color.ruleThin, width: 0.8 } });
    const h = per - 0.2;
    s.addText(String(i + 1), { x: X0, y: y + 0.1, w: numW, h, fontFace: T.font.en, fontSize: 48, bold: true, color: T.color.numGhost, valign: 'middle', margin: 0 });
    para(s, it.title, { x: X0 + numW, y: y + 0.1, w: leftW, h }, { size: 24, bold: true, min: 18, valign: 'middle', lh: 1.3 });
    const rx = X0 + numW + leftW + 0.6;
    if (it.stat) {
      s.addText(it.stat, { x: rx, y: y + 0.1, w: rightW, h: h * 0.6, fontFace: T.font.gothic, fontSize: fit(it.stat, rightW, h * 0.6, { base: 40, min: 24, quiet: true }), bold: true, color: BIG(), valign: 'bottom', margin: 0 });
      para(s, it.stat_label || it.implication, { x: rx, y: y + 0.1 + h * 0.62, w: rightW, h: h * 0.38 }, { size: 16, min: 14, color: T.color.sub });
    } else {
      para(s, it.implication, { x: rx, y: y + 0.1, w: rightW, h }, { size: 19, bold: true, min: 15, color: READ(), valign: 'middle', lh: 1.4 });
    }
    s.talk(`${i + 1}. ${it.title}\n${it.evidence || ''}${it.stat && it.stat_label && it.implication ? `\n→ ${it.implication}` : ''}`);
  });
  return s;
}

// ───────────────────────────────── 指標別 TOP5（ファミマ式）
function slideTop5(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const cards = (pg.cards || []).slice(0, 5);
  const gap = 0.28;
  const cw = (W - gap * 4) / 5;
  const hasFactors = (pg.factors || []).length > 0;
  let top = S.top + 0.05;
  // 全部の数字を並べるカード（再生数・ENG率・保存数 TOP5。2026-10-05 参考資料「冷凍食品 コンビニ」の項目）
  const full = cards.some((c) => c.full_stats);
  const nSt = full ? Math.max(...cards.map((c) => (c.stats || []).length), 1) : 2;
  const ROW = MT() >= 16 ? 0.35 : 0.30;
  const LINE = MT() >= 16 ? 0.34 : 0.30;
  // アカウントとフォロワーは別行にする。長いIDの折返しが指標に重ならないよう、実際の2行分を確保する。
  const META_H = LINE * 2;
  const textH = full ? 0.36 + META_H + 0.52 + nSt * ROW + LINE + 0.02 : 0;
  // 共通点が無いページは画像を大きく。カードの高さは中身に合わせる（下に余白を溜めない）
  const fullH = hasFactors ? S.bottom - top - 0.2 - 1.75 : S.bottom - top - 0.05;
  const imgH = full ? Math.max(1.6, Math.min(4.2, fullH - 0.24 - 0.06 - textH))
    : hasFactors ? 2.95 : Math.min(4.6, S.bottom - top - 0.05 - 2.4);
  const imgW0 = Math.min(cw - 0.24, imgH * 9 / 16);
  const pad = (hasFactors || full) ? 0.12 : Math.max(0.12, (cw - imgW0) / 2);
  const CARD_H = full ? pad + imgH + 0.06 + textH + pad : hasFactors ? 4.95 : pad + imgH + 0.06 + 0.48 + 0.52 + 0.68 + pad;
  if (!hasFactors) top = S.top + Math.max(0.05, (S.bottom - S.top - CARD_H) / 2);
  cards.forEach((c, i) => {
    const x = X0 + i * (cw + gap);
    s.addShape('rect', { x, y: top, w: cw, h: CARD_H, fill: { color: T.color.cardBg }, line: { color: T.color.cardLine, width: 0.75 }, ...SHADOW() });
    const abs = img(c.cover, `TOP5 ${c.video_id}`);
    const box = { x: x + 0.12, y: top + pad, w: cw - 0.24, h: imgH };
    const b = abs ? addThumb(s, abs, box, c.url) : (addEmptySlot(s, box, '画像なし'), box);
    const no = (pg.rank_start || 1) + i;
    addBadge(s, { x: b.x + 0.06, y: b.y + 0.06, text: String(no), w: no >= 10 ? 0.52 : 0.40, h: 0.40, size: 15, fill: ACCENT });
    if (c.is_pr) addBadge(s, { x: b.x + b.w - 0.62, y: b.y + 0.06, text: 'PR', fill: ACCENT, w: 0.56, h: 0.36, size: Math.max(14, MT() - 2) });
    let y = top + pad + 0.06 + imgH;
    // 名前と数字は画像の左右の端にそろえる（画像は縦長で中央に寄るため）
    // 画像が細いと数字の欄も細くなり、桁が折れて切れた（「14,90」2026-10-06）。細いときはカードの幅を使う
    const narrow = b.w < cw - 0.6;
    const tx = c.caption_line && !narrow ? b.x : x + 0.14;
    const tw = c.caption_line && !narrow ? b.w : cw - 0.28;
    if (full) {
      // 表示名（太字）→ @アカウント｜フォロワー → 指標の値 → その他の数字 → 投稿日｜尺
      // 表示名は1行に収まる長さで切る（2行に折れると下の @アカウントの行に重なった）。参考資料と同じく「…」
      const maxU = Math.floor(((cw - 0.28) * 72 * 0.92) / 15);
      let nm = String(c.display_name || `@${c.author}`); let u = 0; let cut = '';
      for (const ch of nm) { u += /[\x00-\x7F]/.test(ch) ? 0.55 : 1; if (u > maxU - 1) { cut += '…'; break; } cut += ch; }
      nm = cut;
      s.addText(nm, { x: x + 0.14, y, w: cw - 0.28, h: 0.34, fontFace: T.font.gothic, fontSize: Math.max(15, MT()), bold: true, color: T.color.text, valign: 'middle', margin: 0 });
      y += 0.36;
      para(s, `@${c.author}${c.followers_label ? `\nフォロワー ${c.followers_label}` : ''}`, { x: x + 0.14, y, w: cw - 0.28, h: META_H - 0.02 }, { size: MT(), min: 14, color: T.color.sub, lh: 1.1 });
      y += META_H;
      s.addText([{ text: c.value_label, options: { fontSize: 24, bold: true, color: BIG() } }, { text: `  ${c.value_unit || ''}`, options: { fontSize: MT(), color: T.color.sub } }],
        { x: x + 0.14, y, w: cw - 0.28, h: 0.50, fontFace: T.font.gothic, valign: 'middle', margin: 0 });
      y += 0.52;
      (c.stats || []).forEach(([k, v]) => {
        s.addText(k, { x: x + 0.14, y, w: 1.3, h: ROW, fontFace: T.font.gothic, fontSize: MT(), color: T.color.sub, valign: 'middle', margin: 0 });
        s.addText(v, { x: x + 1.44, y, w: cw - 1.58, h: ROW, fontFace: T.font.gothic, fontSize: MT(), bold: true, color: T.color.text, align: 'right', valign: 'middle', margin: 0 });
        y += ROW;
      });
      if (c.posted) para(s, c.posted, { x: x + 0.14, y: y + 0.02, w: cw - 0.28, h: LINE - 0.02 }, { size: MT(), min: 14, color: T.color.sub, lh: 1.1 });
      s.talk(`${no}. ${c.display_name || ''}（@${c.author}）${c.value_label}${c.value_unit || ''}${c.meta ? `／${String(c.meta).replace(/\n/g, '／')}` : ''}`);
      return;
    }
    if (c.caption_line) {
      // 比べる主語（投稿名）は、カードの中で数字と同じくらい読める大きさにする
      para(s, c.caption_line, { x: tx, y: y + 0.04, w: tw, h: 0.40 }, { size: 16, min: 14, color: T.color.text });
      y += 0.48;
    } else {
      para(s, `@${c.author}${c.followers_label ? `｜Fw ${c.followers_label}` : ''}`, { x: x + 0.14, y, w: cw - 0.28, h: 0.30 }, { size: MT(), min: 14, color: T.color.sub });
      y += 0.32;
    }
    s.addText([{ text: c.value_label, options: { fontSize: 24, bold: true, color: BIG() } }, { text: `  ${c.value_unit || ''}`, options: { fontSize: MT(), color: T.color.sub } }],
      { x: tx, y, w: tw, h: 0.50, fontFace: T.font.gothic, valign: 'middle', margin: 0 });
    y += 0.52;
    (c.stats || []).slice(0, 2).forEach(([k, v]) => {
      s.addText(k, { x: tx, y, w: 1.6, h: 0.32, fontFace: T.font.gothic, fontSize: MT(), color: T.color.sub, valign: 'middle', margin: 0 });
      s.addText(v, { x: tx + 1.6, y, w: Math.max(0.6, tw - 1.6), h: 0.32, fontFace: T.font.gothic, fontSize: MT(), bold: true, color: T.color.text, align: 'right', valign: 'middle', margin: 0 });
      y += 0.34;
    });
    s.talk(`${no}. ${c.author ? `@${c.author}` : (c.caption_line || '')}（${c.value_label}${c.value_unit || ''}）：${(c.stats || []).map(([k, v]) => `${k}${v}`).join('・')}${c.meta ? `／${String(c.meta).replace(/\n/g, '／')}` : ''}`);
  });
  // 下の囲み：上位を狙うために必要な要素（無ければ出さない）
  if (!hasFactors) return s;
  const by = top + CARD_H + 0.2;
  const bh = S.bottom - by - 0.05;
  s.addShape('rect', { x: X0, y: by, w: W, h: bh, fill: { color: T.color.panel }, line: { color: T.color.panel, width: 0.5 } });
  s.addText(pg.factors_title || '', { x: X0 + 0.3, y: by + 0.15, w: W - 0.6, h: 0.4, fontFace: T.font.gothic, fontSize: 16, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  // 要因は1行ずつ。括弧の補足と2文目以降は話すことへ
  const fl = (pg.factors || []).slice(0, 3);
  const fh = (bh - 0.7) / Math.max(fl.length, 1);
  fl.forEach((f, i) => {
    // 括弧の補足と2文目以降は話すことへ（途中で切らない）
    const head = String(f).replace(/[（(][^）)]*[）)]/g, '').split('。')[0].trim();
    if (head !== f) s.talk(`上位の共通点${i + 1}：${f}`);
    s.addText(String(i + 1), { x: X0 + 0.3, y: by + 0.62 + i * fh, w: 0.4, h: fh, fontFace: T.font.en, fontSize: 17, bold: true, color: BIG(), valign: 'middle', margin: 0 });
    para(s, head, { x: X0 + 0.75, y: by + 0.62 + i * fh, w: W - 1.05, h: fh }, { size: 17, min: 14, valign: 'middle' });
  });
  return s;
}

// ② 一般検索ワードごと：検索画面の上位8本と、再生・ENG率・保存の上位3本（2026-10-06 本人
// 「生活者の検索するワードで何が上位表示され、再生、ENG、保存されているか」）
function slideKw(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const fs = Math.max(16, MT());
  const top = S.top + 0.02;
  s.addText('検索画面の表示順（上位8本）', { x: X0, y: top, w: 9, h: 0.4, fontFace: T.font.gothic, fontSize: fs, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  const strip = (pg.strip || []).slice(0, 8);
  const th = 2.6;
  const tw = th * 9 / 16;
  const step = strip.length > 1 ? (W - tw) / 7 : 0;
  strip.forEach((c, i) => {
    const x = X0 + i * step;
    const box = { x, y: top + 0.48, w: tw, h: th };
    const abs = img(c.cover, `検索画面 ${c.video_id}`);
    const b = abs ? addThumb(s, abs, box, c.url) : (addEmptySlot(s, box, '画像なし'), box);
    if (c.is_pr) addBadge(s, { x: b.x + b.w - 0.62, y: b.y + 0.06, text: 'PR', fill: ACCENT, w: 0.56, h: 0.36, size: 14 });
    s.addText(`${c.rank}位 ▶${c.views_label || ''}`, { x: x - 0.2, y: top + 0.52 + th, w: tw + 0.4, h: 0.36, fontFace: T.font.gothic, fontSize: fs, bold: true, color: T.color.text, align: 'center', valign: 'middle', margin: 0 });
    s.talk(`${c.rank}位　${c.views_label || ''}再生　${c.url || ''}`);
  });
  const y0 = top + 0.48 + th + 0.62;
  const gap = 0.45;
  const cw = (W - gap * 2) / 3;
  const iw = (cw - 0.3) / 3;
  const ih = Math.min(1.9, S.bottom - (y0 + 0.48) - 0.78);
  (pg.cols || []).slice(0, 3).forEach((col, j) => {
    const cx = X0 + j * (cw + gap);
    s.addShape('line', { x: cx, y: y0, w: cw, h: 0, line: { color: T.color.rule, width: 1.0 } });
    s.addText(col.title || '', { x: cx, y: y0 + 0.04, w: cw, h: 0.4, fontFace: T.font.gothic, fontSize: fs, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
    (col.items || []).slice(0, 3).forEach((it, k) => {
      const ix = cx + k * (iw + 0.15);
      const box = { x: ix + (iw - ih * 9 / 16) / 2, y: y0 + 0.5, w: ih * 9 / 16, h: ih };
      const abs = img(it.cover, `上位3本 ${it.video_id}`);
      const b = abs ? addThumb(s, abs, box, it.url) : (addEmptySlot(s, box, '画像なし'), box);
      addBadge(s, { x: b.x + 0.05, y: b.y + 0.05, text: String(k + 1), w: 0.36, h: 0.36, size: 14, fill: ACCENT });
      s.addText(it.value || '', { x: ix - 0.05, y: y0 + 0.54 + ih, w: iw + 0.1, h: 0.36, fontFace: T.font.gothic, fontSize: fs, bold: true, color: k === 0 ? BIG() : T.color.text, align: 'center', valign: 'middle', margin: 0 });
      para(s, it.angle || `@${it.author || ''}`, { x: ix - 0.05, y: y0 + 0.9 + ih, w: iw + 0.1, h: 0.34 }, { size: fs, min: 14, color: T.color.sub, align: 'center', lh: 1.1 });
      s.talk(`${col.title} ${k + 1}位：@${it.author || ''}　${it.value || ''}　${it.angle || ''}　${it.url || ''}`);
    });
    if (!(col.items || []).length) s.addText('該当なし', { x: cx, y: y0 + 0.6, w: cw, h: 0.5, fontFace: T.font.gothic, fontSize: fs, color: T.color.subLight, valign: 'middle', margin: 0 });
  });
  s.talk(pg.note);
  return s;
}

// ───────────────────────────────── 個別投稿の構成分析（2枚組：8軸／5コマ）
const AXES = [
  ['hook', 'フック（0〜3秒）'], ['visual', '視覚演出'],
  ['telop', 'テロップ・発話'], ['price', '価格・スペック'],
  ['brand', '商品識別'], ['hypothesis', '伸び方の仮説'],
];

function videoHeader(pptx, v, ctx, sub) {
  return addStorySlide(pptx, {
    kicker: kick(ctx, `構成分析 ${v.no}/${v.total}｜${v.entry}｜@${v.author}`),
    headline: v.headline, sub, footer: ctx.footer,
  });
}

function slideVideoA(pptx, v, ctx) {
  const s = videoHeader(pptx, v, ctx, v.meta);
  const top = S.top + 0.05;
  // 左：冒頭のコマ（無ければカバー）
  const abs = img(v.lead_image, `構成分析 ${v.video_id}`);
  const box = { x: X0, y: top, w: 3.6, h: 6.40 };
  if (abs) addThumb(s, abs, box, v.url); else addEmptySlot(s, box, '画像なし');
  // 右上：数字
  const nx = X0 + 4.05;
  const nw = W - 4.05;
  const kpis = v.kpis || [];
  const kw = nw / Math.max(kpis.length, 1);
  kpis.forEach(([k, val], i) => {
    const x = nx + i * kw;
    s.addShape('rect', { x: x + 0.04, y: top, w: kw - 0.08, h: 0.72, fill: { color: i === kpis.length - 1 ? BLUE : 'FFFFFF' }, line: { color: T.color.cardLine, width: 0.75 } });
    s.addText([{ text: `${k}  `, options: { fontSize: 10.5, color: i === kpis.length - 1 ? 'DDE3F0' : T.color.sub } }, { text: val, options: { fontSize: 16, bold: true, color: i === kpis.length - 1 ? 'FFFFFF' : T.color.text } }],
      { x: x + 0.04, y: top, w: kw - 0.08, h: 0.72, fontFace: T.font.gothic, align: 'center', valign: 'middle', margin: 0 });
  });
  // 右下：6軸
  const gy = top + 0.95;
  const colW = (nw - 0.4) / 2;
  const rowH = ((v.essence ? S.bottom - 0.62 : box.y + box.h) - gy) / 3;
  AXES.forEach(([key, label], i) => {
    const x = nx + (i % 2) * (colW + 0.4);
    const y = gy + Math.floor(i / 2) * rowH;
    s.addShape('rect', { x, y: y + 0.08, w: 0.14, h: 0.14, fill: { color: key === 'hypothesis' ? BLUE : T.color.text }, line: { width: 0 } });
    s.addText(label, { x: x + 0.25, y, w: colW - 0.25, h: 0.32, fontFace: T.font.gothic, fontSize: 13, bold: true, color: key === 'hypothesis' ? BLUE : T.color.text, valign: 'middle', margin: 0 });
    para(s, (v.axes || {})[key] || '（未記入）', { x: x + 0.25, y: y + 0.36, w: colW - 0.25, h: rowH - 0.46 }, { size: 11.5, min: 9.5, lh: 1.45 });
  });
  // 下：本質1行
  if (v.essence) {
    const ey = S.bottom - 0.50;
    s.addShape('rect', { x: X0, y: ey, w: 1.5, h: 0.46, fill: { color: BLUE }, line: { width: 0 } });
    s.addText('本質1行', { x: X0, y: ey, w: 1.5, h: 0.46, fontFace: T.font.gothic, fontSize: 12, bold: true, color: 'FFFFFF', align: 'center', valign: 'middle', margin: 0 });
    para(s, v.essence, { x: X0 + 1.7, y: ey, w: W - 1.7, h: 0.46 }, { size: 15, bold: true, mincho: true, valign: 'middle', min: 11 });
  }
  return s;
}

function slideVideoB(pptx, v, ctx) {
  const s = videoHeader(pptx, v, ctx, v.frames_note || '5コマで見る「どう始まり、何を見せ、どう終わるか」');
  const frames = (v.frames || []).slice(0, 5);
  const n = Math.max(frames.length, 1);
  const gap = 0.55;
  const fw = Math.min(2.9, (W - gap * (n - 1)) / n);
  const fh = Math.min(fw * 16 / 9, 4.5);
  const top = S.top + 0.05;
  const total = n * fw + (n - 1) * gap;
  const x0 = X0 + (W - total) / 2;
  frames.forEach((f, i) => {
    const x = x0 + i * (fw + gap);
    addBadge(s, { x, y: top, text: f.label_no || String(i + 1).padStart(2, '0'), fill: BLUE, w: 0.52, h: 0.30, size: 11 });
    const abs = img(f.path, `構成分析 ${v.video_id} コマ${f.label_no}`);
    const box = { x, y: top + 0.38, w: fw, h: fh };
    if (abs) addThumb(s, abs, box, v.url); else addEmptySlot(s, box, '画像なし');
    para(s, f.caption, { x: x - 0.1, y: top + 0.45 + fh, w: fw + 0.2, h: 0.62 }, { size: 11.5, bold: true, align: 'center', min: 9.5 });
    if (i < n - 1) s.addText('→', { x: x + fw + 0.08, y: top + 0.38 + fh / 2 - 0.2, w: gap - 0.16, h: 0.4, fontFace: T.font.gothic, fontSize: 14, color: T.color.subLight, align: 'center', valign: 'middle', margin: 0 });
  });
  const ty = top + 0.45 + fh + 0.72;
  s.addShape('line', { x: X0, y: ty - 0.08, w: W, h: 0, line: { color: T.color.ruleThin, width: 0.75 } });
  const lines = [v.story, v.cta ? `行動喚起（CTA）：${v.cta}` : null, v.observed ? `観察範囲：${v.observed}` : null, v.url ? `URL：${v.url}` : null].filter(Boolean);
  para(s, lines.join('\n'), { x: X0, y: ty, w: W, h: S.bottom - ty }, { size: 12, min: 9.5, lh: 1.45, color: T.color.text });
  return s;
}

// ───────────────────────────────── 提案（まずこの3本）
// カード＝番号・題・型のチップ・参考の投稿（大きく）。本文と根拠は話すことへ
function slideProposals(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer, tag: '提案（仮説）' });
  const items = (pg.items || []).slice(0, 3);
  const gap = 0.4;
  const cw = (W - gap * (items.length - 1)) / Math.max(items.length, 1);
  const top = S.top + 0.05;
  const ch = S.bottom - top - 0.05;
  items.forEach((it, i) => {
    const number = (pg.item_offset || 0) + i + 1;
    const x = X0 + i * (cw + gap);
    s.addShape('rect', { x, y: top, w: cw, h: ch, fill: { color: T.color.cardBg }, line: { color: T.color.cardLine, width: 0.75 } });
    s.addText(String(number).padStart(2, '0'), { x: x + 0.3, y: top + 0.2, w: 1.2, h: 0.6, fontFace: T.font.en, fontSize: 30, bold: true, color: BIG(), valign: 'middle', margin: 0 });
    para(s, it.title, { x: x + 0.3, y: top + 0.85, w: cw - 0.6, h: 1.0 }, { size: 21, bold: true, mincho: true, min: 16 });
    s.talk(`案${number}「${it.title}」\n${it.body || ''}${it.evidence ? `\n根拠：${String(it.evidence).replace(/^根拠[：:]/, '')}` : ''}`);
    const by = top + 2.05;
    const bh = ch - 2.05 - 0.25;
    // 左：参考の投稿（縦長のまま大きく）／右：型のチップを縦に
    let rx = x + 0.3;
    if (it.reference) {
      const refH = bh - 0.45;
      const refW = Math.min(refH * 9 / 16, cw * 0.45);
      const abs = img(it.reference.cover, `提案 参考 ${it.reference.video_id}`);
      const box = { x: x + 0.3, y: by, w: refW, h: refW * 16 / 9 };
      if (abs) addThumb(s, abs, box, it.reference.url); else addEmptySlot(s, box, '画像なし');
      para(s, it.reference.label || '参考にした投稿', { x: x + 0.3, y: by + box.h + 0.06, w: Math.max(refW, 2.4), h: 0.4 }, { size: MT(), min: 14, color: T.color.sub, lh: 1.15 });
      rx = x + 0.3 + refW + 0.3;
    }
    const chipW = x + cw - 0.3 - rx;
    let y = by;
    (it.chips || []).forEach(([label, text]) => {
      s.addText(label, { x: rx, y, w: chipW, h: 0.32, fontFace: T.font.gothic, fontSize: Math.max(13, MT() - 1), color: T.color.sub, valign: 'middle', margin: 0 });
      const c = label === '型' ? ACCENT : T.color.chipDark;
      s.addShape('rect', { x: rx, y: y + 0.36, w: chipW, h: 0.62, fill: { color: c }, line: { width: 0 } });
      s.addText(text, { x: rx + 0.1, y: y + 0.36, w: chipW - 0.2, h: 0.62, fontFace: T.font.gothic, fontSize: fit(text, chipW - 0.2, 0.62, { base: Math.max(16, MT()), min: Math.min(16, MT()), lineHeight: 1.1, quiet: true }), bold: true, color: 'FFFFFF', align: 'center', valign: 'middle', margin: 0 });
      y += 1.2;
    });
    if (it.point) para(s, it.point, { x: rx, y: y + 0.1, w: chipW, h: by + bh - y - 0.1 }, { size: 16, bold: true, min: 14, color: READ(), lh: 1.35 });
  });
  return s;
}


// ───────────────────────────────── 代表1本の秒単位フック
// 上：秒ごとのコマ＋テロップ（発話は話すことへ）。下の帯：この冒頭でやっていること3つを横に並べる
function slideHook(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const beats = (pg.beats || []).slice(0, 5);
  const n = Math.max(beats.length, 1);
  const top = S.top + 0.1;
  const bandH = 1.55;
  const bandY = S.bottom - bandH;
  const telopH = 0.75;
  const fh = bandY - 0.3 - telopH - 0.42 - top;
  const fw = Math.min(fh * 9 / 16, (W - 0.5 * (n - 1)) / n);
  const gap = n > 1 ? Math.min(1.2, (W - fw * n) / (n - 1)) : 0;
  const x0 = X0 + (W - (fw * n + gap * (n - 1))) / 2;
  beats.forEach((b, i) => {
    const x = x0 + i * (fw + gap);
    addBadge(s, { x, y: top, text: b.sec, fill: ACCENT, w: 1.0, h: 0.34, size: 14 });
    const abs = img(b.path, `フック ${pg.video_id} ${b.sec}`);
    const box = { x, y: top + 0.42, w: fw, h: fh };
    if (abs) addThumb(s, abs, box, pg.url); else addEmptySlot(s, box, '画像なし');
    para(s, b.telop || '—', { x: x - 0.15, y: top + 0.5 + fh, w: fw + 0.3, h: telopH }, { size: MT(), bold: true, min: 14, align: 'center', lh: 1.2 });
    if (i < n - 1) s.addText('→', { x: x + fw, y: top + 0.42 + fh / 2 - 0.25, w: gap, h: 0.5, fontFace: T.font.gothic, fontSize: 18, color: T.color.subLight, align: 'center', valign: 'middle', margin: 0 });
    s.talk(`${b.sec}　テロップ「${b.telop || '—'}」　発話「${b.speech || '—'}」`);
  });
  // 下の帯：要点は3つまで。「：」の後ろ（何をしているか）を載せ、全文は話すことへ
  const ptsAll = pg.points || [];
  ptsAll.forEach((t, i) => s.talk(`要点${i + 1}：${t}`));
  const pts = ptsAll.slice(0, 3);
  s.addShape('rect', { x: X0, y: bandY, w: W, h: bandH, fill: { color: T.color.panel }, line: { color: T.color.panel, width: 0.5 } });
  s.addText(pg.point_title || 'この冒頭でやっていること', { x: X0 + 0.3, y: bandY + 0.12, w: W - 0.6, h: 0.36, fontFace: T.font.gothic, fontSize: Math.max(14, MT()), bold: true, color: T.color.sub, valign: 'middle', margin: 0 });
  const cwp = (W - 0.6) / Math.max(pts.length, 1);
  pts.forEach((t, i) => {
    const str = String(t);
    const k = str.indexOf('：');
    const body = (k >= 0 && k < str.length - 4 ? str.slice(k + 1) : str).split('。')[0];
    const x = X0 + 0.3 + i * cwp;
    s.addText(`${i + 1}`, { x, y: bandY + 0.55, w: 0.4, h: 0.85, fontFace: T.font.en, fontSize: 22, bold: true, color: BIG(), valign: 'middle', margin: 0 });
    para(s, body, { x: x + 0.45, y: bandY + 0.55, w: cwp - 0.75, h: 0.85 }, { size: 16, bold: true, min: 14, valign: 'middle', lh: 1.35 });
  });
  return s;
}

// ───────────────────────────────── 1本1枚の比較カード（10本を同じ配置で見比べる）
// 左：決まった瞬間のコマ3つ／右上：数字4つ／右下：事実の行（ラベル＋短い値）／左下：読み解き1行。長い文は話すことへ
function slideVideoCard(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const top = S.top + 0.15;
  const shots = (pg.shots || []).slice(0, 3);
  const fw = SK.framed() ? 2.6 : 2.45;
  const fh = fw * 16 / 9;
  const gap = SK.framed() ? 0.3 : 0.4;
  shots.forEach((f, i) => {
    const x = X0 + i * (fw + gap);
    addBadge(s, { x, y: top, text: f.label, fill: f.accent ? ACCENT : T.color.chipDark, w: fw, h: 0.38, size: 14 });
    const abs = img(f.path, `カード ${pg.video_id} ${f.label}`);
    const box = { x, y: top + 0.44, w: fw, h: fh };
    if (abs) addThumb(s, abs, box, pg.url); else addEmptySlot(s, box, '画像なし');
  });
  const leftW = shots.length * fw + (shots.length - 1) * gap;
  if (pg.reading) {
    const ry = top + 0.44 + fh + 0.3;
    para(s, pg.reading, { x: X0, y: ry, w: leftW, h: S.bottom - ry }, { size: 17, bold: true, min: 14, color: READ(), lh: 1.35, valign: SK.framed() ? 'bottom' : 'top' });
  }
  const rx = X0 + leftW + 0.7;
  const rw = X0 + W - rx;
  const kpis = (pg.kpis || []).slice(0, 4);
  const kw = (rw - 0.3) / 2;
  const kh = 1.05;
  kpis.forEach(([k, v, emph0], i) => {
    const emph = pg.emph_kpi != null ? pg.emph_kpi === i : emph0;
    const x = rx + (i % 2) * (kw + 0.3);
    const y = top + Math.floor(i / 2) * (kh + 0.25);
    s.addShape('rect', { x, y, w: kw, h: kh, fill: { color: emph ? T.color.emphFill : 'FFFFFF' }, line: { color: T.color.cardLine, width: 0.75 }, ...SHADOW() });
    s.addText(k, { x: x + 0.2, y: y + 0.08, w: kw - 0.4, h: 0.34, fontFace: T.font.gothic, fontSize: Math.max(14, MT()), color: emph ? T.color.emphLabel : T.color.sub, valign: 'middle', margin: 0 });
    s.addText(v, { x: x + 0.2, y: y + 0.42, w: kw - 0.4, h: 0.56, fontFace: T.font.gothic, fontSize: 24, bold: true, color: emph ? ACCENT : T.color.text, valign: 'middle', margin: 0 });
  });
  const fy = top + 2 * (kh + 0.25) + 0.1;
  const facts = (pg.facts || []).slice(0, 6);
  const fhh = (S.bottom - fy) / Math.max(facts.length, 1);
  facts.forEach(([k, v], i) => {
    const y = fy + i * fhh;
    s.addShape('line', { x: rx, y, w: rw, h: 0, line: { color: T.color.ruleThin, width: 0.75 } });
    if (T.color.labelFill) s.addShape('rect', { x: rx, y: y + 0.05, w: 2.0, h: fhh - 0.1, fill: { color: T.color.labelFill }, line: { color: T.color.labelFill, width: 0 } });
    s.addText(k, { x: rx + (T.color.labelFill ? 0.15 : 0), y, w: 1.85, h: fhh, fontFace: T.font.gothic, fontSize: Math.max(14, MT()), bold: !!T.color.labelFill, color: T.color.labelFill ? T.color.text : T.color.sub, valign: 'middle', margin: 0 });
    const vx = T.color.labelFill ? 2.2 : 2.4;
    para(s, v, { x: rx + vx, y: y + 0.04, w: rw - vx, h: fhh - 0.08 }, { size: Math.max(15, MT()), min: 15, valign: 'middle', lh: 1.3 });
    if (fit(v, rw - vx, fhh - 0.08, { base: 15, min: 6, lineHeight: 1.3, quiet: true }) < 15) STATS.qa.push(`カードの事実が長い p${ctx.page}: 「${String(v).slice(0, 18)}…」（15ptで収まらない）`);
  });
  if (facts.length) s.addShape('line', { x: rx, y: fy + facts.length * fhh, w: rw, h: 0, line: { color: T.color.ruleThin, width: 0.75 } });
  (pg.talk || []).forEach((t) => s.talk(t));
  return s;
}

// ───────────────────────────────── 終わりのページ（スキンのFMTの「thank you！」）
function slideEnd(pptx, pg) {
  const s = pptx.addSlide();
  countSlide();
  s._talk = [];
  SK.drawFrame(s);
  s.addText(pg.text || 'thank you！', { x: 0, y: 4.7, w: T.slide.w, h: 1.4, fontFace: (SK.getSkin() && SK.getSkin().end_font) || T.font.en, fontSize: 43, bold: true, color: (SK.getSkin() && SK.getSkin().end_color) || T.color.text, align: 'center', valign: 'middle', margin: 0 });
  return s;
}

// ───────────────────────────────── 図1枚＋要点（図は案件の assets/ に置いた画像。要点は3つまで・言い切りだけ）
function slideFigure(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const top = S.top + 0.1;
  const h = S.bottom - top - 0.05;
  const pts = (pg.points || []).slice(0, 3);
  const figW = pts.length ? W * 0.66 : W;
  const abs = img(pg.image, `図 ${pg.kicker || ''}`);
  if (abs) {

    s.addImage({ path: abs, ...fitBox(abs, X0, top, figW, h) });
  } else addEmptySlot(s, { x: X0, y: top, w: figW, h }, '図なし');
  if (pts.length) {
    const px = X0 + figW + 0.5;
    const pw = W - figW - 0.5;
    const ph = h / pts.length;
    pts.forEach((t, i) => {
      const y = top + i * ph;
      if (i > 0) s.addShape('line', { x: px, y, w: pw, h: 0, line: { color: T.color.ruleThin, width: 0.8 } });
      s.addText(String(i + 1), { x: px, y: y + 0.15, w: 0.5, h: ph - 0.3, fontFace: T.font.en, fontSize: 24, bold: true, color: BIG(), valign: 'middle', margin: 0 });
      para(s, t, { x: px + 0.55, y: y + 0.15, w: pw - 0.55, h: ph - 0.3 }, { size: 18, bold: true, min: 14, lh: 1.35, valign: 'middle' });
    });
  }
  (pg.talk || []).forEach((t) => s.talk(t));
  return s;
}

// ───────────────────────────────── 投稿案の秒単位台本
function slideScript(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer, tag: '提案（仮説）' });
  const top = S.top + 0.05;
  const lw = 4.3;
  // 左：企画の骨子
  s.addShape('rect', { x: X0, y: top, w: lw, h: S.bottom - top - 0.05, fill: { color: T.color.cardBg }, line: { color: T.color.cardLine, width: 0.75 } });
  let y = top + 0.2;
  // 企画の骨子は3項目まで紙面に（尺・投稿者・商品）。残り（保存の理由など）は話すことへ（2026-10-02 字の量の見直し）
  const specsAll = pg.specs || [];
  const specs = specsAll.slice(0, 3);
  specsAll.slice(3).forEach(([k, v]) => s.talk(`${k}：${v}`));
  const step = 1.15;
  specs.forEach(([k, v]) => {
    s.addText(k, { x: X0 + 0.2, y, w: lw - 0.4, h: 0.3, fontFace: T.font.gothic, fontSize: 14, color: T.color.sub, margin: 0 });
    para(s, v, { x: X0 + 0.2, y: y + 0.32, w: lw - 0.4, h: step - 0.38 }, { size: 16, bold: true, min: 14 });
    y += step;
  });
  if (pg.reference) {
    // 参考画像は左の枠の下端（S.bottom-0.15）に収める。仕様が多いときは小さくする
    const avail = S.bottom - 0.15 - (y + 0.28);
    const rw = Math.max(0.8, Math.min(1.35, avail * 9 / 16));
    const abs = img(pg.reference.cover, `台本 参考 ${pg.reference.video_id}`);
    const box = { x: X0 + 0.2, y: y + 0.28, w: rw, h: Math.min(rw * 16 / 9, avail) };
    s.addText('参考にした投稿', { x: X0 + 0.2, y, w: lw - 0.4, h: 0.26, fontFace: T.font.gothic, fontSize: 14, color: T.color.sub, margin: 0 });
    if (abs) addThumb(s, abs, box, pg.reference.url); else addEmptySlot(s, box, '画像なし');
    // 紙面には投稿者と数字の1行目だけ。説明はノートへ（10pt で3行並んでいた）
    const refLines = String(pg.reference.label || '').split('\n');
    para(s, refLines[0] || '', { x: X0 + 0.2 + rw + 0.15, y: y + 0.28, w: lw - 0.55 - rw, h: box.h }, { size: 14, min: 14, color: T.color.sub, lh: 1.4 });
    if (refLines.length > 1) s.talk(`参考にした投稿：${refLines.join('／')}`);
  }
  // 右：秒単位の台本
  const tx = X0 + lw + 0.3;
  const tw = W - lw - 0.3;
  // 3列（秒／画／テロップと発話）。「ねらい」は話すことへ（紙面は撮る人が見る中身だけ。2026-10-02 字の量の見直し）
  const head = ['秒', '画（カット）', 'テロップ ／ 発話'].map((h) => ({ text: h }));
  const rows = (pg.rows || []).map((r) => [{ text: r[0], bold: true, color: ACCENT }, r[1],
    { text: [r[2], r[3] ? (/^[「（(]/.test(String(r[3])) ? r[3] : `「${r[3]}」`) : ''].filter(Boolean).join('\n') }]);
  (pg.rows || []).forEach((r) => { if (r[4]) s.talk(`${r[0]}　ねらい：${r[4]}`); });
  const nr = Math.max(rows.length, 1);
  addDataTable(s, { x: tx, y: top, w: tw, head, rows, colW: [1.6, 4.9, 6.6], fontSize: 16, headFontSize: 14, minFs: 14, rowH: Math.min(1.2, (S.bottom - top - 0.8) / nr), maxH: S.bottom - top - 0.05 });
  s.talk(pg.basis ? `根拠：${pg.basis}` : '');
  return s;
}

/** 話すことをノートに書き、見出しの長さを検査する（2026-09-30 FB：上に「何を語るか」を短く） */
/** ノートの先頭：このページは何を見て、何を出しているか（2026-10-06 打ち合わせ。質問されたとき営業が答えられるように） */
function howNotes(s, how) {
  if (!s || !how) return;
  s.addNotes(`【このページは何を見て、何を出しているか】\n${Object.entries(how).map(([k, v]) => `${k}：${v}`).join('\n')}\n\n`);
}

function finishTalk(s, pg, page) {
  if (!s) return;
  howNotes(s, pg.how);
  if ((s._headLen || 0) > HEAD_MAX) STATS.qa.push(`見出しが長い p${page}: ${s._headLen}字（上限${HEAD_MAX}）「${String(pg.headline || pg.title || '').slice(0, 20)}…」`);
  if (pg.sub && String(pg.sub).length > SUB_MAX) STATS.qa.push(`補足をノートへ回した p${page}: ${String(pg.sub).length}字（紙面は${SUB_MAX}字まで）`);
  flushTalk(s);
}

// ───────────────────────────────── 口コミの実画面（写し）。2026-10-06 本人「写し＋URLで飛べると確証が出せる」
// 資料に引用した口コミの、その1件の枠の画面（tools/review_shots.js で撮る）を並べ、画像と下の文字にその口コミのURLを付ける。
// 価格.com は1件ずつのページが開く。マイベストは1件ずつのページが無いので、商品ページへのリンクと「引用した文」で示す
// pg: {kicker, headline, sub, shots:[{png, url, label, tone:'good'|'bad', caption, quote, site}]}
function slideReviewShots(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kick(ctx, pg.kicker || ''), headline: pg.headline, sub: pg.sub || '', footer: ctx.footer });
  const shots = (pg.shots || []).slice(0, 3);
  const gap = 0.45;
  const cw = (W - gap * (shots.length - 1)) / Math.max(1, shots.length);
  const y0 = S.top + 0.2;
  shots.forEach((sh, i) => {
    const x = X0 + i * (cw + gap);
    const bad = sh.tone === 'bad';
    const col = bad ? T.color.sub : ACCENT;
    s.addText(sh.label || '', { x, y: y0, w: cw, h: 0.5, fontFace: T.font.gothic, fontSize: 18, bold: true, color: col, valign: 'middle', margin: 0 });
    const abs = img(sh.png, `口コミの写し ${sh.label || ''}`);
    const iy = y0 + 0.6;
    const maxH = S.bottom - iy - 1.25;
    let ih = 0;
    if (abs) {
      const b = { ...fitBox(abs, x, iy, cw, maxH), y: iy };   // 上に揃える（下の文字と重ならないように）
      s.addImage({ path: abs, ...b, ...linkTo(sh.url) });
      s.addShape('rect', { ...b, fill: { type: 'none' }, line: { color: T.color.ruleThin, width: 0.75 } });
      ih = b.h;
    }
    const ty = iy + ih + 0.15;
    s.addText(sh.caption || '', { x, y: ty, w: cw, h: 0.45, fontFace: T.font.gothic, fontSize: 14, color: T.color.sub, valign: 'top', margin: 0 });
    s.addText([{ text: sh.site === 'kakaku' ? '▶ 元の口コミを開く（価格.com）' : '▶ 商品ページの口コミ欄を開く', options: { hyperlink: { url: sh.url }, color: READ(), underline: true } }],
      { x, y: ty + 0.45, w: cw, h: 0.42, fontFace: T.font.gothic, fontSize: 14, valign: 'top', margin: 0 });
    s.talk(`${sh.label}：「${sh.quote}」（${sh.caption}）${sh.url}`);
  });
  s.talk(pg.note);
  return s;
}

const RENDER = {
  hook: slideHook, script: slideScript, figure: slideFigure, videocard: slideVideoCard, end: slideEnd,
  part: slidePart, table: slideTable, insights: slideInsights, top5: slideTop5, proposals: slideProposals, kwpage: slideKw, reviewshots: slideReviewShots,
};

/** 付録の前提：JCB と同じ1枚の表（7行まで・14pt以上）。各項目は紙面に1文目だけ、全文は話すことへ */
function slidePremise(pptx, ap, ctx, csvName, override = {}) {
  const all = (ap.premise || []).map(([k, v]) => [k, String(v || '')]);
  const first = (v) => { const m = v.match(/^[^。]*。?/); return (m ? m[0] : v).trim(); };
  const rows = all.slice(0, 7).map(([k, v]) => [k, first(v)]);
  const s = slideTable(pptx, { type: 'table', kicker: '付録　調査の前提', headline: override.headline || '調査の前提', sub: override.sub ?? '数字の出どころと、判定のしかた',
    head: ['項目', '内容'], rows, align: ['left', 'left'], col_w: [3.0, 14.7], max_rows: 7, font_size: 15, label_fill: true, appendix: true }, ctx);
  all.forEach(([k, v], i) => { if (i >= 7 || first(v) !== v) s.talk(`${k}：${v}`); });
  if (csvName) s.talk(`数字の一覧は別ファイル「${csvName}」（表計算で開ける）`);
  return s;
}

/** 数字の一覧（検索ごとの取得・判定の件数、切り口の分布）を CSV に書く。返り値はファイル名（書けなければ null） */
function writeNumbersCsv(ap, deckFile) {
  if (!ap || (!ap.table && !ap.matrix)) return null;
  const q = (c) => `"${String(c && typeof c === 'object' ? c.text : (c ?? '')).replace(/"/g, '""')}"`;
  const lines = [];
  for (const t of [ap.table, ap.matrix]) {
    if (!t || !(t.rows || []).length) continue;
    if (t.title) lines.push(q(t.title));
    lines.push((t.head || []).map(q).join(','));
    t.rows.forEach((r) => lines.push(r.map(q).join(',')));
    lines.push('');
  }
  const name = String(deckFile || 'deck.pptx').replace(/\.pptx$/, '') + '_数字の一覧.csv';
  try {
    const dir = path.join(ROOT || process.cwd(), 'output', '作業');   // 数字の一覧は作業用（output/ にはパワポと PDF だけ）
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, name), '\ufeff' + lines.join('\n'), 'utf8');   // Excel で文字化けしないよう BOM 付き
    return name;
  } catch (e) { STATS.qa.push(`数字の一覧を書けなかった: ${e.message}`); return null; }
}

/** research.json の pages を順に描く。返り値は枚数 */
function buildResearch(pptx, fv, rs) {
  // 案件のFMTに外側の見た目を合わせる（project.skin が無ければ今までどおり）
  T.minText = Number(rs.project.min_text) || 14;
  (rs.project.qa_notes || []).forEach((t) => STATS.qa.push(t));
  if (rs.project.skin) {
    useSkin(rs.project.skin, ROOT);
    ACCENT = T.brandColors[0];
    BLUE = T.brandColors[1];
  }
  // 枚数を先に数える（フッターの「NN / 総数」）
  let total = 1;
  rs.pages.forEach((p) => { total += p.type === 'video' ? 2 : 1; });
  resetStory(total);
  const ctx = { footer: rs.project.footer || fv.project.footer || '', client: fv.project.client_short, page: 1, kickOffset: 0 };
  // 表紙は初訪の表紙（題名だけ差し替え）
  const fvCover = { ...fv, cover_cards: rs.project.cover_cards || fv.cover_cards, project: { ...fv.project, cover_title: rs.project.cover_title || fv.project.cover_title, cover_kicker: rs.project.cover_kicker, cover_sub: rs.project.cover_sub, cover_style: rs.project.cover_style || fv.project.cover_style, cover_brands: rs.project.cover_brands, cover_keywords: rs.project.cover_keywords } };
  FVS.slideCover(pptx, fvCover);
  FVS.addStoryFooterSkip();
  rs.pages.forEach((p) => {
    ctx.page += 1;
    // 次回・付録は章の外（右上の「PART n — …」を持ち越さない）
    if ((p.type === 'fv' && (p.page === 'next' || p.page === 'appendix')) || p.appendix) SK.setPart('');
    if (p.type === 'fv') {
      if (p.page === 'appendix') {
        // 付録は1枚（前提の表）。数字の一覧は紙面に載せず、表計算で開けるファイルにして添える（2026-10-02：9.5pt で詰まっていた）
        const csv = writeNumbersCsv(fv.appendix, rs.project.file);
        const ps = slidePremise(pptx, p.appendix || fv.appendix, ctx, csv, p.override);
        howNotes(ps, p.how);
        flushTalk(ps);
        return;
      }
      const fn = { now: FVS.slideNow, competitors: FVS.slideCompetitors, winning: FVS.slideWinning, plans: FVS.slidePlans, next: FVS.slideNext }[p.page];
      if (!fn || !fv.pages[p.page]) { STATS.qa.push(`初訪ページ ${p.page} が first_visit.json に無い`); ctx.page -= 1; return; }
      const pg = { ...fv.pages[p.page], ...(p.override || {}), query: fv.project.query, how: p.how };
      const fs_ = fn(pptx, pg, ctx);
      // 写真だけのページにも話すことを残す（検索画面・競合のページのノートが空だった。2026-10-02）
      if (fs_ && p.page === 'now') (pg.cards || []).forEach((c) => fs_.talk(`${c.rank}位　${c.views_label || ''}再生　${c.url || ''}`));
      if (fs_ && p.page === 'competitors') (pg.columns || []).filter((c) => !c.note_line).forEach((c) => fs_.talk(`${c.short || c.brand}：${c.n ?? ''}本${c.angle ? `。多い切り口は「${c.angle.label}」${c.angle.count}本` : ''}`));
      finishTalk(fs_, pg, ctx.page);
      return;
    }
    if (p.type === 'video') {
      flushTalk(slideVideoA(pptx, p, ctx));
      ctx.page += 1;
      flushTalk(slideVideoB(pptx, p, ctx));
      return;
    }
    const fn = RENDER[p.type];
    if (!fn) { STATS.qa.push(`未知のページ種別 ${p.type}`); ctx.page -= 1; return; }
    finishTalk(fn(pptx, p, ctx), p, ctx.page);
  });
  return total;
}

module.exports = { buildResearch, researchStats, pickRows };
