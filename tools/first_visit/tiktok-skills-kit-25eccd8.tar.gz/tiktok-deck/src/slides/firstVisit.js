// firstVisit.js — 初訪資料（本編8枚＋付録2枚以内）
//
// 2026-09 上長FBで作り直した。狙う感情は「この人たちは競合も市場も見てきている。役に立つ」。
//   P1 表紙 → P2 いま検索するとこう見える → P3 競合はこう発信している
//   → P4 競合がお金をかけて広げている訴求（成立するときだけ）→ P5 貴社に足りていない発信
//   → P6 いま伸びている型（お土産）→ P7 まずこの3本 → P8 次回 → 付録1 前提 → 付録2 数字
// 1枚＝実画像＋ワンフレーズ。数値・文言はすべて tools/build_first_visit.py が first_visit.json に
// 作ったものをそのまま置く（ここでは計算も言い換えもしない）。
const fs = require('fs');
const path = require('path');
const T = require('../theme');
const { fit, fitBalanced, widthUnits } = require('../helpers/text');
const { addDataTable } = require('../components/comparisonTable');
const { S, addStorySlide, addBadge, addThumb, addEmptySlot, resetStory, addStoryFooter } = require('../components/storySlide');
const { countSlide } = require('../components/slideBase');
const { caseRoot } = require('../helpers/caseRoot');
const SK = require('../components/skin');
const { fitBox, imageSize, linkTo } = require('../helpers/imageBox');

const ROOT = caseRoot();
const W = T.content.w;
const X0 = T.margin.l;
// 文字数の上限は Python 側（build_first_visit.py / preflight.py）と同じファイルを読む
const LIMITS = (() => {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'tools', 'vocab', '_limits.json'), 'utf8')); } catch (e) { return { body_chars: 160 }; }
})();

const FV = { images: 0, missing: [], qa: [], page: 0, notes: [] };
function fvStats() { return FV; }

function brandColor(i) { return T.brandColors[(i || 0) % T.brandColors.length]; }
const BC = () => T.brandColors[0];   // 強調色（自社・市場の数字）

/** キッカー「NN　…」。番号は紙面の並び（表紙の次を01）。P4 が落ちても 01,02,04… と飛ばさない。
 *  文言は build_first_visit.py が状況に合わせて決める（勝ち型が無いのに「伸びている型」と書かない等） */
function kicker(ctx, pg, fallback) {
  return `${String(ctx.page - (ctx.kickOffset ?? 1)).padStart(2, '0')}　${pg.kicker || fallback}`;
}

/**
 * 案件ディレクトリ基準で画像を解決。無ければ記録して null（ダミーで埋めない）。
 * 置いてよいのは assets/covers/<その投稿のID>.jpg だけ（first_visit.json を手で書き換えて
 * ラベルの無い投稿の画像や案件外のファイルを差し込めないようにする）
 */
function cover(p, where, vid) {
  if (!p) return null;
  const abs = path.resolve(ROOT, p);
  const ok = /^\d{6,25}$/.test(String(vid || ''));
  // 表紙用に 9:16 に切った写し（assets/covers_916/<投稿ID>.jpg）も、同じ投稿IDなら使ってよい
  const want = ok ? [path.join(ROOT, 'assets', 'covers', `${vid}.jpg`), path.join(ROOT, 'assets', 'covers_916', `${vid}.jpg`)] : [];
  if (!want.includes(abs)) {
    FV.missing.push(`${p} ← ${where}（assets/covers/<投稿ID>.jpg 以外は置かない）`);
    return null;
  }
  if (!fs.existsSync(abs)) {
    FV.missing.push(`${p} ← ${where}`);
    return null;
  }
  FV.images += 1;
  return abs;
}

/** そのページで使った投稿をノートに残す（紙の資料を見ながら「…624491 を差し替え」と言えるように） */
function note(c) {
  if (!c || !c.video_id) return;
  FV.notes.push(`…${c.video_id.slice(-6)}　@${c.author || ''}　${c.axis || ''} ${c.rank ? c.rank + '位' : ''}　${c.video_id}　${c.url || ''}`);
}

function finishPage(s, pageNo, expect) {
  // 先方に渡す版（--client）ではノートを付けない（社内のファイル名が残るため）
  if (FV.notes.length && process.env.TIKTOK_DECK_CLIENT !== '1') s.addNotes(`この頁の投稿（ラベルは labels.json・前日レビューは review/初訪_レビュー.html）\n${FV.notes.join('\n')}`);
  FV.notes = [];
  if (s._fvChars > (LIMITS.body_chars || 160)) {
    FV.qa.push(`FV文字量超過 p${pageNo}: 本文${s._fvChars}字/${LIMITS.body_chars || 160}`);
  }
  if (expect && expect.have < expect.want) {
    FV.qa.push(`FVカード不足 p${pageNo}: ${expect.have}/${expect.want}（${expect.why}）`);
  }
}

/** カバー＋（左上）順位バッジ＋（右上）PR/公式バッジ＋（下）再生数 */
function thumbCard(s, c, box, opt = {}) {
  const abs = cover(c && c.cover, opt.where || '?', c && c.video_id);
  const b = abs ? addThumb(s, abs, box, c.url) : null;
  if (!b) {
    addEmptySlot(s, box, '画像なし');
    return box;
  }
  note(c);
  if (c.media === 'photo') {
    // 写真カルーセルは1枚目しか見えない。動画と同じに見せない
    addBadge(s, { x: b.x + 0.08, y: b.y + b.h - 0.38, text: c.image_count ? `写真${c.image_count}枚` : '写真', fill: '55524C' });
  }
  if (opt.rank && c.rank) addBadge(s, { x: b.x + 0.08, y: b.y + 0.08, text: `${c.rank}位`, size: 12 });
  const badges = [];
  if (c.is_pr) badges.push(['PR', 'A24765']);
  if (c.poster === 'official') badges.push(['公式', '2F5397']);
  let bx = b.x + b.w - 0.08;
  badges.forEach(([t, col]) => {
    const w = 0.16 + t.length * 0.20;
    bx -= w;
    addBadge(s, { x: bx, y: b.y + 0.08, text: t, fill: col, w });
    bx -= 0.06;
  });
  if (opt.views !== false && c.views_label) {
    s.addText(`▶ ${c.views_label}`, {
      x: b.x, y: b.y + b.h + 0.04, w: b.w, h: 0.30,
      fontFace: T.font.gothic, fontSize: Math.max(opt.viewsSize || 12, minf()), bold: true, color: T.color.text, valign: 'top',
    });
  }
  return b;
}

// 字の下限。調査と提案の資料（build_research.js）は話す資料の約束で 14pt。旧初訪は 0（今の大きさのまま）
// 字の下限。環境変数（既定14）と、初訪の16pt（T.minText。2026-10-06）の大きい方。呼ぶたびに読む
const MINF_ENV = Number(process.env.TIKTOK_DECK_MIN_FONT || 0);
const minf = () => Math.max(MINF_ENV, T.minText || 0);

/** チップ（切り口・訴求の短い名前）。ラベル付き */
function chip(s, { x, y, w, label, text, color }) {
  s.addText(label, {
    x, y, w: 0.9, h: 0.40,
    fontFace: T.font.gothic, fontSize: Math.max(11, minf()), color: T.color.sub, valign: 'middle',
  });
  s.addShape('rect', { x: x + 0.92, y: y + 0.02, w: w - 0.92, h: 0.36, fill: { color: color || T.color.chipDark }, line: { width: 0 } });
  s.addText(text, {
    x: x + 0.92, y: y + 0.02, w: w - 0.92, h: 0.36,
    fontFace: T.font.gothic, fontSize: fit(text, w - 0.92, 0.36, { base: 15, min: Math.max(10, minf()), lineHeight: 1.0, quiet: true }),
    bold: true, color: 'FFFFFF', align: 'center', valign: 'middle', margin: 0,
  });
}

// 表紙（スキンあり）：FMTの表紙と同じく、左に宛名・題・日付、右に画像1枚
function slideCoverSkinned(pptx, fv) {
  const p = fv.project;
  const skin = SK.getSkin();
  const c = skin.cover || {};
  if (c.background) return slideCoverBackground(pptx, fv, c);
  const s = pptx.addSlide();
  countSlide();
  SK.drawFrame(s);
  const L = c.left || { x: 2.0, y: 3.2, w: 6.0 };
  const sz = c.sizes || [26, 28, 20, 18];
  const lines = [
    [p.recipient || '', sz[0], true],
    [p.cover_title || '', sz[1], true],
    [p.date_label || '', sz[2], false],
    [p.producer || '', sz[3], false],
  ].filter(([t]) => t);
  let y = L.y;
  lines.forEach(([t, size, bold]) => {
    const n = String(t).split('\n').length;
    const h = n * size * 1.35 / 72 + 0.12;
    s.addText(t, { x: L.x, y, w: L.w, h, fontFace: T.font.gothic, fontSize: fit(t, L.w, h, { base: size, min: size * 0.75, lineHeight: 1.3, quiet: true }), bold, color: T.color.text, valign: 'top', margin: 0, lineSpacingMultiple: 1.15 });
    y += h + (bold ? 0.35 : 0.3);
  });
  const abs = SK.skinImage(c.image);
  const b = c.image_box || { x: 8.1, y: 3.08, w: 9.66, h: 5.08 };
  if (abs) s.addImage({ path: abs, ...fitBox(abs, b.x, b.y, b.w, b.h) });
  return s;
}

// 表紙（スキン：全面の背景画像）。ベクトルのFMT：青の全面に白い題を中央、下の白い帯にロゴ（2026-10-06）
function slideCoverBackground(pptx, fv, c) {
  const p = fv.project;
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.dark };
  SK.drawBackground(s, c.background);
  const band = c.band;
  if (band) s.addShape('rect', { x: 0, y: band.y, w: T.slide.w, h: band.h, fill: { color: band.color || 'FFFFFF' }, line: { width: 0 } });
  const lg = c.logo;
  const labs = lg && SK.skinImage(lg.path);
  if (labs) s.addImage({ path: labs, x: lg.x, y: lg.y, w: lg.w, h: lg.h });
  const t = c.title || { x: 1.0, y: 2.6, w: 18.0, h: 3.6, base: 60, min: 40 };
  const col = t.color || 'FFFFFF';
  if (p.recipient) s.addText(p.recipient, { x: t.x, y: t.y - 1.0, w: t.w, h: 0.7, fontFace: T.font.gothic, fontSize: 26, bold: true, color: col, align: 'center', valign: 'middle', margin: 0 });
  const title = p.cover_title || '';
  s.addText(title, { x: t.x, y: t.y, w: t.w, h: t.h, fontFace: T.font.mincho,
    fontSize: fit(title, t.w, t.h, { base: t.base || 60, min: t.min || 40, lineHeight: 1.3, quiet: true }),
    bold: true, color: col, align: 'center', valign: 'middle', lineSpacingMultiple: 1.2, margin: 0 });
  const below = [p.cover_sub, [p.date_label, p.producer].filter(Boolean).join('　／　')].filter(Boolean);
  below.forEach((line, i) => s.addText(line, { x: t.x, y: t.y + t.h + 0.25 + i * 0.62, w: t.w, h: 0.55, fontFace: T.font.gothic,
    fontSize: fit(line, t.w, 0.55, { base: i ? 18 : 22, min: 16, quiet: true }), color: col, align: 'center', valign: 'middle', margin: 0 }));
  return s;
}

// 表紙（元のFMT）。2026-10-06 本人「表紙はもっとシンプルで良い。表題と画像と〇〇御中でOK」
// 宛名（〇〇御中）と罫・大きな題・検索上位の投稿2枚だけ。小見出し・社名の並び・調べた量・対象の表・社名は載せない
function slideCoverDeepdive(pptx, fv) {
  const p = fv.project;
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.bg };
  s.addText(p.recipient || '', { x: X0, y: 0.80, w: 11.0, h: 0.6, fontFace: T.font.gothic, fontSize: 24, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  s.addShape('line', { x: X0, y: 1.55, w: T.content.w, h: 0, line: { color: T.color.rule, width: 1.1 } });
  // 右：検索上位の投稿2枚（段をずらして大きく）
  const boxes = [{ x: 12.5, y: 2.35, w: 2.95, h: 5.24 }, { x: 15.9, y: 3.75, w: 2.95, h: 5.24 }];
  // 題：明示改行の各行が1行に収まる大きさで、写真の縦の中央にそろえる
  const title = String(p.cover_title || '');
  const tw = 10.6;
  const longest = Math.max(1, ...title.split('\n').map(widthUnits));
  const size = Math.max(36, Math.min(64, Math.floor(((tw - 0.16) * 72 * 0.92 / longest) * 2) / 2));
  s.addText(title, { x: X0, y: boxes[0].y, w: tw, h: boxes[1].y + boxes[1].h - boxes[0].y, fontFace: T.font.mincho, fontSize: size, bold: true,
    color: T.color.text, valign: 'middle', lineSpacingMultiple: 1.18, margin: 0 });
  const shots = (fv.cover_cards || []).slice(0, 2);
  shots.forEach((c, i) => coverShot(s, c, boxes[i]));
  return s;
}

// ───────────────────────────────── P1 表紙
function slideCover(pptx, fv) {
  if (SK.framed()) return slideCoverSkinned(pptx, fv);
  if (SK.opt('cover_style') === 'deepdive') return slideCoverDeepdive(pptx, fv);
  // 既定は「上に大きな題・下の帯に写真」。cover_style:"panel" で右に帯の別案
  return (fv.project.cover_style === 'panel' ? slideCoverPanel : slideCoverStrip)(pptx, fv);
}

// 表紙の写真は同じ大きさに切りそろえる（縦横比を保って収めると、縦長でない画像だけ小さく浮いていた。2026-10-02）
function coverShot(s, c, box) {
  const abs = cover(c.cover, '表紙', c.video_id);
  if (!abs) return false;
  // 枠を覆う大きさに拡げて中央で切る（pptxgenjs の sizing:cover は元画像の縦横比を w・h に渡す必要がある）
  // 写しを 9:16 に切ってある（build_research_json.py の covers_916）。切っていない画像は枠に収めて置く
  const sz = imageSize(abs);
  const r = sz && sz.w && sz.h ? sz.w / sz.h : 9 / 16;
  if (Math.abs(r - box.w / box.h) < 0.02) s.addImage({ path: abs, x: box.x, y: box.y, w: box.w, h: box.h, ...linkTo(c.url) });
  else s.addImage({ path: abs, ...fitBox(abs, box.x, box.y, box.w, box.h), ...linkTo(c.url) });
  note(c);
  return true;
}

function coverTitle(s, p, box, base) {
  const title = p.cover_title || '';
  // 明示改行の各行が1行に収まる大きさ（見積りは実描画より約8%甘いので 0.92 を掛ける）
  const longest = Math.max(1, ...String(title).split('\n').map(widthUnits));
  const oneLine = Math.floor(((box.w - 0.16) * 72 * 0.92 / longest) * 2) / 2;
  const size = Math.max(36, Math.min(fit(title, box.w, box.h, { base, min: 36, lineHeight: 1.25 }), oneLine));
  s.addText(title, { ...box, fontFace: T.font.mincho, fontSize: size, bold: true, color: T.color.text, valign: 'top', lineSpacingMultiple: 1.18, margin: 0 });
  return size;
}

/** 表紙（既定）：左に大きな題、右に濃い帯と写真3枚 */
function slideCoverPanel(pptx, fv) {
  const p = fv.project;
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.bg };
  const panelX = 12.4;
  s.addShape('rect', { x: panelX, y: 0, w: T.slide.w - panelX, h: T.slide.h, fill: { color: T.color.dark }, line: { color: T.color.dark, width: 0 } });
  // 左上：宛名。右上（帯の上）：CONFIDENTIAL
  s.addText(p.recipient || '', { x: X0, y: 0.9, w: 10.6, h: 0.56, fontFace: T.font.gothic, fontSize: 20, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  s.addText('CONFIDENTIAL', { x: panelX + 0.6, y: 0.9, w: T.slide.w - panelX - 1.2, h: 0.56, fontFace: T.font.en, fontSize: 14, color: T.color.darkSub, align: 'right', valign: 'middle', charSpacing: 3, margin: 0 });
  // 題の塊は縦の中央より少し上に
  s.addShape('rect', { x: X0, y: 3.05, w: 0.9, h: 0.09, fill: { color: T.brandColors[0] }, line: { width: 0 } });
  s.addText(p.cover_kicker || 'TIKTOK SEARCH — FIRST VISIT', { x: X0, y: 3.35, w: 10.6, h: 0.44, fontFace: T.font.en, fontSize: 16, bold: true, color: T.brandColors[0], charSpacing: 3.2, valign: 'middle', margin: 0 });
  coverTitle(s, p, { x: X0, y: 4.05, w: 10.6, h: 3.3 }, 60);
  if (p.cover_sub) s.addText(p.cover_sub, { x: X0, y: 7.6, w: 10.6, h: 0.5, fontFace: T.font.gothic, fontSize: 17, color: T.color.sub, valign: 'middle', margin: 0 });
  // 左下：日付・作成
  s.addShape('line', { x: X0, y: 9.55, w: 10.6, h: 0, line: { color: T.color.ruleThin, width: 0.8 } });
  s.addText([p.date_label, p.producer].filter(Boolean).join('　／　'), { x: X0, y: 9.7, w: 10.6, h: 0.5, fontFace: T.font.gothic, fontSize: 16, color: T.color.sub, valign: 'middle', margin: 0 });
  // 右：関連を確認した上位の投稿3枚。同じ大きさで横に並べ、縦の中央に
  const shots = (fv.cover_cards || []).slice(0, 3);
  const gap = 0.24;
  const pw = T.slide.w - panelX - 1.2;
  const bw = (pw - gap * 2) / 3;
  const bh = bw * 16 / 9;
  const by = (T.slide.h - bh) / 2 + 0.2;
  shots.forEach((c, i) => coverShot(s, c, { x: panelX + 0.6 + i * (bw + gap), y: by, w: bw, h: bh }));
  if (shots.length) s.addText('いま検索で上位に出ている投稿', { x: panelX + 0.6, y: by + bh + 0.25, w: pw, h: 0.4, fontFace: T.font.gothic, fontSize: 14, color: T.color.darkSub, valign: 'middle', margin: 0 });
  return s;
}

/** 表紙（別案 cover_style:"strip"）：上に題、下の帯に写真を横一列 */
function slideCoverStrip(pptx, fv) {
  const p = fv.project;
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.bg };
  s.addText(p.recipient || '', { x: X0, y: 0.8, w: 12, h: 0.56, fontFace: T.font.gothic, fontSize: 20, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  s.addText('CONFIDENTIAL', { x: T.slide.w - T.margin.r - 5, y: 0.8, w: 5, h: 0.56, fontFace: T.font.en, fontSize: 14, color: T.color.subLight, align: 'right', valign: 'middle', charSpacing: 3, margin: 0 });
  s.addText(p.cover_kicker || 'TIKTOK SEARCH — FIRST VISIT', { x: X0, y: 1.9, w: 14, h: 0.44, fontFace: T.font.en, fontSize: 16, bold: true, color: T.brandColors[0], charSpacing: 3.2, valign: 'middle', margin: 0 });
  coverTitle(s, p, { x: X0, y: 2.55, w: W, h: 2.9 }, 64);
  const bandY = 6.0;
  s.addShape('rect', { x: 0, y: bandY, w: T.slide.w, h: T.slide.h - bandY, fill: { color: T.color.dark }, line: { width: 0 } });
  const shots = (fv.cover_cards || []).slice(0, 3);
  const bh = T.slide.h - bandY - 1.25;
  const bw = bh * 9 / 16;
  shots.forEach((c, i) => coverShot(s, c, { x: T.slide.w - T.margin.r - (shots.length - i) * bw - (shots.length - 1 - i) * 0.24, y: bandY + 0.45, w: bw, h: bh }));
  // 帯の左：何をどれだけ調べたか（白）と日付
  const lw = T.slide.w - T.margin.r - shots.length * (bw + 0.24) - X0 - 0.6;
  s.addShape('rect', { x: X0, y: bandY + 0.75, w: 0.9, h: 0.08, fill: { color: T.brandColors[0] }, line: { width: 0 } });
  if (p.cover_sub) {
    const items = String(p.cover_sub).split('・');
    s.addText(items.map((t, i) => ({ text: t, options: { breakLine: i < items.length - 1 } })),
      { x: X0, y: bandY + 1.05, w: lw, h: bh - 1.6, fontFace: T.font.gothic, fontSize: 22, bold: true, color: T.color.darkText, valign: 'top', lineSpacingMultiple: 1.35, margin: 0 });
  }
  s.addText([p.date_label, p.producer].filter(Boolean).join('　／　'), { x: X0, y: bandY + 0.45 + bh - 0.5, w: lw, h: 0.5, fontFace: T.font.gothic, fontSize: 16, color: T.color.darkSub, valign: 'bottom', margin: 0 });
  return s;
}

// ───────────────────────────────── P2 いま検索するとこう見える
function slideNow(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, 'いま、検索するとこう見える'), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const cards = (pg.cards || []).slice(0, 8);
  const n = Math.max(cards.length, 1);
  const gap = 0.22;
  const tw = Math.min(2.02, (W - (n - 1) * gap) / n);
  const th = tw * 16 / 9;
  // 検索窓＋格子を本文領域の縦中央より少し上に置く（格子は横幅で大きさが決まり、下に余白が残るため）
  const block = 0.95 + th + 0.34;
  const y0 = S.top + Math.max(0.05, (S.bottom - S.top - block) * 0.4);
  // 検索窓（絵文字は明朝・ゴシックに字形が無く豆腐になるため、虫眼鏡は図形で描く）
  s.addShape('roundRect', {
    x: X0, y: y0, w: 7.6, h: 0.62, rectRadius: 0.31,
    fill: { color: 'FFFFFF' }, line: { color: T.color.cardLine, width: 1 },
  });
  s.addShape('ellipse', { x: X0 + 0.30, y: y0 + 0.15, w: 0.26, h: 0.26, fill: { type: 'none' }, line: { color: T.color.sub, width: 1.6 } });
  s.addShape('line', { x: X0 + 0.52, y: y0 + 0.38, w: 0.12, h: 0.12, line: { color: T.color.sub, width: 1.6 } });
  s.addText(pg.query || '', {
    x: X0 + 0.80, y: y0, w: 6.6, h: 0.62,
    fontFace: T.font.gothic, fontSize: 19, bold: true, color: T.color.text, valign: 'middle',
  });
  s.addText(pg.caption || '', {
    x: X0 + 7.9, y: y0, w: W - 7.9, h: 0.62,
    fontFace: T.font.gothic, fontSize: Math.max(12, minf()), color: T.color.subLight, valign: 'middle',
  });
  const ty = y0 + 0.95;
  cards.forEach((c, i) => {
    thumbCard(s, c, { x: X0 + i * (tw + gap), y: ty, w: tw, h: th }, { rank: true, where: 'P2' });
  });
  // 投稿者の内訳（クリエイター／個人＝フォロワー1万人で分けた数）は本編に出さない。
  // 上長FB「フォロワーの話はいらない、あっても最後」→ 付録2の表にだけ置く
  finishPage(s, ctx.page, { have: cards.length, want: 8, why: '関連・検索画面のカバーがある投稿が足りない' });
  return s;
}

// ───────────────────────────────── P3 競合はこう発信している
/** 市場が求める動画（一般の検索語の保存数上位）と、各社の指名検索の動画の比較（2026-10-05 本人案。P3 を置き換える） */
function slideMarketGap(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, '市場が求める動画と、指名検索の動画'), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const m = pg.market;
  const top = S.top + 0.15;
  const lw = 6.0;
  // 左：市場が保存している型
  s.addShape('rect', { x: X0, y: top, w: lw, h: S.bottom - top - 0.1, fill: { color: T.color.cardBg }, line: { color: T.color.cardLine, width: 0.75 } });
  s.addText(`「${m.keyword}」で保存数の多い${m.top_n}本`, { x: X0 + 0.3, y: top + 0.25, w: lw - 0.6, h: 0.45, fontFace: T.font.gothic, fontSize: 16, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  s.addText('＝市場が求めている動画', { x: X0 + 0.3, y: top + 0.72, w: lw - 0.6, h: 0.36, fontFace: T.font.gothic, fontSize: Math.max(14, minf()), color: T.color.sub, valign: 'middle', margin: 0 });
  (m.types || []).forEach((t, i) => {
    const y = top + 1.35 + i * 1.15;
    s.addText(t.label, { x: X0 + 0.3, y, w: lw - 2.0, h: 0.7, fontFace: T.font.mincho, fontSize: 26, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
    s.addText(`${t.count}本`, { x: X0 + lw - 1.7, y, w: 1.4, h: 0.7, fontFace: T.font.en, fontSize: 24, bold: true, color: BC(), align: 'right', valign: 'middle', margin: 0 });
  });
  s.addText([{ text: 'この型で ', options: { fontSize: 16, color: T.color.sub } }, { text: `${Math.round(m.coverage * 100)}%`, options: { fontSize: 34, bold: true, color: BC() } }],
    { x: X0 + 0.3, y: S.bottom - 1.25, w: lw - 0.6, h: 0.8, fontFace: T.font.gothic, valign: 'middle', margin: 0 });
  // 右：各社の指名検索で、その型に入る割合。縦の点線＝市場の割合
  const rx = X0 + lw + 0.7;
  const rw = W - lw - 0.7;
  s.addText('指名検索（上位50本）でその社が語られている投稿のうち、この型に入る割合（点線＝市場）', { x: rx, y: top + 0.1, w: rw, h: 0.4, fontFace: T.font.gothic, fontSize: Math.max(14, minf()), color: T.color.sub, valign: 'middle', margin: 0 });
  const bs = m.brands || [];
  const nameW = 2.6;
  const valW = 2.9;
  const barX = rx + nameW;
  const barW = rw - nameW - valW - 0.2;
  const rowH = Math.min(1.25, (S.bottom - top - 0.8) / Math.max(bs.length, 1));
  bs.forEach((b, i) => {
    const y = top + 0.7 + i * rowH;
    const col = b.own ? BC() : brandColor(b.color_index);
    s.addShape('rect', { x: rx, y: y + rowH * 0.3, w: 0.16, h: rowH * 0.4, fill: { color: col }, line: { width: 0 } });
    s.addText(b.short + (b.own ? '（貴社）' : ''), { x: rx + 0.28, y, w: nameW - 0.3, h: rowH, fontFace: T.font.gothic, fontSize: 17, bold: true, color: T.color.text, valign: 'middle', margin: 0 });
    const bh = Math.min(0.42, rowH * 0.42);
    const by = y + (rowH - bh) / 2;
    s.addShape('rect', { x: barX, y: by, w: barW, h: bh, fill: { color: T.color.track }, line: { width: 0 } });
    if (!b.few) s.addShape('rect', { x: barX, y: by, w: Math.max(0.05, barW * b.share), h: bh, fill: { color: b.fit ? col : T.color.placeholder }, line: { width: 0 } });
    s.addShape('line', { x: barX + barW * m.coverage, y: by - 0.12, w: 0, h: bh + 0.24, line: { color: T.color.text, width: 1.25, dashType: 'dash' } });
    s.addText(b.few ? `語られている投稿${b.n}本と少ない` : `${b.n}本中${b.k}本（${Math.round(b.share * 100)}%）`, { x: barX + barW + 0.2, y, w: valW, h: rowH, fontFace: T.font.gothic,
      fontSize: b.few ? Math.max(14, minf()) : 18, bold: !b.few, color: b.few ? T.color.subLight : (b.fit ? T.color.text : T.color.sub), align: 'right', valign: 'middle', margin: 0 });
    if (s.talk) s.talk(`${b.short}：指名検索の上位50本でその社が語られている${b.n}本（主役${b.n_main ?? '-'}・ほかの商品と一緒に語られている${b.n_mention ?? '-'}）のうち、市場の型に入る${b.k}本（${b.note}）`);
  });
  if (s.talk) s.talk(`市場＝「${m.keyword}」の関連投稿を保存数の多い順に${m.top_n}本。見せ方の上位：${(m.types || []).map((t) => `${t.label}${t.count}本`).join('・')}（この型で${Math.round(m.coverage * 100)}%）。差が15ポイント以内なら「合っている」`);
  finishPage(s, ctx.page, { have: bs.length, want: 2, why: '比べられる社が1社' });
  return s;
}

function slideCompetitors(pptx, pg, ctx) {
  if (pg.market) return slideMarketGap(pptx, pg, ctx);
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, '競合はこう発信している'), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const cols = pg.columns || [];
  const n = Math.max(cols.length, 1);
  const gap = 0.45;
  const cw = (W - (n - 1) * gap) / n;
  cols.forEach((c, i) => {
    const x = X0 + i * (cw + gap);
    const color = brandColor(c.color_index);
    s.addShape('rect', { x, y: S.top + 0.05, w: 0.20, h: 0.42, fill: { color }, line: { width: 0 } });
    s.addText(c.brand, {
      x: x + 0.32, y: S.top, w: cw - 0.32, h: 0.52,
      fontFace: T.font.gothic, fontSize: fit(c.brand, cw - 0.32, 0.52, { base: 20, min: 13, lineHeight: 1.0, quiet: true }),
      bold: true, color: T.color.text, valign: 'middle',
    });
    const thumbs = (c.cards || []).slice(0, 2);
    const tgap = 0.18;
    const tw = Math.min(2.55, (cw - tgap) / 2);
    const th = tw * 16 / 9;
    const ty = S.top + 0.72;
    thumbs.forEach((t, j) => thumbCard(s, t, { x: x + j * (tw + tgap), y: ty, w: tw, h: th }, { where: `P3 ${c.brand}` }));
    let cy = ty + th + 0.48;
    if (c.main) {
      // 下半分は見出しの軸だけを、全社同じ3行で：結論の語 → 割合の横棒 → 分数の文（2026-10-05 本人FB「下の表が分かりにくい」）
      const m = c.main;
      const word = m.state === 'A' ? `「${m.short}」` : (m.state === 'C' ? '傾向は言えない' : '1つに絞れない');
      s.addText(word, {
        x, y: cy, w: cw, h: 0.62, margin: 0, valign: 'middle',
        fontFace: m.state === 'A' ? T.font.mincho : T.font.gothic, fontSize: m.state === 'A' ? 28 : 18, bold: m.state === 'A',
        color: m.state === 'A' ? (m.emph ? color : T.color.text) : T.color.subLight,
      });
      if (m.state !== 'C') {
        s.addShape('rect', { x, y: cy + 0.72, w: cw, h: 0.16, fill: { color: T.color.track }, line: { width: 0 } });
        s.addShape('rect', { x, y: cy + 0.72, w: Math.max(0.05, cw * Math.min(1, m.share || 0)), h: 0.16,
          fill: { color: m.state === 'A' && m.emph ? color : T.color.placeholder }, line: { width: 0 } });
      }
      const text = m.state === 'A' ? `関連${m.n}本中${m.count}本が「${m.short}」`
        : m.state === 'B1' ? `「${m.short}」${m.count}本と「${m.second.short}」${m.second.count}本で割れる`
          : m.state === 'B3' ? `最多が${m.count}本ずつで並ぶ（関連${m.n}本）`
            : m.state === 'B2' ? `最多の「${m.short}」でも関連${m.n}本中${m.count}本`
              : `関連${m.n}本と少ない`;
      s.addText(text, {
        x, y: cy + 0.98, w: cw, h: 0.62, margin: 0, valign: 'top',
        fontFace: T.font.gothic, fontSize: Math.max(14, minf()), color: T.color.sub, lineSpacingMultiple: 1.15,
      });
      cy += 1.70;
      if (c.note_line && s.talk) s.talk(c.note_line);
    } else {
    // 本数の文字（「20本中10本」）を列の内側に残す。4社だと列幅が約4.1inで、チップが列いっぱいになり
    // 本数が隣の列に重なった（旧い first_visit.json＝main が無いときだけ）
    const chipW = Math.min(4.6, cw - 1.25);
    if (c.angle) {
      chip(s, { x, y: cy, w: chipW, label: '切り口', text: c.angle.short || c.angle.label, color });
      s.addText(`${c.n}本中${c.angle.count}本`, {
        x: x + chipW + 0.10, y: cy, w: cw - chipW - 0.10, h: 0.40,
        fontFace: T.font.gothic, fontSize: Math.max(12, minf()), color: T.color.sub, valign: 'middle',
      });
      cy += 0.52;
    }
    if (c.appeal) {
      chip(s, { x, y: cy, w: chipW, label: '訴求', text: c.appeal.short || c.appeal.label, color: T.color.chipDark });
      s.addText(`${c.n}本中${c.appeal.count}本`, {
        x: x + chipW + 0.10, y: cy, w: cw - chipW - 0.10, h: 0.40,
        fontFace: T.font.gothic, fontSize: Math.max(12, minf()), color: T.color.sub, valign: 'middle',
      });
      cy += 0.52;
    }
    const line = c.note || (c.scattered ? '切り口はばらけている' : null);
    if (line) {
      s.addText(line, {
        x, y: cy, w: cw, h: 0.40,
        fontFace: T.font.gothic, fontSize: Math.max(13, minf()), color: T.color.sub, valign: 'middle',
      });
      cy += 0.46;
    }
    }
    if (c.paid_line) {
      // 列が狭い（3〜4社）ときは2行まで。2社の列は広く1行で収まるが、下端（フッターの上）を越えない
      const ph = Math.max(0.36, Math.min(0.62, S.bottom + 0.06 - (cy + 0.04)));
      s.addText(c.paid_line, {
        x, y: cy + 0.04, w: cw, h: ph,
        fontFace: T.font.gothic, fontSize: fit(c.paid_line, cw, ph, { base: Math.max(13, minf()), min: Math.max(10, minf()), lineHeight: 1.15, quiet: true }),
        bold: true, color: 'A24765', valign: 'middle',
      });
    }
  });
  finishPage(s, ctx.page, { have: cols.length, want: 2, why: '比べられる競合が1社' });
  return s;
}

// ───────────────────────────────── P4 競合がお金をかけて広げている訴求
function slidePaid(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, '競合がお金をかけて広げている訴求'), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const cards = (pg.cards || []).slice(0, 4);
  const n = Math.max(cards.length, 1);
  const gap = 0.5;
  const cw = Math.min(4.0, (W - (n - 1) * gap) / n);
  const startX = X0 + (W - (n * cw + (n - 1) * gap)) / 2;
  const th = Math.min(5.0, cw * 16 / 9 * 0.82);
  const tw = th * 9 / 16;
  cards.forEach((c, i) => {
    const x = startX + i * (cw + gap);
    const color = brandColor(c.color_index);
    const b = thumbCard(s, c, { x: x + (cw - tw) / 2, y: S.top + 0.10, w: tw, h: th }, { where: `P4 ${c.brand}`, views: false });
    let y = b.y + b.h + 0.18;
    s.addShape('rect', { x, y: y + 0.08, w: 0.16, h: 0.26, fill: { color }, line: { width: 0 } });
    const who = `${c.short || c.brand}　${c.badge || ''}`;
    s.addText(who, {
      x: x + 0.26, y, w: cw - 0.26, h: 0.42,
      fontFace: T.font.gothic, fontSize: fit(who, cw - 0.26, 0.42, { base: Math.max(13, minf()), min: Math.max(10, minf()), lineHeight: 1.0, quiet: true }),
      bold: true, color: T.color.text, valign: 'middle',
    });
    y += 0.46;
    s.addText(c.appeal_label || '', {
      x, y, w: cw, h: 0.62,
      fontFace: T.font.mincho, fontSize: fit(c.appeal_label || '', cw, 0.62, { base: 24, min: 15, lineHeight: 1.1, quiet: true }),
      bold: true, color: T.color.text, valign: 'middle',
    });
    s.addText(`▶ ${c.views_label || '—'}`, {
      x, y: y + 0.64, w: cw, h: 0.32, fontFace: T.font.gothic, fontSize: Math.max(12, minf()), color: T.color.sub, valign: 'middle',
    });
  });
  finishPage(s, ctx.page, { have: cards.length, want: 3, why: 'PR・公式の関連投稿でカバーのあるもの' });
  return s;
}

// ───────────────────────────────── P5 貴社に足りていない発信
function slideGap(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, `${ctx.client}に足りていない発信`), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const rows = (pg.rows || []).slice(0, 3);
  const n = Math.max(rows.length, 1);
  const gap = 0.55;
  const cw = (W - (n - 1) * gap) / n;
  rows.forEach((r, i) => {
    const x = X0 + i * (cw + gap);
    s.addText(r.label, {
      x, y: S.top, w: cw, h: 0.62,
      fontFace: T.font.mincho, fontSize: fit(r.label, cw, 0.62, { base: 26, min: 16, lineHeight: 1.1, quiet: true }),
      bold: true, color: T.color.text, valign: 'middle',
    });
    const tgap = 0.30;
    const tw = Math.min(2.45, (cw - tgap) / 2);
    const th = tw * 16 / 9;
    const ty = S.top + 1.12;
    // 左＝競合（または市場）の実例、右＝貴社の枠
    const lc = r.left || {};
    s.addText(lc.caption || '', {
      x, y: ty - 0.42, w: tw, h: 0.36, fontFace: T.font.gothic, fontSize: Math.max(12, minf()), bold: true,
      color: brandColor(lc.color_index), valign: 'middle',
    });
    thumbCard(s, lc, { x, y: ty, w: tw, h: th }, { where: `P5 ${r.label}` });
    const rx = x + tw + tgap;
    s.addText(pg.right_label || ctx.client, {
      x: rx, y: ty - 0.42, w: tw, h: 0.36, fontFace: T.font.gothic, fontSize: Math.max(12, minf()), bold: true,
      color: T.color.text, valign: 'middle',
    });
    if (r.right && r.right.cover) {
      thumbCard(s, r.right, { x: rx, y: ty, w: tw, h: th }, { where: `P5 ${ctx.client}` });
    } else {
      addEmptySlot(s, { x: rx, y: ty, w: tw, h: th }, r.right_text || 'まだ無し');
    }
    if (r.evidence) {
      s.addText(r.evidence, {
        x, y: ty + th + 0.42, w: cw, h: 0.40,
        fontFace: T.font.gothic, fontSize: fit(r.evidence, cw, 0.40, { base: Math.max(13, minf()), min: Math.max(10, minf()), lineHeight: 1.1, quiet: true }),
        color: T.color.sub, valign: 'middle',
      });
    }
  });
  if (!rows.length) {
    // 型の空白は言えないが、公式アカウントの不在は言える場合（数字だけを大きく）
    s.addText('0本', {
      x: X0, y: S.top + 1.2, w: W, h: 2.6, fontFace: T.font.en, fontSize: 150, bold: true,
      color: T.brandColors[0], align: 'center', valign: 'middle',
    });
    // 分母は実際に数えた本数（取得が30本未満なら30と書かない）
    const within = pg.official_n ? `上位${pg.official_n}本` : '上位';
    s.addText(`「${pg.query || ''}」${within}のうち、${ctx.client}公式アカウントの投稿`, {
      x: X0, y: S.top + 4.0, w: W, h: 0.6, fontFace: T.font.gothic, fontSize: 18, color: T.color.sub, align: 'center', valign: 'middle',
    });
  }
  finishPage(s, ctx.page, pg.mode === 'official' ? null : { have: rows.length, want: 3, why: '言える空白の型が少ない' });
  return s;
}

// ───────────────────────────────── P6 いま伸びている型（お土産）
function slideWinning(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, pg.winners ? 'いま伸びている型' : 'いま多い型'), headline: pg.headline, sub: pg.sub, footer: ctx.footer, tag: pg.tag || '' });
  const cards = (pg.cards || []).slice(0, 3);
  const n = Math.max(cards.length, 1);
  const gap = 0.5;
  const cw = (W - (n - 1) * gap) / n;
  cards.forEach((c, i) => {
    const x = X0 + i * (cw + gap);
    // 型が1〜2つのときは画像を大きくする（3列用の寸法のままだと紙面の半分以上が空く）
    const tw = n === 1 ? 3.6 : Math.min(2.75, cw * 0.47);
    const th = tw * 16 / 9;
    thumbCard(s, c.example || {}, { x, y: S.top + 0.12, w: tw, h: th }, { where: `P6 ${c.label}` });
    const tx = x + tw + 0.30;
    const txw = cw - tw - 0.30;
    s.addText(String(i + 1).padStart(2, '0'), {
      x: tx, y: S.top + 0.05, w: txw, h: 0.50, fontFace: T.font.en, fontSize: 22, bold: true, color: T.brandColors[0], valign: 'middle',
    });
    s.addText(c.label, {
      x: tx, y: S.top + 0.60, w: txw, h: 1.10,
      fontFace: T.font.mincho, fontSize: fit(c.label, txw, 1.10, { base: 26, min: 16, lineHeight: 1.15, quiet: true }),
      bold: true, color: T.color.text, valign: 'top',
    });
    s.addText(c.phrase || '', {
      x: tx, y: S.top + 1.75, w: txw, h: 1.10,
      fontFace: T.font.gothic, fontSize: fit(c.phrase || '', txw, 1.10, { base: 16, min: Math.max(11, minf()), lineHeight: 1.4, quiet: true }),
      color: T.color.text, valign: 'top', lineSpacingMultiple: 1.3,
    });
    if (c.lift_label) {
      s.addText(c.lift_label, {
        x: tx, y: S.top + 3.05, w: txw, h: 0.95,
        fontFace: T.font.gothic, fontSize: 40, bold: true, color: T.brandColors[0], valign: 'middle',
      });
    }
    s.addText(c.evidence || '', {
      x: tx, y: S.top + 4.02, w: txw, h: 0.80,
      fontFace: T.font.gothic, fontSize: fit(c.evidence || '', txw, 0.80, { base: Math.max(13, minf()), min: Math.max(10, minf()), lineHeight: 1.3, quiet: true }),
      color: T.color.sub, valign: 'top',
    });
  });
  finishPage(s, ctx.page, { have: cards.length, want: 3, why: pg.winners ? '伸びている型が少ない' : 'まだ勝ち型が無い' });
  return s;
}

// ───────────────────────────────── P7 まずこの3本
function slidePlans(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, `まずこの${(pg.items || []).length}本`), headline: pg.headline, sub: pg.sub, footer: ctx.footer, tag: '提案（仮説）' });
  const items = (pg.items || []).slice(0, 3);
  const n = Math.max(items.length, 1);
  const gap = 0.5;
  const cw = (W - (n - 1) * gap) / n;
  items.forEach((it, i) => {
    const x = X0 + i * (cw + gap);
    s.addShape('rect', { x, y: S.top + 0.05, w: cw, h: 6.95, fill: { color: T.color.cardBg }, line: { color: T.color.cardLine, width: 1 } });
    s.addText(String(i + 1).padStart(2, '0'), {
      x: x + 0.30, y: S.top + 0.25, w: 1.5, h: 0.70, fontFace: T.font.en, fontSize: 34, bold: true, color: T.brandColors[0], valign: 'middle',
    });
    // 「…で見せ／る」のように1〜2字だけ次の行へ落ちると読めない。最終行が短くならない大きさを選ぶ
    s.addText(it.title, {
      x: x + 0.30, y: S.top + 1.05, w: cw - 0.60, h: 1.25,
      fontFace: T.font.mincho, fontSize: fitBalanced(it.title, cw - 0.60, 1.25, { base: 24, min: 15, lineHeight: 1.2, minTail: 5 }),
      bold: true, color: T.color.text, valign: 'top',
    });
    let cy = S.top + 2.45;
    if (it.angle_short) { chip(s, { x: x + 0.30, y: cy, w: Math.min(3.6, cw - 0.6), label: '切り口', text: it.angle_short, color: T.brandColors[0] }); cy += 0.50; }
    if (it.appeal_short) { chip(s, { x: x + 0.30, y: cy, w: Math.min(3.6, cw - 0.6), label: '訴求', text: it.appeal_short }); cy += 0.50; }
    const ref = it.reference;
    if (ref) {
      const th = Math.min(3.35, S.top + 6.8 - (cy + 0.45));
      const tw = th * 9 / 16;
      s.addText('参考', { x: x + 0.30, y: cy + 0.05, w: 1.0, h: 0.32, fontFace: T.font.gothic, fontSize: Math.max(11, minf()), color: T.color.sub, valign: 'middle' });
      thumbCard(s, ref, { x: x + 0.30, y: cy + 0.40, w: tw, h: th }, { where: `P7 ${it.title}` });
      if (it.reason) {
        s.addText(it.reason, {
          x: x + 0.30 + tw + 0.25, y: cy + 0.40, w: cw - 0.85 - tw, h: th,
          fontFace: T.font.gothic, fontSize: fit(it.reason, cw - 0.85 - tw, th, { base: Math.max(13, minf()), min: Math.max(10, minf()), lineHeight: 1.4, quiet: true }),
          color: T.color.sub, valign: 'bottom',
        });
      }
    }
  });
  finishPage(s, ctx.page, { have: items.length, want: 3, why: '型の候補が少ない' });
  return s;
}

// ───────────────────────────────── P8 次回
function slideNext(pptx, pg, ctx) {
  const s = addStorySlide(pptx, { kicker: kicker(ctx, pg, '次回'), headline: pg.headline, sub: pg.sub, footer: ctx.footer });
  const colW = (W - 1.0) / 2;
  const blocks = [['次回お持ちするもの', pg.bring || [], T.brandColors[0]], ['教えていただきたいこと', pg.ask || [], T.color.text]];
  blocks.forEach(([title, list, color], bi) => {
    const x = X0 + bi * (colW + 1.0);
    s.addText(title, { x, y: S.top + 0.10, w: colW, h: 0.46, fontFace: T.font.gothic, fontSize: 15, bold: true, color, valign: 'middle' });
    s.addShape('line', { x, y: S.top + 0.62, w: colW, h: 0, line: { color: T.color.ruleThin, width: 1 } });
    list.slice(0, 3).forEach((t, i) => {
      const y = S.top + 0.85 + i * 1.25;
      s.addText(String(i + 1).padStart(2, '0'), { x, y, w: 0.9, h: 0.9, fontFace: T.font.en, fontSize: 26, bold: true, color, valign: 'middle' });
      s.addText(t, {
        x: x + 1.0, y, w: colW - 1.0, h: 0.9,
        fontFace: T.font.gothic, fontSize: fit(t, colW - 1.0, 0.9, { base: 21, min: 14, lineHeight: 1.25, quiet: true }),
        bold: bi === 0, color: T.color.text, valign: 'middle',
      });
    });
  });
  if (pg.service) {
    const y = T.content.bottom - 1.15;
    s.addShape('rect', { x: X0, y, w: W, h: 0.95, fill: { color: T.color.dark }, line: { width: 0 } });
    s.addText(pg.service, {
      x: X0 + 0.5, y, w: W - 1.0, h: 0.95,
      fontFace: T.font.mincho, fontSize: fit(pg.service, W - 1.0, 0.95, { base: 22, min: 14, lineHeight: 1.2, quiet: true }),
      bold: true, color: 'FFFFFF', valign: 'middle',
    });
  }
  finishPage(s, ctx.page, null);
  return s;
}

// ───────────────────────────────── 付録（最大2枚）
function slideAppendixPremise(pptx, ap, ctx) {
  const s = addStorySlide(pptx, { kicker: '付録1', headline: '調査の前提', sub: '', footer: ctx.footer, accent: T.color.sub });
  const rows = (ap.premise || []);
  const labelW = 3.0;
  const bodyW = W - labelW - 0.3;
  const room = T.content.bottom - (S.top + 0.1);
  const per = Math.min(0.95, room / Math.max(rows.length, 1));
  rows.forEach(([k, v], i) => {
    const y = S.top + 0.1 + i * per;
    s.addShape('line', { x: X0, y, w: W, h: 0, line: { color: T.color.ruleThin, width: 0.8 } });
    s.addText(k, { x: X0, y: y + 0.06, w: labelW, h: per - 0.1, fontFace: T.font.gothic, fontSize: 13, bold: true, color: T.color.text, valign: 'top' });
    s.addText(v, {
      x: X0 + labelW + 0.3, y: y + 0.06, w: bodyW, h: per - 0.1,
      fontFace: T.font.gothic, fontSize: fit(v, bodyW, per - 0.1, { base: 13, min: 9.5, lineHeight: 1.35 }),
      color: T.color.sub, valign: 'top', lineSpacingMultiple: 1.25,
    });
  });
  return s;
}

function slideAppendixNumbers(pptx, ap, ctx) {
  const s = addStorySlide(pptx, { kicker: '付録2', headline: '数字の一覧', sub: '', footer: ctx.footer, accent: T.color.sub });
  const t = ap.table || { head: [], rows: [] };
  const colW = t.col_w || t.head.map(() => W / Math.max(t.head.length, 1));
  const y = S.top + 0.1;
  const r = addDataTable(s, { x: X0, y, w: W, head: t.head, rows: t.rows, colW, fontSize: 13, maxH: 3.2 });
  const m = ap.matrix;
  if (m && m.rows && m.rows.length) {
    const my = y + ((r && r.height) || 2.6) + 0.45;
    s.addText(m.title || '', { x: X0, y: my, w: W, h: 0.36, fontFace: T.font.gothic, fontSize: 13, bold: true, color: T.color.text, valign: 'middle' });
    addDataTable(s, {
      x: X0, y: my + 0.42, w: W, head: m.head, rows: m.rows,
      colW: m.col_w || m.head.map(() => W / m.head.length), fontSize: 12,
      maxH: T.content.bottom - (my + 0.42) - 0.05,
    });
  }
  return s;
}

const RENDER = {
  now: slideNow, competitors: slideCompetitors, paid: slidePaid, gap: slideGap,
  winning: slideWinning, plans: slidePlans, next: slideNext,
};

/** 初訪の全ページを組む。返り値は枚数 */
function buildFirstVisit(pptx, fv) {
  const order = (fv.order || []).filter((k) => fv.pages[k] && RENDER[k]);
  const hasAppendix = fv.appendix && (fv.appendix.premise || fv.appendix.table);
  const total = 1 + order.length + (hasAppendix ? 2 : 0);
  resetStory(total);
  const ctx = { footer: fv.project.footer || '', client: fv.project.client_short || fv.project.client, page: 1 };
  const cs = slideCover(pptx, fv);
  if (FV.notes.length) { if (process.env.TIKTOK_DECK_CLIENT !== '1') cs.addNotes(`表紙の投稿\n${FV.notes.join('\n')}`); FV.notes = []; }
  // 表紙はページ番号を出さないが、数には入れる（本編の番号＝物理位置にそろえる）
  addStoryFooterSkip();
  order.forEach((k) => {
    ctx.page += 1;
    const pg = { ...fv.pages[k], query: fv.project.query };
    RENDER[k](pptx, pg, ctx);
  });
  if (hasAppendix) {
    slideAppendixPremise(pptx, fv.appendix, ctx);
    slideAppendixNumbers(pptx, fv.appendix, ctx);
  }
  return total;
}

// 表紙の分だけ番号を進める（表紙にはフッターを描かない）
function addStoryFooterSkip() {
  const dummy = { addText: () => {} };
  addStoryFooter(dummy, null);
}

module.exports = { buildFirstVisit, fvStats,
  // 調査と提案の統合資料（research.js）から初訪のページ部品を使うために公開する
  slideCover, slideNow, slideCompetitors, slideWinning, slidePlans, slideNext,
  slideAppendixPremise, slideAppendixNumbers, thumbCard, chip, addStoryFooterSkip, finishPage };
