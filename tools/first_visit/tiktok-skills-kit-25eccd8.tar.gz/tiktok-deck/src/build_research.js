// build_research.js — 初訪＋口コミ調査＋SNS分析＋個別投稿の構成分析を1本の PPTX にする
// 使い方: node src/build_research.js --case <案件> [--out output/xxx.pptx]
// 入力: <案件>/first_visit.json（初訪のページ）と <案件>/research.json（tools/build_research_json.py が作る）
const fs = require('fs');
const path = require('path');

const argv = process.argv.slice(2);
const arg = (k, d) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d; };
const caseDir = path.resolve(arg('--case', '.'));
// --client：先方に渡す版（スピーカーノートに社内のファイル名を残さない）
if (argv.includes('--client')) process.env.TIKTOK_DECK_CLIENT = '1';
process.env.CASE_ROOT = caseDir;
process.env.TIKTOK_DECK_MIN_FONT = process.env.TIKTOK_DECK_MIN_FONT || '14';   // 話す資料の字の下限（初訪の部品も 14pt 以上に）
process.env.TIKTOK_CASE_ROOT = caseDir;

const pptxgen = require('pptxgenjs');
require('./components/safeAltText');   // 画像の代替テキストに手元の絶対パスを書かない
const T = require('./theme');
const { buildResearch, researchStats } = require('./slides/research');
const { fvStats } = require('./slides/firstVisit');

const fv = JSON.parse(fs.readFileSync(path.join(caseDir, 'first_visit.json'), 'utf8'));
const rs = JSON.parse(fs.readFileSync(path.join(caseDir, arg('--data', 'research.json')), 'utf8'));
const out = path.resolve(caseDir, arg('--out', path.join('output', rs.project.file || 'research.pptx')));

const pptx = new pptxgen();
pptx.defineLayout({ name: 'W20', width: T.slide.w, height: T.slide.h });
pptx.layout = 'W20';
const n = buildResearch(pptx, fv, rs);
// Standard OOXML core metadata travels with a renamed/copied PPTX. Include the
// renderer audit so preflight does not depend on an adjacent generation log.
const strings = (value) => {
  if (typeof value === 'string') return value.trim() ? [value.trim()] : [];
  if (Array.isArray(value)) return value.flatMap(strings);
  if (value && typeof value === 'object') return strings(value.text);
  return [];
};
const manifest = [{ page: 1, type: 'cover', id: 'cover', required_texts: [] }];
let pageNo = 1;
for (const p of rs.pages) {
  const required = [];
  if (p.type === 'insights') {
    for (const it of p.items || []) required.push(...strings([it.title, it.implication, it.evidence]));
  } else if (p.type === 'proposals') {
    for (const it of p.items || []) required.push(...strings([
      it.title, it.body, typeof it.evidence === 'string' ? it.evidence.replace(/^根拠[：:]\s*/, '') : it.evidence,
      it.point, it.chips,
    ]));
  } else if (p.type === 'script') {
    required.push(...strings([p.basis, p.specs]));
    for (const row of p.rows || []) required.push(...strings(row.slice(0, 4)));
  } else if (p.type === 'top5') {
    required.push(...strings(p.factors));
  } else if (p.type === 'table' && (p.id || p._id) === 'rv_zero') {
    required.push(...strings([p.headline, p.sub, p.rows]));
  }
  const entry = {
    page: ++pageNo, type: p.type, id: p._id || p.id || (p.type === 'fv' ? `fv_${p.page}` : p.type),
    title: p.kicker || p.title || p.headline || '', required_texts: [...new Set(required)],
  };
  if (p.type === 'table' || p.type === 'script') entry.row_count = (p.rows || []).length;
  if (p.type === 'insights' || p.type === 'proposals') entry.item_count = (p.items || []).length;
  manifest.push(entry);
  if (p.type === 'video') manifest.push({ page: ++pageNo, type: 'video_frames', id: p.video_id || 'video_frames', required_texts: [] });
}
const renderStats = researchStats();
const firstStats = fvStats();
pptx.subject = 'tiktok-deck-quality:v1:' + JSON.stringify({
  ...(rs.quality_contract || {}),
  slide_manifest: manifest,
  generation_audit: {
    schema_version: 1, slides: n,
    missing_images: [...renderStats.missing, ...firstStats.missing],
    qa: [...renderStats.qa, ...firstStats.qa],
  },
});
fs.mkdirSync(path.dirname(out), { recursive: true });
pptx.writeFile({ fileName: out }).then(() => {
  const a = researchStats();
  const b = fvStats();
  const log = [
    '# generation_log（調査と提案の統合資料）',
    `- 生成: ${n} スライド`,
    `- 画像（初訪部品）: ${b.images}／（追加ページ）: ${a.images}`,
    `- 見つからない画像: ${a.missing.length + b.missing.length}`,
    ...a.missing.map((m) => `  - ${m}`), ...b.missing.map((m) => `  - ${m}`),
    '## QA', ...a.qa.map((q) => `  - ${q}`), ...b.qa.map((q) => `  - ${q}`),
  ].join('\n');
  // 生成ログは作業用なので output/作業/ に置く（output/ にはパワポと PDF だけ。2026-10-06 本人「なぜ5つ以上できるの？」）
  const work = path.join(path.dirname(out), '作業');
  fs.mkdirSync(work, { recursive: true });
  fs.writeFileSync(path.join(work, `generation_log_${path.basename(out, '.pptx')}.md`), log + '\n');
  console.log(`スライド ${n}枚 → ${out}`);
  if (a.missing.length + b.missing.length) console.log(`！見つからない画像 ${a.missing.length + b.missing.length}件（generation_log_research.md）`);
});
