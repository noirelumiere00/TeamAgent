// skin.js — 案件ごとの「外側の見た目」を差し替える（2026-10-02 追加）
//
// 先方やパートナーの資料のFMTに、背景・見出しの帯・右上の印・ロゴ・色・書体だけを合わせたいときに使う。
// 中身（ページの並び・図表・文）は変えない。スキンを指定しない案件は今までどおりの見た目。
//
// 使い方：research.json の project.skin に、案件フォルダからの相対パスで skin.json を書く。
//   { "project": { "skin": "skin.json", ... } }
// skin.json の形（寸法は20×11.25インチの版面。10×5.625のFMTなら値を2倍にする）:
//   frame:      { color, inner, x, y, w, h }        外側の色の額縁と、内側の白地
//   title_bar:  { color, x, y, w, h }                見出しの左の縦帯
//   title:      { x, y, w, h, base, min, color }     見出し（1行で言い切る文）
//   kicker:     { x, y, h, size, color }             小見出し（「04　10本の数字」）
//   sub:        { x, y, h, size }                    補足
//   rule:       { y, color, width }                  見出しの下の線（無ければ引かない）
//   top:        本文の上端
//   badge:      { text, x, y, w, h, color, font, size }   右上の印（confidential 等）
//   logo:       { path, x, y, w, h }                 右下のロゴ（案件フォルダの assets/ の画像。省略可）
//   page_number:{ x, y, w }                          ページ番号の位置
//   colors:     theme.js の T.color の上書き
//   brand:      [強調色, 2番目の色]
//   fonts:      { heading, en }                      見出しの書体（明朝をやめるとき）・英字の書体
//   cover:      { image, left:{x,y,w}, image_box:{x,y,w,h} }   表紙
//               { background, band:{y,h,color}, logo:{path,x,y,w,h}, title:{x,y,w,h,base,min,color} }   全面の背景画像の表紙（ベクトルFMT）
//   images:     [{ path, x, y, w, h }]               どのページにも敷く画像（見出しの帯・上下の帯など。文より先に描く）
//   footer:     { x, y, w, color, size }             フッター左の文の位置（帯の上に白で置く等）
//   part:       { background, color, sub }           章扉を全面の背景画像にする（題は中央・白）
//   title/kicker/sub の align: 'center'、kicker.w・sub.w で幅
//   layout:     "default" なら版面の配置は既定（スキン無し）のまま、色・書体と下の見た目だけ差し替える
//   header:     "qlabel" 小見出しの番号を赤の太字の札にし、続きを灰色の問い・右上に章（PART n — 名前）（元のFMT）
//   head_base:  見出しの大きさ（既定 40）
//   footer_prefix: フッター左の頭に付ける文（字間を空けて出す）
//   cover_style:"deepdive" 元のFMTの表紙／ part_style: "numeral" 輪郭の大きな数字の章扉
//
// キットに同梱のスキン：project.skin に "@vector" のように @名前 で書くと tiktok-deck/skins/<名前>/skin.json を使う。
// そのときの画像のパスは skin.json のあるフォルダからの相対（案件フォルダには何も置かなくてよい）
const fs = require('fs');
const path = require('path');
const T = require('../theme');

let SKIN = null;
let ROOT = null;
let SKIN_DIR = null;   // キット同梱のスキン（@名前）のとき、そのフォルダ
const KIT_SKINS = path.join(__dirname, '..', '..', 'skins');

function applySkin(skin, caseRoot) {
  SKIN = skin || null;
  ROOT = caseRoot || null;
  if (!SKIN) return null;
  Object.assign(T.color, SKIN.colors || {});
  (SKIN.brand || []).forEach((c, i) => { T.brandColors[i] = c; });
  if (SKIN.fonts && SKIN.fonts.heading) T.font.mincho = SKIN.fonts.heading;
  if (SKIN.fonts && SKIN.fonts.en) T.font.en = SKIN.fonts.en;
  if (SKIN.fonts && SKIN.fonts.gothic) T.font.gothic = SKIN.fonts.gothic;
  return SKIN;
}

function loadSkin(rel, caseRoot) {
  if (!rel) return null;
  const kit = /^@([\w-]+)$/.exec(String(rel));
  const p = kit ? path.join(KIT_SKINS, kit[1], 'skin.json') : path.resolve(caseRoot, rel);
  if (kit && !fs.existsSync(p)) {
    const have = fs.existsSync(KIT_SKINS) ? fs.readdirSync(KIT_SKINS).map((d) => `@${d}`).join('・') : 'なし';
    throw new Error(`スキン ${rel} がキットにありません（あるもの：${have}）`);
  }
  SKIN_DIR = kit ? path.dirname(p) : null;
  return applySkin(JSON.parse(fs.readFileSync(p, 'utf8')), caseRoot);
}

function getSkin() { return SKIN; }
/** 版面ごと差し替えるスキンか（layout:"default" のスキンは配置を変えない） */
function framed() { return !!SKIN && SKIN.layout !== 'default'; }
/** スキンの値（無ければ d） */
function opt(k, d) { return SKIN && SKIN[k] !== undefined ? SKIN[k] : d; }
let PART = '';
/** いまの章（右上の札に出す）。章扉を描くたびに入れる */
function setPart(t) { PART = t || ''; }
function currentPart() { return PART; }

/** 案件フォルダの assets/ にある画像だけを返す（無ければ null） */
function skinImage(rel) {
  if (!rel) return null;
  if (SKIN_DIR) {   // キット同梱のスキン：スキンのフォルダの中だけ
    const abs = path.resolve(SKIN_DIR, rel);
    return abs.startsWith(SKIN_DIR + path.sep) && fs.existsSync(abs) ? abs : null;
  }
  if (!ROOT) return null;
  const abs = path.resolve(ROOT, rel);
  if (!abs.startsWith(path.join(ROOT, 'assets') + path.sep) || !fs.existsSync(abs)) return null;
  return abs;
}

/** 額縁・右上の印・ロゴを描く（どのページにも共通の外側） */
function drawFrame(s) {
  if (!SKIN) return;
  const f = SKIN.frame || {};
  s.background = { color: f.color || T.color.bg };
  (SKIN.images || []).forEach((im) => {
    const abs = skinImage(im.path);
    if (abs) s.addImage({ path: abs, x: im.x, y: im.y, w: im.w, h: im.h });
  });
  if (f.inner) s.addShape('rect', { x: f.x, y: f.y, w: f.w, h: f.h, fill: { color: f.inner }, line: { color: f.inner, width: 0 } });
  const b = SKIN.badge;
  if (b) {
    s.addShape('rect', { x: b.x, y: b.y, w: b.w, h: b.h, fill: { color: 'FFFFFF' }, line: { color: b.color, width: b.line || 1.25 } });
    s.addText(b.text, { x: b.x, y: b.y, w: b.w, h: b.h, fontFace: b.font || T.font.en, fontSize: b.size || 18, color: b.color, align: 'center', valign: 'middle', margin: 0 });
  }
  const l = SKIN.logo;
  const abs = l && skinImage(l.path);
  if (abs) s.addImage({ path: abs, x: l.x, y: l.y, w: l.w, h: l.h });
}

/** 全面の背景画像（表紙・章扉）。描けたら true */
function drawBackground(s, rel) {
  const abs = skinImage(rel);
  if (!abs) return false;
  s.addImage({ path: abs, x: 0, y: 0, w: T.slide.w, h: T.slide.h });
  return true;
}

/** 見出しの左の縦帯 */
function drawTitleBar(s) {
  const t = SKIN && SKIN.title_bar;
  if (!t) return;
  s.addShape('roundRect', { x: t.x, y: t.y, w: t.w, h: t.h, rectRadius: Math.min(t.w, t.h) / 2, fill: { color: t.color }, line: { color: t.color, width: 0 } });
}

module.exports = { applySkin, loadSkin, getSkin, framed, opt, setPart, currentPart, skinImage, drawFrame, drawTitleBar, drawBackground };
