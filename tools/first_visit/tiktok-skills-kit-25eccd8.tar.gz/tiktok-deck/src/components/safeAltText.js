// safeAltText.js — 画像の代替テキスト（descr）に、作った PC の絶対パスが入らないようにする（2026-10-02）
//
// pptxgenjs は addImage に altText を渡さないと、画像のパスをそのまま descr に書く。
// そのまま先方に渡すと、資料の中に「/Users/<名前>/Documents/projects/<案件>/…」が残る（PowerPoint の代替テキストで見える）。
// 読み込むだけで効く（build_research.js・generate.js の先頭で require する）。altText を明示した呼び出しはそのまま。
const path = require('path');
const pptxgen = require('pptxgenjs');

const proto = Object.getPrototypeOf(new pptxgen().addSlide());
if (!proto.__safeAltText) {
  const orig = proto.addImage;
  proto.addImage = function addImage(o = {}) {
    // data: の画像は中身そのものが descr に入るので、名前だけにする
    const alt = o.altText != null && o.altText !== '' ? o.altText : (o.path ? path.basename(o.path) : 'image');
    return orig.call(this, { ...o, altText: alt });
  };
  proto.__safeAltText = true;
}

module.exports = {};
