// storySlide.js — 初訪（ストーリー型）専用のスライド骨格
//
// 初訪は「画像＋ワンフレーズ」で読ませる資料（2026-09 上長FB）。
// 分析資料用の addSlide は Q番号・PARTタグ・lead注記（「検索上位のうち先頭10本。順位は…」）を
// 必ず出すため、上長が「この辺はいらない」と切った“器”がそのまま付いてくる。
// ここでは見出し・補足・フッターだけを持つ骨格を別に用意する。
const T = require('../theme');
const { fit, fitBalanced } = require('../helpers/text');
const { countSlide } = require('./slideBase');
const { fitBox, linkTo } = require('../helpers/imageBox');
const SK = require('./skin');

const S = {
  kickerY: 0.62,
  headY: 0.98, headH: 1.10,
  subY: 2.10, subH: 0.50,
  ruleY: 2.78,
  top: 3.05,            // 本文（ビジュアル）領域の上端
  bottom: T.content.bottom,
};

// 見出しは1行で言い切る長さ、補足は1行（どちらも超えたら生成ログに出す）
const HEAD_MAX = 34;
const SUB_MAX = 48;

let pageNo = 0;
let pageTotal = 0;
function resetStory(total) { pageNo = 0; pageTotal = total || 0; }

function addStoryFooter(s, left, dark) {
  pageNo += 1;
  const col = dark ? T.color.darkSub : T.color.subLight;
  const pnSkin = SK.getSkin() && SK.getSkin().page_number;
  if (SK.getSkin() && SK.getSkin().footer_text === false) left = null;
  const fSkin = SK.getSkin() && SK.getSkin().footer;
  if (left && fSkin) {   // スキンが決めた位置（下の帯の上など）
    s.addText(left, {
      x: fSkin.x, y: fSkin.y ?? T.footerY, w: fSkin.w, h: 0.34,
      fontFace: T.font.gothic, fontSize: fSkin.size || T.size.footer, color: dark ? col : (fSkin.color || col), valign: 'middle', margin: 0,
    });
  } else if (left) {
    const pre = SK.opt('footer_prefix');
    s.addText(pre ? `${pre}${left}` : left, {
      x: T.margin.l, y: T.footerY, w: pnSkin ? pnSkin.x - T.margin.l - 0.3 : T.content.w - 2.4, h: 0.34,
      fontFace: T.font.gothic, fontSize: T.size.footer, color: col, valign: 'middle', margin: 0, ...(pre ? { charSpacing: 1.6 } : {}),
    });
  }
  // preflight.py はこの「NN / NN」をフッターとして認識する（フッター衝突の判定に使う）
  const pn = (SK.getSkin() && SK.getSkin().page_number) || { x: T.slide.w - T.margin.r - 2.2, y: T.footerY, w: 2.2 };
  s.addText(`${String(pageNo).padStart(2, '0')} / ${pageTotal || '--'}`, {
    x: pn.x, y: pn.y ?? T.footerY, w: pn.w || 2.2, h: 0.34,
    fontFace: T.font.gothic, fontSize: T.size.footer, bold: !(pnSkin && pnSkin.bold === false), color: (!dark && pnSkin && pnSkin.color) || col,
    align: 'right', valign: 'middle', margin: 0,
  });
}

/**
 * 見出し（明朝・1文）＋補足（1〜2行）＋細罫＋フッターだけの骨格。
 * opts: {kicker, headline, sub, accent, footer}
 */
function addStorySlide(pptx, opts) {
  const s = pptx.addSlide();
  countSlide();
  s.background = { color: T.color.bg };
  const accent = opts.accent || T.brandColors[0];
  const skin = SK.getSkin();
  if (SK.framed()) return addSkinnedSlide(s, opts, skin, accent);
  const qlabel = SK.opt('header') === 'qlabel';
  if (opts.kicker && qlabel) {
    // 元のFMT：番号を赤の太字の札に、続きを問いのように灰色で（「Q1-1　誰が取り上げていて…」の形）
    const m = /^(\S+)[　 ]+(.+)$/.exec(String(opts.kicker));
    const label = m ? m[1] : '';
    const rest = m ? m[2] : String(opts.kicker);
    let x = T.margin.l;
    if (label) {
      const lw = Math.max(0.9, 0.2 + String(label).length * 0.3);
      s.addText(label, { x, y: S.kickerY - 0.12, w: lw, h: 0.6, fontFace: T.font.gothic, fontSize: 26, bold: true, color: accent, valign: 'middle', margin: 0 });
      x += lw + 0.15;
    }
    s.addText(rest, { x, y: S.kickerY - 0.12, w: T.slide.w - T.margin.r - 5.2 - x, h: 0.6, fontFace: T.font.gothic,
      fontSize: fit(rest, T.slide.w - T.margin.r - 5.2 - x, 0.6, { base: 19, min: Math.max(15, T.minText || 0), quiet: true }), bold: true, color: T.color.text, valign: 'middle', margin: 0 });
  } else if (opts.kicker) {
    s.addText(opts.kicker, {
      x: T.margin.l, y: S.kickerY, w: 12.0, h: 0.36,
      fontFace: T.font.gothic, fontSize: 14, bold: true, color: accent,
      charSpacing: 1.2, valign: 'middle', margin: 0,
    });
  }
  const tagText = opts.tag || (qlabel ? SK.currentPart() : '');
  if (tagText) {
    s.addText(tagText, {
      x: T.slide.w - T.margin.r - 5.0, y: S.kickerY, w: 5.0, h: 0.36,
      fontFace: T.font.gothic, fontSize: qlabel ? Math.max(14, T.minText || 0) : 12, color: T.color.subLight,
      align: 'right', valign: 'middle', charSpacing: 1.2, margin: 0,
    });
  }
  const headBase = SK.opt('head_base', 40);
  s.addText(opts.headline || '', {
    x: T.margin.l, y: S.headY, w: T.content.w, h: S.headH,
    fontFace: T.font.mincho,
    fontSize: fitBalanced(opts.headline || '', T.content.w, S.headH,
      { base: headBase, min: Math.min(30, headBase - 4), lineHeight: 1.15, minTail: 6 }),
    bold: true, color: T.color.text, valign: 'middle', margin: 0,
  });
  // 話す内容はノートへ（2026-09-30 FB「文字を多用せず、細かくは人間が口で言う」）。
  // s.talk(文) で積んだものを、ノートの先頭「話すこと」にまとめる。社内向けのノート（投稿IDなど）とは別の段にする
  s._talk = [];
  s.talk = (t) => { if (t && String(t).trim()) s._talk.push(String(t).trim()); };
  s._headLen = String(opts.headline || '').length;
  // 補足は1行で読める長さ（SUB_MAX 字）だけ紙面に置く。長い補足はノートへ回す
  if (opts.sub && String(opts.sub).length <= SUB_MAX) {
    s.addText(opts.sub, {
      x: T.margin.l, y: S.subY, w: T.content.w, h: S.subH,
      fontFace: T.font.gothic,
      fontSize: fit(opts.sub, T.content.w, S.subH, { base: 18, min: Math.max(15, T.minText || 0), lineHeight: 1.2 }),
      color: T.color.sub, valign: 'top', margin: 0,
    });
  } else if (opts.sub) {
    s.talk(opts.sub);
  }
  s.addShape('line', {
    x: T.margin.l, y: S.ruleY, w: T.content.w, h: 0, line: { color: T.color.rule, width: 1.1 },
  });
  addStoryFooter(s, opts.footer);
  // 本文の文字数を数える（FB「文字が多い」の再発防止）。短いラベル（順位・再生・PR 等の6字以下）は
  // 文章ではないので数えない。preflight.py と同じ数え方にする（キッカー・タグも紙面の文字なので数える）
  s._fvChars = [opts.kicker, opts.tag, opts.headline, opts.sub].filter(Boolean)
    .reduce((a, t) => a + (String(t).length > 6 ? String(t).length : 0), 0);
  const orig = s.addText.bind(s);
  s.addText = (t, o) => {
    const str = typeof t === 'string' ? t : (Array.isArray(t) ? t.map((x) => (x && x.text) || '').join('') : '');
    if (str.length > 6) s._fvChars += str.length;
    return orig(t, o);
  };
  return s;
}

/**
 * スキン（案件のFMT）に合わせた骨格。見出しはFMTの見出しの位置（左に縦帯）に置き、
 * その下に小見出しと補足を1行ずつ。額縁・右上の印・ロゴは skin.js が描く。
 */
function addSkinnedSlide(s, opts, skin, accent) {
  SK.drawFrame(s);
  SK.drawTitleBar(s);
  const t = skin.title;
  s.addText(opts.headline || '', {
    x: t.x, y: t.y, w: t.w, h: t.h, fontFace: T.font.mincho,
    fontSize: fitBalanced(opts.headline || '', t.w, t.h, { base: t.base || 32, min: t.min || 24, lineHeight: 1.15, minTail: 6 }),
    bold: true, color: t.color || T.color.text, align: t.align || 'left', valign: 'middle', margin: 0,
  });
  const k = skin.kicker || {};
  if (opts.kicker) {
    const kw = k.w || 14.0;
    s.addText(opts.kicker, { x: k.x ?? t.x, y: k.y, w: kw, h: k.h || 0.34, fontFace: T.font.gothic,
      fontSize: k.w ? fit(opts.kicker, kw, k.h || 0.34, { base: k.size || 13, min: 16, lineHeight: 1.1, quiet: true }) : (k.size || 13),
      bold: k.bold !== false, color: k.color || accent, align: k.align || 'left', valign: 'middle', margin: 0 });
  }
  if (opts.tag) {
    s.addText(opts.tag, { x: T.slide.w - T.margin.r - 5.0, y: k.y, w: 5.0, h: k.h || 0.34, fontFace: T.font.gothic, fontSize: 12, color: T.color.subLight, align: 'right', valign: 'middle', margin: 0 });
  }
  s._talk = [];
  s.talk = (x) => { if (x && String(x).trim()) s._talk.push(String(x).trim()); };
  s._headLen = String(opts.headline || '').length;
  const sb = skin.sub || {};
  if (opts.sub && String(opts.sub).length <= SUB_MAX) {
    const sw = sb.w || T.content.w;
    s.addText(opts.sub, { x: sb.x ?? t.x, y: sb.y, w: sw, h: sb.h || 0.45, fontFace: T.font.gothic, fontSize: fit(opts.sub, sw, sb.h || 0.45, { base: sb.size || 16, min: 14, lineHeight: 1.2 }), color: T.color.sub, align: sb.align || 'left', valign: 'top', margin: 0 });
  } else if (opts.sub) {
    s.talk(opts.sub);
  }
  if (skin.rule) s.addShape('line', { x: T.margin.l, y: skin.rule.y, w: T.content.w, h: 0, line: { color: skin.rule.color || T.color.ruleThin, width: skin.rule.width || 0.75 } });
  addStoryFooter(s, opts.footer);
  s._fvChars = [opts.kicker, opts.tag, opts.headline, opts.sub].filter(Boolean).reduce((a, x) => a + (String(x).length > 6 ? String(x).length : 0), 0);
  const orig = s.addText.bind(s);
  s.addText = (x, o) => {
    const str = typeof x === 'string' ? x : (Array.isArray(x) ? x.map((y) => (y && y.text) || '').join('') : '');
    if (str.length > 6) s._fvChars += str.length;
    return orig(x, o);
  };
  return s;
}

/** スキンを当てたら、本文の上端などの寸法を合わせる（research.js が組み始める前に呼ぶ） */
function useSkin(rel, caseRoot) {
  const skin = SK.loadSkin(rel, caseRoot);
  if (skin && skin.top) S.top = skin.top;
  return skin;
}

/** s.talk で積んだ「話すこと」をノートに書く。ページを描き終えたら呼ぶ（社内向けのノートより前に置く） */
function flushTalk(s) {
  if (!s || !s._talk || !s._talk.length) return;
  s.addNotes(`【話すこと】\n${s._talk.map((t) => `・${t}`).join('\n')}\n\n`);
  s._talk = [];
}

/** 小さなバッジ（PR / 公式 / 順位）。画像の上に重ねる */
function addBadge(s, { x, y, text, fill, color, w, h, size }) {
  const bw = w || Math.max(0.46, 0.16 + String(text).length * 0.17);
  const bh = h || 0.30;
  s.addShape('rect', { x, y, w: bw, h: bh, fill: { color: fill || T.color.chipDark }, line: { color: fill || T.color.chipDark, width: 0 } });
  s.addText(String(text), {
    x, y, w: bw, h: bh,
    fontFace: T.font.gothic, fontSize: size || 11, bold: true, color: color || 'FFFFFF',
    align: 'center', valign: 'middle', margin: 0,
  });
  return bw;
}

/**
 * 9:16 の投稿カバーを枠に収めて置く（縦横比は実寸から）。リンク付き。
 * 画像が無ければ何も置かず null を返す（生成画像やダミーで埋めない）。
 */
function addThumb(s, absPath, box, url) {
  if (!absPath) return null;
  const b = fitBox(absPath, box.x, box.y, box.w, box.h);
  s.addImage({ path: absPath, ...b, ...linkTo(url) });
  // 細い枠。クリーム地に明るいカバーが溶けるのを防ぐ
  s.addShape('rect', { ...b, fill: { type: 'none' }, line: { color: T.color.cardLine, width: 0.75 } });
  return b;
}

/** 点線の空枠（「まだ無し」）。自社の投稿が無いことを“画で”見せる */
function addEmptySlot(s, box, text) {
  s.addShape('rect', {
    ...box, fill: { color: T.color.cardBg },
    line: { color: T.color.subLight, width: 1.25, dashType: 'dash' },
  });
  s.addText(text || 'まだ無し', {
    ...box, fontFace: T.font.gothic, fontSize: 16, bold: true, color: T.color.subLight,
    align: 'center', valign: 'middle',
  });
}

module.exports = { S, HEAD_MAX, SUB_MAX, flushTalk, useSkin, addStorySlide, addStoryFooter, addBadge, addThumb, addEmptySlot, resetStory };
